"""Локальная подмена GitHub API — чтобы прогнать все сценарии
обновления, не создавая настоящих релизов.

Запуск (из папки проекта, где лежит release/ после make_release.py):

    python fake_github.py 1.3.0

Затем во ВТОРОМ окне, перед запуском приложения:

    set DOPAMINE_UPDATE_API_BASE=http://127.0.0.1:8765
    set DOPAMINE_REPO=test/test
    python app.py

Сценарии (аргумент --mode):
    ok       — нормальный релиз (по умолчанию)
    none     — обновлений нет (отдаёт текущую версию)
    broken   — битый архив (проверяем, что установка отменяется)
    badhash  — неверная сумма в SHA256SUMS.txt
    fail     — сервер отдаёт 500 на скачивание ассета
"""

import argparse
import hashlib
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
RELEASE_DIR = os.path.join(ROOT, "release")
PORT = 8765

CFG = {"version": "1.3.0", "mode": "ok"}


def assets():
    out = []
    if not os.path.isdir(RELEASE_DIR):
        return out
    for fn in sorted(os.listdir(RELEASE_DIR)):
        if fn.endswith(".zip") or fn == "SHA256SUMS.txt":
            out.append({
                "name": fn,
                "size": os.path.getsize(os.path.join(RELEASE_DIR, fn)),
                "browser_download_url": f"http://127.0.0.1:{PORT}/asset/{fn}",
            })
    return out


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        print("  [fake_github]", fmt % a)

    def _send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.endswith("/releases/latest"):
            data = {
                "tag_name": "v" + CFG["version"],
                "draft": False,
                "prerelease": False,
                "published_at": "2026-09-17T10:00:00Z",
                "body": "Тестовый релиз.\n- пункт один\n- пункт два",
                "assets": assets(),
            }
            self._send(200, json.dumps(data).encode("utf-8"))
            return

        if self.path.startswith("/asset/"):
            name = os.path.basename(self.path[len("/asset/"):])
            path = os.path.join(RELEASE_DIR, name)
            if not os.path.exists(path):
                self._send(404, b'{"message":"not found"}')
                return
            if CFG["mode"] == "fail" and name.endswith(".zip"):
                self._send(500, b'{"message":"boom"}')
                return
            with open(path, "rb") as f:
                body = f.read()
            if CFG["mode"] == "broken" and name.endswith(".zip"):
                body = b"NOT-A-ZIP" + body[9:]          # ломаем сигнатуру
            if CFG["mode"] == "badhash" and name == "SHA256SUMS.txt":
                body = b"0" * 64 + b" *" + body.split(b"*", 1)[1]
            self._send(200, body, "application/octet-stream")
            return

        self._send(404, b'{"message":"no route"}')


def main():
    p = argparse.ArgumentParser()
    p.add_argument("version", nargs="?", default="1.3.0")
    p.add_argument("--mode", default="ok",
                   choices=["ok", "none", "broken", "badhash", "fail"])
    a = p.parse_args()
    CFG["version"] = a.version
    CFG["mode"] = a.mode
    if a.mode == "none":
        sys.path.insert(0, ROOT)
        import version
        CFG["version"] = version.__version__

    print(f"Fake GitHub на http://127.0.0.1:{PORT}  "
          f"версия={CFG['version']}  режим={CFG['mode']}")
    print(f"Ассеты берутся из: {RELEASE_DIR}")
    print("Ctrl+C — остановить")
    HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
