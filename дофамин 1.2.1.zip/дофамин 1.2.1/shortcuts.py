"""Ярлык на рабочем столе и автозапуск при входе в Windows.

Только stdlib: .lnk создаётся через PowerShell (WScript.Shell), который
есть в любой Windows — pywin32/winshell не нужны.

Автозапуск делается ярлыком в папке «Автозагрузка», а не записью в
реестре: так пользователь видит его в Диспетчере задач и может
отключить сам, и ничего не остаётся в системе после удаления папки.

Все функции возвращают (успех: bool, сообщение_для_UI: str) и никогда
не бросают исключений.
"""

import logging
import os
import subprocess
import sys

logger = logging.getLogger("shortcuts")

AVAILABLE = sys.platform == "win32"

if getattr(sys, "frozen", False):
    APP_PATH = os.path.dirname(sys.executable)
    TARGET = sys.executable
    ARGS = ""
else:
    APP_PATH = os.path.dirname(os.path.abspath(__file__))
    _py = sys.executable
    _pyw = os.path.join(os.path.dirname(_py), "pythonw.exe")
    TARGET = _pyw if os.path.exists(_pyw) else _py
    ARGS = os.path.join(APP_PATH, "app.py")

SHORTCUT_NAME = "Dopamine Assistant.lnk"
ICON_PATH = os.path.join(APP_PATH, "icon.ico")

_CREATE_NO_WINDOW = 0x08000000


def _run_ps(script: str) -> bool:
    try:
        res = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=30,
            creationflags=_CREATE_NO_WINDOW)
        if res.returncode != 0:
            logger.error("PowerShell вернул %s: %s", res.returncode,
                         (res.stderr or "").strip()[:300])
            return False
        return True
    except Exception as e:
        logger.error("Запуск PowerShell не удался: %s", e)
        return False


def _desktop_dir() -> str:
    return os.path.join(os.environ.get("USERPROFILE",
                                       os.path.expanduser("~")), "Desktop")


def _startup_dir() -> str:
    appdata = os.environ.get("APPDATA", "")
    return os.path.join(appdata, "Microsoft", "Windows", "Start Menu",
                        "Programs", "Startup")


def _make_lnk(lnk_path: str) -> bool:
    """Создаёт .lnk на приложение с правильной рабочей папкой.

    WorkingDirectory обязателен: без него приложение стартует с чужим
    CWD и не находит относительные пути.
    """
    args = f'$s.Arguments = "{ARGS}";' if ARGS else ""
    icon = (f'$s.IconLocation = "{ICON_PATH}";'
            if os.path.exists(ICON_PATH) else "")
    script = (
        "$w = New-Object -ComObject WScript.Shell;"
        f'$s = $w.CreateShortcut("{lnk_path}");'
        f'$s.TargetPath = "{TARGET}";'
        f"{args}"
        f'$s.WorkingDirectory = "{APP_PATH}";'
        f"{icon}"
        '$s.Description = "Dopamine Assistant";'
        "$s.Save()"
    )
    return _run_ps(script)


def create_desktop_shortcut():
    if not AVAILABLE:
        return False, "Ярлыки поддерживаются только в Windows"
    desktop = _desktop_dir()
    if not os.path.isdir(desktop):
        return False, f"Папка рабочего стола не найдена: {desktop}"
    path = os.path.join(desktop, SHORTCUT_NAME)
    if _make_lnk(path) and os.path.exists(path):
        logger.info("Создан ярлык: %s", path)
        return True, "Ярлык создан на рабочем столе"
    return False, "Не удалось создать ярлык (подробности в логе)"


def autostart_path() -> str:
    return os.path.join(_startup_dir(), SHORTCUT_NAME)


def is_autostart_enabled() -> bool:
    try:
        return AVAILABLE and os.path.exists(autostart_path())
    except OSError:
        return False


def set_autostart(enabled: bool):
    if not AVAILABLE:
        return False, "Автозапуск поддерживается только в Windows"
    path = autostart_path()
    if enabled:
        d = os.path.dirname(path)
        if not os.path.isdir(d):
            return False, f"Папка автозагрузки не найдена: {d}"
        if _make_lnk(path) and os.path.exists(path):
            logger.info("Автозапуск включён: %s", path)
            return True, "Приложение будет запускаться при входе в Windows"
        return False, "Не удалось включить автозапуск (см. лог)"
    try:
        if os.path.exists(path):
            os.remove(path)
        logger.info("Автозапуск выключен")
        return True, "Автозапуск отключён"
    except OSError as e:
        logger.error("Снятие автозапуска: %s", e)
        return False, f"Не удалось отключить автозапуск: {e}"
