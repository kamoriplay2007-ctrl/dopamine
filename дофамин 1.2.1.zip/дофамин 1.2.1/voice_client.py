"""Голосовой модуль Dopamine Assistant.

Две независимые возможности, каждая работает даже если вторая недоступна:

1. Голос -> текст (распознавание речи).
   Запись идёт с микрофона (sounddevice), а расшифровка — через
   тот же аккаунт Cloudflare Workers AI, что уже используется для
   чата (модель @cf/openai/whisper). Отдельного API-ключа не нужно —
   используются CLOUDFLARE_API_KEY / CLOUDFLARE_ACCOUNT_ID из .env.

2. Текст -> голос (озвучка ответов AI).
   Работает полностью офлайн через pyttsx3 (Windows: SAPI5,
   macOS: NSSpeechSynthesizer, Linux: espeak) — интернет не нужен.

Зависимости (по желанию, модуль работает и без них — просто
соответствующая функция становится недоступна):
    pip install sounddevice numpy pyttsx3

Никакая часть приложения, кроме UI-кнопок микрофона/озвучки,
не обязана знать про эти зависимости — ai_client.py и остальной
код работают как прежде.
"""
import os
import io
import sys
import json
import time
import wave
import logging
import threading
import urllib.request
import urllib.error

logger = logging.getLogger(__name__)

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

try:
    import sounddevice as sd
    import numpy as np
    HAS_MIC = True
except Exception as _e:
    HAS_MIC = False
    logger.warning("Голосовой ввод недоступен (нет sounddevice/numpy): %s", _e)

try:
    import pyttsx3
    HAS_TTS = True
except Exception as _e:
    HAS_TTS = False
    logger.warning("Озвучка недоступна (нет pyttsx3): %s", _e)

CLOUDFLARE_API_KEY = os.environ.get("CLOUDFLARE_API_KEY", "").strip()
CLOUDFLARE_ACCOUNT_ID = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "").strip()
WHISPER_MODEL = "@cf/openai/whisper"

SAMPLE_RATE = 16000          # Whisper ожидает 16 кГц, моно, 16 бит
MIN_RECORDING_SEC = 0.3      # короче — считаем случайным кликом
MAX_RECORDING_SEC = 60       # защита от "забыл остановить запись"
TRANSCRIBE_TIMEOUT = 30
TRANSCRIBE_RETRIES = 2


class VoiceClient:
    """Запись голоса -> текст и текст -> голос."""

    def __init__(self):
        self.mic_available = bool(HAS_MIC and CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID)
        self.tts_available = HAS_TTS

        self._recording = False
        self._frames = []
        self._stream = None
        self._record_started_at = 0.0

        self._tts_lock = threading.Lock()
        self._tts_stop_flag = threading.Event()

        if not HAS_MIC:
            logger.info("Запись голоса: нет sounddevice/numpy — 'pip install sounddevice numpy'")
        elif not (CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID):
            logger.info("Запись голоса: не настроен .env (CLOUDFLARE_API_KEY/ACCOUNT_ID)")

    def mic_unavailable_reason(self):
        """Человекочитаемая причина, почему голосовой ввод недоступен (для UI)."""
        if not HAS_MIC:
            return ("Голосовой ввод недоступен.\n\n"
                    "Установи зависимости:\n"
                    "   pip install sounddevice numpy")
        if not (CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID):
            return ("Голосовой ввод недоступен: не настроен .env.\n"
                    "Нужны CLOUDFLARE_API_KEY и CLOUDFLARE_ACCOUNT_ID "
                    "(те же, что и для AI-чата).")
        return None

    def tts_unavailable_reason(self):
        if not HAS_TTS:
            return ("Озвучка недоступна.\n\n"
                    "Установи зависимость:\n"
                    "   pip install pyttsx3")
        return None

    # ---------------------------------------------------------------
    # Голос -> текст
    # ---------------------------------------------------------------

    def start_recording(self):
        """Начинает запись с микрофона (неблокирующе). True при успехе."""
        if not self.mic_available or self._recording:
            return False
        self._frames = []
        try:
            self._stream = sd.InputStream(
                samplerate=SAMPLE_RATE, channels=1, dtype="int16",
                callback=self._on_audio_block)
            self._stream.start()
            self._recording = True
            self._record_started_at = time.time()
            return True
        except Exception as e:
            logger.error("Ошибка запуска записи микрофона: %s", e)
            self._stream = None
            self._recording = False
            return False

    def _on_audio_block(self, indata, frames, time_info, status):
        if status:
            logger.debug("Audio input status: %s", status)
        self._frames.append(indata.copy())
        # Защита от бесконечной записи, если пользователь забыл нажать "стоп"
        if time.time() - self._record_started_at > MAX_RECORDING_SEC:
            try:
                self._stream.stop()
            except Exception:
                pass

    def is_recording(self):
        return self._recording

    def cancel_recording(self):
        """Останавливает запись без распознавания (например, при закрытии окна)."""
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
        self._stream = None
        self._recording = False
        self._frames = []

    def stop_recording_and_transcribe(self):
        """Останавливает запись и распознаёт речь.

        Блокирующий вызов (сетевой запрос) — вызывать из фонового потока,
        не из GUI-потока. Возвращает (True, текст) или (False, текст ошибки).
        """
        if not self._recording:
            return False, "Запись не была начата"
        try:
            self._stream.stop()
            self._stream.close()
        except Exception:
            pass
        self._recording = False
        frames, self._frames = self._frames, []

        if not frames:
            return False, "Не удалось записать звук с микрофона"

        audio = np.concatenate(frames, axis=0)
        duration = len(audio) / SAMPLE_RATE
        if duration < MIN_RECORDING_SEC:
            return False, "Запись слишком короткая"

        wav_bytes = self._to_wav_bytes(audio)
        return self._transcribe(wav_bytes)

    @staticmethod
    def _to_wav_bytes(audio_np):
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)  # int16 = 2 байта
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(audio_np.tobytes())
        return buf.getvalue()

    def _transcribe(self, wav_bytes):
        if not (CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID):
            return False, "Не настроены CLOUDFLARE_API_KEY/ACCOUNT_ID"

        url = (f"https://api.cloudflare.com/client/v4/accounts/"
               f"{CLOUDFLARE_ACCOUNT_ID}/ai/run/{WHISPER_MODEL}")
        last_error = None
        for attempt in range(TRANSCRIBE_RETRIES + 1):
            try:
                req = urllib.request.Request(
                    url, data=wav_bytes, method="POST",
                    headers={
                        "Authorization": f"Bearer {CLOUDFLARE_API_KEY}",
                        "Content-Type": "application/octet-stream",
                    })
                with urllib.request.urlopen(req, timeout=TRANSCRIBE_TIMEOUT) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                text = (data.get("result") or {}).get("text", "").strip()
                if data.get("success") and text:
                    return True, text
                return False, "Не удалось распознать речь (пустой результат)"
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode("utf-8", "ignore")[:300]
                except Exception:
                    body = ""
                last_error = f"HTTP {e.code}: {body}"
            except Exception as e:
                last_error = str(e)
            if attempt < TRANSCRIBE_RETRIES:
                time.sleep(1.5 * (attempt + 1))

        logger.error("Ошибка распознавания речи: %s", last_error)
        return False, f"Ошибка распознавания: {last_error}"

    # ---------------------------------------------------------------
    # Текст -> голос
    # ---------------------------------------------------------------

    def speak(self, text, on_done=None):
        """Озвучивает текст в фоновом потоке. Не блокирует GUI.

        on_done (если передан) вызывается по завершении озвучки —
        из фонового потока, поэтому в GUI его нужно перекладывать
        через app.after(0, ...).
        """
        if not self.tts_available or not (text or "").strip():
            if on_done:
                on_done()
            return
        clean = self._strip_for_speech(text)
        if not clean:
            if on_done:
                on_done()
            return

        def worker():
            com_ok = False
            if sys.platform == "win32":
                try:
                    import pythoncom
                    pythoncom.CoInitialize()
                    com_ok = True
                except Exception:
                    pass
            with self._tts_lock:
                self._tts_stop_flag.clear()
                try:
                    engine = pyttsx3.init()
                    engine.say(clean)
                    engine.runAndWait()
                    engine.stop()
                except Exception as e:
                    logger.error("Ошибка озвучки: %s", e)
            if com_ok:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass
            if on_done:
                on_done()

        threading.Thread(target=worker, daemon=True).start()

    @staticmethod
    def _strip_for_speech(text):
        """Чистит текст от markdown/эмодзи, чтобы TTS не читал их дословно."""
        import re
        text = re.sub(r'[*_`#>~]', ' ', text)
        text = re.sub(r'[\U0001F300-\U0001FAFF\u2600-\u27BF\u2190-\u21FF]', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()


voice_client = VoiceClient()
