"""AI-клиент Cloudflare Workers AI.

Изменения по сравнению с исходной версией:
- chat() принимает необязательный kb_context — список готовых
  Q&A-фрагментов из локальной базы знаний клуба (RAG). Они
  подмешиваются в system-промпт ТОЛЬКО для текущего запроса
  (в self.history не попадают), чтобы модель в первую очередь
  опиралась на проверенные ответы клуба, а не выдумывала общие
  советы.
- Добавлены повторные попытки с задержкой при сетевых сбоях
  (таймаут, обрыв соединения и т.п.), чтобы разовый сбой сети
  клуба не превращался в "❌ Ошибка AI" для пользователя.
- Добавлен настраиваемый таймаут запроса.
"""
import os
import time
import logging

logger = logging.getLogger(__name__)

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

try:
    from openai import OpenAI
    HAS_OPENAI = True
except Exception:
    HAS_OPENAI = False

CLOUDFLARE_API_KEY = os.environ.get("CLOUDFLARE_API_KEY", "").strip()
CLOUDFLARE_ACCOUNT_ID = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "").strip()
AI_MODEL = "@cf/meta/llama-3.3-70b-instruct-fp8-fast"

REQUEST_TIMEOUT = 30       # секунд на один запрос к Cloudflare
MAX_RETRIES = 2            # повторных попыток при сетевой ошибке
RETRY_BACKOFF_SEC = 1.5    # базовая задержка между попытками

SYSTEM_PROMPT = (
    "Ты — AI-помощник техника компьютерного клуба LANGame. "
    "Отвечай кратко, по делу, на русском языке. "
    "Помогай с проблемами: игры (CS2, Minecraft, DBD, GTA 5), "
    "периферия (микрофон, мышь, клавиатура), софт (VPN, Steam, античиты), "
    "сеть (пинг, интернет), клуб (бронь, оплата). "
    "Если не уверен — предложи обратиться к админу. "
    "Используй списки, если шагов несколько."
)


def _build_kb_context_message(kb_context):
    """Формирует system-сообщение с найденными фрагментами базы знаний клуба."""
    if not kb_context:
        return None
    snippets = "\n\n".join(f"— {s.strip()}" for s in kb_context if s and s.strip())
    if not snippets:
        return None
    return {
        "role": "system",
        "content": (
            "Ниже — проверенные материалы из базы знаний клуба LANGame, "
            "которые могут быть релевантны вопросу пользователя. "
            "Если они подходят — обязательно используй их как основу ответа "
            "(это специфика именно этого клуба). Если не подходят — "
            "игнорируй их и отвечай своими знаниями.\n\n" + snippets
        ),
    }


class AIClient:
    def __init__(self):
        self.client = None
        self.available = False
        self.history = []
        self._init()

    def _init(self):
        if not HAS_OPENAI or not CLOUDFLARE_API_KEY or not CLOUDFLARE_ACCOUNT_ID:
            logger.warning("AI недоступен")
            return
        try:
            self.client = OpenAI(
                api_key=CLOUDFLARE_API_KEY,
                base_url=f"https://api.cloudflare.com/client/v4/accounts/{CLOUDFLARE_ACCOUNT_ID}/ai/v1",
                timeout=REQUEST_TIMEOUT,
            )
            self.available = True
            logger.info("AI-клиент Cloudflare готов")
        except Exception as e:
            logger.error("AI init error: %s", e)
            self.available = False

    def chat(self, user_message: str, kb_context=None) -> str:
        """Отправляет сообщение модели.

        kb_context: список строк (Q&A-фрагментов из базы знаний клуба),
        найденных отдельным поиском по ключевым словам ДО вызова chat().
        Используется только для этого запроса и не сохраняется в истории,
        чтобы не раздувать контекст будущих сообщений устаревшими данными.
        """
        if not self.available:
            return ("⚠️ AI недоступен.\n\n"
                    "1. Создай .env рядом с app.py\n"
                    "2. Добавь:\n"
                    "   CLOUDFLARE_API_KEY=cfut_...\n"
                    "   CLOUDFLARE_ACCOUNT_ID=твой_id\n"
                    "3. pip install openai python-dotenv")

        self.history.append({"role": "user", "content": user_message})
        history = self.history[-20:]

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        ctx_msg = _build_kb_context_message(kb_context)
        if ctx_msg:
            messages.append(ctx_msg)
        messages += history

        last_error = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                resp = self.client.chat.completions.create(
                    model=AI_MODEL, messages=messages,
                    temperature=0.4, max_tokens=1500, stream=False)
                answer = resp.choices[0].message.content
                self.history.append({"role": "assistant", "content": answer})
                return answer
            except Exception as e:
                last_error = e
                is_last = attempt == MAX_RETRIES
                logger.error("AI chat error (попытка %d/%d): %s",
                             attempt + 1, MAX_RETRIES + 1, e)
                if not is_last:
                    time.sleep(RETRY_BACKOFF_SEC * (attempt + 1))

        # Не удалось получить ответ — откатываем последнее сообщение
        # пользователя из истории, чтобы не засорять контекст неудачным
        # запросом при следующей попытке.
        if self.history and self.history[-1]["content"] == user_message:
            self.history.pop()
        return f"❌ Ошибка AI: {last_error}"

    def clear(self):
        self.history = []


ai_client = AIClient()
