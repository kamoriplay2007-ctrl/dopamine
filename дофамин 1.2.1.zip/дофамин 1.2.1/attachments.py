"""
Модуль вложений для Dopamine Assistant.

Безопасное сохранение, чтение и удаление пользовательских файлов
с проверкой MIME-типов, симлинков, квот и защитой от path traversal.
"""

import os
import io
import sys
import hashlib
import shutil
import subprocess
import logging
from datetime import datetime
from functools import lru_cache
from typing import Optional

logger = logging.getLogger(__name__)

ALLOWED_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
    ".mp4", ".avi", ".mkv", ".mov",
    ".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac",
    ".pdf", ".txt", ".docx", ".zip",
}

# Расширения, которые считаем "известными" для проверки сигнатур
_MAGIC_SIGNATURES = {
    b"\x89PNG\r\n\x1a\n": {".png"},
    b"\xff\xd8\xff":      {".jpg", ".jpeg"},
    b"GIF87a":            {".gif"},
    b"GIF89a":            {".gif"},
    b"%PDF":              {".pdf"},
    b"PK\x03\x04":        {".zip", ".docx"},
    b"\x1aE\xdf\xa3":     {".mkv", ".webm"},
    b"OggS":              {".ogg"},
    b"ID3":               {".mp3"},
    b"RIFF":              {".wav", ".avi", ".webp"},
}

MAX_FILE_SIZE_MB = 20
MAX_FILES_PER_ITEM = 3
MAX_TOTAL_STORAGE_MB = 2000
MAX_FILENAME_LEN = 120
_HASH_BLOCK = 1 << 20  # 1 МБ


@lru_cache(maxsize=1)
def _data_dir() -> str:
    """Путь к папке вложений. Кэшируется после первого вызова."""
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(base, "data", "attachments")
    os.makedirs(d, exist_ok=True)
    return d


def _sanitize_name(name: str) -> str:
    """Убирает опасные символы из отображаемого имени файла."""
    name = os.path.basename(name)
    name = "".join(c for c in name if c.isprintable() and c not in '<>:"/\\|?*')
    if len(name) > MAX_FILENAME_LEN:
        base, ext = os.path.splitext(name)
        name = base[: MAX_FILENAME_LEN - len(ext) - 1] + ext
    return name or "file"


def _file_hash(path: str) -> str:
    """SHA-256 всего файла, читается блоками."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(_HASH_BLOCK), b""):
                h.update(chunk)
    except OSError as e:
        logger.warning("Не удалось прочитать файл для хэша: %s", e)
        return "0000000000000000"
    return h.hexdigest()[:16]


def _looks_like_allowed_content(path: str) -> bool:
    """Мягкая проверка сигнатуры. Пропускает txt и неизвестные типы."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".txt":
        return True
    try:
        with open(path, "rb") as f:
            head = f.read(16)
    except OSError:
        return False
    if not head:
        return False
    for sig, exts in _MAGIC_SIGNATURES.items():
        if head.startswith(sig):
            return True
    # Не нашли сигнатуру — не блокируем, но логируем
    logger.debug("Сигнатура не распознана для %s", path)
    return True


def _total_storage_mb() -> float:
    try:
        total = 0
        for f in os.listdir(_data_dir()):
            fp = os.path.join(_data_dir(), f)
            if os.path.isfile(fp):
                total += os.path.getsize(fp)
        return total / (1024 * 1024)
    except OSError:
        return 0.0


def is_allowed(path: str) -> bool:
    ext = os.path.splitext(path)[1].lower()
    return ext in ALLOWED_EXTS


def file_size_ok(path: str) -> tuple[bool, float]:
    try:
        size_mb = os.path.getsize(path) / (1024 * 1024)
        return size_mb <= MAX_FILE_SIZE_MB, round(size_mb, 2)
    except OSError:
        return False, 0.0


_COPY_CHUNK = 4 * 1024 * 1024  # 4 МБ — размер блока при копировании с прогрессом


def _copy_with_progress(src_path: str, dst_path: str, progress_cb=None) -> None:
    """Копирует файл блоками, опционально сообщая прогресс.

    progress_cb(copied_bytes, total_bytes) вызывается после каждого блока —
    удобно для прогресс-бара в GUI при копировании больших видео/аудио.
    Пишет во временный файл рядом с целевым и переименовывает его только
    после успешного завершения — при сбое (обрыв, нехватка места) в папке
    вложений не останется "битого" файла с финальным именем.
    """
    total = os.path.getsize(src_path)
    tmp_path = dst_path + ".part"
    copied = 0
    try:
        with open(src_path, "rb") as fsrc, open(tmp_path, "wb") as fdst:
            while True:
                chunk = fsrc.read(_COPY_CHUNK)
                if not chunk:
                    break
                fdst.write(chunk)
                copied += len(chunk)
                if progress_cb:
                    try:
                        progress_cb(copied, total)
                    except Exception:
                        pass  # прогресс не должен ронять копирование
            fdst.flush()
            os.fsync(fdst.fileno())
        os.replace(tmp_path, dst_path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
    # Сохраняем метаданные файла (mtime и т.п.), как это делал copy2
    try:
        shutil.copystat(src_path, dst_path)
    except OSError:
        pass


def save_attachment(src_path: str, progress_cb=None) -> tuple[bool, dict | str]:
    """
    Копирует файл в data/attachments/.
    progress_cb(copied_bytes, total_bytes), если передан, вызывается по ходу
    копирования — можно привязать к прогресс-бару для больших файлов.
    Возвращает (True, dict) или (False, "текст ошибки").
    """
    if not src_path or not os.path.exists(src_path):
        return False, "Файл не найден"

    # Защита от симлинков
    try:
        real = os.path.realpath(src_path)
        if not os.path.isfile(real):
            return False, "Это не файл"
    except OSError as e:
        return False, f"Ошибка доступа: {e}"

    if not is_allowed(src_path):
        ext = os.path.splitext(src_path)[1]
        return False, f"Тип файла не поддерживается: {ext}"

    ok, size_mb = file_size_ok(src_path)
    if not ok:
        return False, f"Файл слишком большой: {size_mb} МБ (макс {MAX_FILE_SIZE_MB} МБ)"

    if not _looks_like_allowed_content(src_path):
        return False, "Содержимое не соответствует расширению"

    if _total_storage_mb() + size_mb > MAX_TOTAL_STORAGE_MB:
        return False, f"Превышена общая квота ({MAX_TOTAL_STORAGE_MB} МБ)"

    try:
        free_mb = shutil.disk_usage(_data_dir()).free / (1024 * 1024)
        if free_mb < size_mb * 2 + 50:
            return False, "Мало свободного места на диске"
    except OSError:
        pass

    try:
        ext = os.path.splitext(src_path)[1].lower()
        h = _file_hash(src_path)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"{ts}_{h}{ext}"
        dst = os.path.join(_data_dir(), fname)

        counter = 1
        while os.path.exists(dst):
            fname = f"{ts}_{h}_{counter}{ext}"
            dst = os.path.join(_data_dir(), fname)
            counter += 1

        _copy_with_progress(src_path, dst, progress_cb=progress_cb)
        return True, {
            "path": fname,
            "name": _sanitize_name(os.path.basename(src_path)),
            "size": round(size_mb, 2),
            "added": datetime.now().isoformat(),
        }
    except OSError as e:
        logger.error("Ошибка сохранения вложения: %s", e)
        return False, f"Ошибка копирования: {e}"


def get_full_path(relative_name: str) -> str:
    """Безопасно склеивает путь внутри data/attachments/."""
    if not relative_name:
        return ""
    rel = os.path.basename(relative_name)
    return os.path.join(_data_dir(), rel)


def delete_attachment(relative_name: str) -> bool:
    try:
        p = get_full_path(relative_name)
        if p and os.path.exists(p):
            os.remove(p)
            clear_thumbnail_cache()
            return True
    except OSError:
        pass
    return False


def is_image(name: str) -> bool:
    return os.path.splitext(name)[1].lower() in (
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"
    )


def is_video(name: str) -> bool:
    return os.path.splitext(name)[1].lower() in (
        ".mp4", ".avi", ".mkv", ".mov"
    )


def is_audio(name: str) -> bool:
    return os.path.splitext(name)[1].lower() in (
        ".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac"
    )


def open_attachment(relative_name: str) -> bool:
    """Открыть вложение системным приложением (без shell-инъекций)."""
    p = get_full_path(relative_name)
    if not p or not os.path.exists(p):
        return False
    try:
        if sys.platform == "win32":
            os.startfile(p)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", p], check=False)
        else:
            subprocess.run(["xdg-open", p], check=False)
        return True
    except Exception as e:
        logger.error("Ошибка открытия вложения: %s", e)
        return False


def cleanup_orphans(valid_paths: set[str]) -> int:
    """Удаляет файлы, на которые нет ссылок в базе."""
    removed = 0
    try:
        for f in os.listdir(_data_dir()):
            if f not in valid_paths:
                try:
                    os.remove(os.path.join(_data_dir(), f))
                    removed += 1
                except OSError:
                    pass
    except OSError:
        pass
    return removed


@lru_cache(maxsize=128)
def _thumbnail_bytes_cached(relative_name: str, size: tuple[int, int]) -> Optional[bytes]:
    """Декодирует и уменьшает картинку один раз, кэширует PNG-байты.

    Файлы вложений именуются по хэшу содержимого (см. save_attachment),
    поэтому одно и то же имя всегда означает одно и то же содержимое —
    кэшировать по (relative_name, size) безопасно без отслеживания mtime.
    """
    try:
        from PIL import Image
        p = get_full_path(relative_name)
        img = Image.open(p)
        img.thumbnail(size)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return None


def get_thumbnail(relative_name: str, size: tuple[int, int] = (120, 120)):
    """Возвращает PIL.Image thumbnail для картинок или None.

    Само уменьшение картинки кэшируется (см. _thumbnail_bytes_cached),
    но каждый вызов возвращает свежий объект Image, чтобы вызывающий код
    мог безопасно его использовать/закрывать, не деля состояние с кэшем.
    """
    if not is_image(relative_name):
        return None
    data = _thumbnail_bytes_cached(relative_name, tuple(size))
    if data is None:
        return None
    try:
        from PIL import Image
        return Image.open(io.BytesIO(data))
    except Exception:
        return None


def clear_thumbnail_cache() -> None:
    """Сбрасывает кэш миниатюр (например, после удаления вложений)."""
    _thumbnail_bytes_cached.cache_clear()