"""GUI-обвязка апдейтера для Dopamine Assistant.

Вынесено в отдельный модуль, чтобы app.py менялся минимально
(5 маленьких правок вместо сотни строк нового кода).

Публичное API:
    start_background_check(app)      — тихая проверка после входа
    build_update_tab(app, parent)    — раздел админки «Обновление»

Всё, что делает сеть, крутится в daemon-потоке; в GUI возвращаемся
только через app.app.after(0, ...) — так же, как это уже сделано
в _notify_loop в app.py.
"""

import logging
import threading

import customtkinter as ctk
from tkinter import messagebox

import updater

logger = logging.getLogger("update_ui")

# Задержка перед фоновой проверкой, чтобы не тормозить появление окна
STARTUP_DELAY_MS = 4000


# ======================================================================
# Фоновая проверка при старте
# ======================================================================

def start_background_check(app):
    """Тихая проверка обновлений. Ошибки — только в лог, пользователь
    ничего не видит. Плашка показывается, только если обновление есть
    и текущая роль — tech."""
    try:
        if not app.is_tech():
            return
        app.app.after(STARTUP_DELAY_MS, lambda: _spawn_check(app))
    except Exception as e:
        logger.error("Не удалось запланировать проверку обновлений: %s", e)


def _spawn_check(app):
    def worker():
        info = updater.check_for_update()
        updater.cleanup_downloads()
        if info:
            try:
                app.app.after(0, lambda: _show_badge(app, info))
            except Exception:
                pass  # окно уже закрыто

    threading.Thread(target=worker, daemon=True).start()


def _show_badge(app, info):
    """Ненавязчивая кнопка в шапке: «⬆ Обновление 1.3.0»."""
    try:
        parent = getattr(app, "header_right", None)
        if parent is None or not parent.winfo_exists():
            return
        if getattr(app, "_update_badge", None) is not None:
            return
        btn = ctk.CTkButton(
            parent, text=f"⬆  {info.version}",
            font=("Segoe UI", 11, "bold"),
            fg_color="#16a34a", hover_color="#22c55e",
            text_color="#ffffff", corner_radius=10,
            height=36, width=110,
            command=lambda: _open_update_section(app))
        btn.pack(side="left", padx=(0, 8))
        app._update_badge = btn
        app._pending_update = info
        logger.info("Показана плашка обновления %s", info.version)
    except Exception as e:
        logger.error("Плашка обновления не отрисовалась: %s", e)


def _open_update_section(app):
    try:
        if not app.is_admin:
            app.show_page("admin")
        app.show_admin_section("update")
    except Exception as e:
        logger.error("Переход в раздел обновления: %s", e)


# ======================================================================
# Раздел админки
# ======================================================================

def build_update_tab(app, parent):
    box = ctk.CTkFrame(parent, fg_color="transparent")
    box.pack(fill="both", expand=True, padx=18, pady=16)

    ctk.CTkLabel(box, text="⬆️  Обновление приложения",
                 font=("Segoe UI", 16, "bold"),
                 text_color=app_color(app, "ACCENT")).pack(anchor="w",
                                                           pady=(0, 12))

    current = updater.get_current_version()
    repo = updater.get_repo() or "не настроен"
    ctk.CTkLabel(box,
                 text=f"Текущая версия:  {current}\n"
                      f"Репозиторий:  {repo}",
                 font=("Segoe UI", 12), justify="left",
                 text_color=app_color(app, "TEXT")).pack(anchor="w",
                                                         pady=(0, 10))

    status = ctk.CTkLabel(box, text="", font=("Segoe UI", 11),
                          justify="left", wraplength=620,
                          text_color=app_color(app, "TEXT_DIM"))
    status.pack(anchor="w", pady=(0, 8))

    bar = ctk.CTkProgressBar(box, width=440, height=12,
                             progress_color=app_color(app, "ACCENT"))
    bar.set(0)

    notes = ctk.CTkTextbox(box, height=180, width=640,
                           font=("Consolas", 11), wrap="word",
                           fg_color=app_color(app, "CARD"),
                           text_color=app_color(app, "TEXT"),
                           corner_radius=10)

    row = ctk.CTkFrame(box, fg_color="transparent")
    row.pack(anchor="w", pady=(12, 0))

    state = {"info": getattr(app, "_pending_update", None), "busy": False}

    # ---------------- проверка ----------------
    def do_check():
        if state["busy"]:
            return
        state["busy"] = True
        btn_check.configure(state="disabled", text="Проверяю…")
        btn_install.configure(state="disabled")
        status.configure(text="Связываюсь с GitHub…")

        def worker():
            info = updater.check_for_update()
            app.app.after(0, lambda: finish(info))

        def finish(info):
            state["busy"] = False
            state["info"] = info
            btn_check.configure(state="normal", text="🔄  Проверить обновления")
            if info is None:
                status.configure(
                    text=f"У вас последняя версия ({current}).\n"
                         "Если ждали обновление — смотрите data/logs/error.log, "
                         "там причина (нет сети или релиз не опубликован).")
                notes.pack_forget()
                return
            kinds = ", ".join(sorted({i.kind for i in info.items}))
            mb = info.total_size / (1024 * 1024)
            status.configure(
                text=f"Доступна версия {info.version} "
                     f"(содержимое: {kinds}, {mb:.1f} МБ).")
            notes.pack(anchor="w", pady=(8, 0))
            notes.configure(state="normal")
            notes.delete("1.0", "end")
            notes.insert("1.0", info.notes or "(описание релиза пустое)")
            notes.configure(state="disabled")
            btn_install.configure(state="normal")

        threading.Thread(target=worker, daemon=True).start()

    # ---------------- установка ----------------
    def do_install():
        info = state["info"]
        if not info or state["busy"]:
            return
        msg = (f"Установить версию {info.version}?\n\n"
               "Папка data/ (база знаний, пользователи, тикеты) "
               "не пострадает — перед заменой будет создан бэкап.")
        if info.has_app:
            msg += "\n\nПриложение закроется и откроется заново автоматически."
        if not messagebox.askyesno("Обновление", msg):
            return

        state["busy"] = True
        btn_check.configure(state="disabled")
        btn_install.configure(state="disabled", text="Обновляю…")
        bar.pack(anchor="w", pady=(10, 0))
        bar.set(0)

        def progress(done, total):
            frac = (done / total) if total else 0
            app.app.after(0, lambda: bar.set(min(frac, 1.0)))

        def worker():
            restart_needed = False
            for item in info.items:
                app.app.after(0, lambda n=item.name: status.configure(
                    text=f"Скачиваю {n}…"))
                path = updater.download_item(item, progress_cb=progress)
                if not path:
                    app.app.after(0, lambda n=item.name: fail(
                        f"Не удалось скачать {n}. Подробности в "
                        "data/logs/error.log. Приложение продолжает "
                        "работать на старой версии."))
                    return
                if item.kind == "data":
                    app.app.after(0, lambda: status.configure(
                        text="Применяю обновление базы…"))
                    if not updater.apply_data_update(path):
                        app.app.after(0, lambda: fail(
                            "Обновление базы не применилось, изменения "
                            "откачены. Смотрите лог."))
                        return
                    restart_needed = True
                else:
                    app.app.after(0, lambda: status.configure(
                        text="Готовлю замену файлов…"))
                    if not updater.apply_app_update(path):
                        app.app.after(0, lambda: fail(
                            "Установка не запустилась. Старая версия "
                            "осталась рабочей, смотрите лог."))
                        return
                    app.app.after(0, close_for_update)
                    return
            app.app.after(0, lambda: done_data(restart_needed))

        def fail(text):
            state["busy"] = False
            bar.pack_forget()
            btn_check.configure(state="normal")
            btn_install.configure(state="normal", text="⬇️  Скачать и установить")
            status.configure(text="⚠️  " + text)

        def done_data(restart_needed):
            state["busy"] = False
            bar.pack_forget()
            btn_check.configure(state="normal")
            btn_install.configure(state="disabled",
                                  text="⬇️  Скачать и установить")
            status.configure(text="✅ Обновление применено.")
            if restart_needed and messagebox.askyesno(
                    "Перезапуск",
                    "Данные обновлены. Перезапустить приложение сейчас?"):
                updater.restart_app()
                app.on_close()

        def close_for_update():
            status.configure(text="Закрываю приложение для установки…")
            try:
                app.on_close()
            except Exception as e:
                logger.error("Закрытие перед обновлением: %s", e)

        threading.Thread(target=worker, daemon=True).start()

    btn_check = app._accent_button(row, "🔄  Проверить обновления",
                                   command=do_check, width=240, height=44)
    btn_check.pack(side="left", padx=(0, 10))

    btn_install = app._accent_button(row, "⬇️  Скачать и установить",
                                     command=do_install, width=240, height=44)
    btn_install.configure(state="disabled")
    btn_install.pack(side="left")

    # ---------------- ярлык и автозапуск ----------------
    try:
        import shortcuts
    except Exception as e:
        logger.warning("Модуль shortcuts недоступен: %s", e)
        shortcuts = None

    if shortcuts and shortcuts.AVAILABLE:
        sc_box = ctk.CTkFrame(box, fg_color="transparent")
        sc_box.pack(anchor="w", pady=(24, 0), fill="x")
        ctk.CTkLabel(sc_box, text="Ярлык и автозапуск",
                     font=("Segoe UI", 13, "bold"),
                     text_color=app_color(app, "TEXT")).pack(anchor="w")

        sc_status = ctk.CTkLabel(sc_box, text="", font=("Segoe UI", 10),
                                 text_color=app_color(app, "TEXT_DIM"))
        sc_status.pack(anchor="w", pady=(4, 6))

        sc_row = ctk.CTkFrame(sc_box, fg_color="transparent")
        sc_row.pack(anchor="w")

        def mk_shortcut():
            ok, msg = shortcuts.create_desktop_shortcut()
            sc_status.configure(text=("✅ " if ok else "⚠️ ") + msg)

        def toggle_autostart():
            enabled = shortcuts.is_autostart_enabled()
            ok, msg = shortcuts.set_autostart(not enabled)
            sc_status.configure(text=("✅ " if ok else "⚠️ ") + msg)
            refresh_autostart_btn()

        def refresh_autostart_btn():
            on = shortcuts.is_autostart_enabled()
            btn_auto.configure(text=("🚫  Убрать из автозапуска" if on
                                     else "🚀  Добавить в автозапуск"))

        app._ghost_button(sc_row, "🖥  Ярлык на рабочий стол",
                          command=mk_shortcut, width=230,
                          height=40).pack(side="left", padx=(0, 10))
        btn_auto = app._ghost_button(sc_row, "🚀  Добавить в автозапуск",
                                     command=toggle_autostart, width=230,
                                     height=40)
        btn_auto.pack(side="left")
        refresh_autostart_btn()

    # Если фоновая проверка уже нашла обновление — сразу показываем его
    if state["info"] is not None:
        info = state["info"]
        status.configure(text=f"Доступна версия {info.version}.")
        notes.pack(anchor="w", pady=(8, 0))
        notes.insert("1.0", info.notes or "(описание релиза пустое)")
        notes.configure(state="disabled")
        btn_install.configure(state="normal")


def app_color(app, key):
    """Берёт цвет текущей темы из app.py, не завязываясь на глобалки."""
    try:
        import sys
        # app.py запущен как __main__ — повторно его импортировать НЕЛЬЗЯ
        # (модуль выполнится второй раз). Берём уже загруженный объект.
        m = sys.modules.get("app") or sys.modules.get("__main__")
        palette = m.DARK if m.theme_mgr.theme == "dark" else m.LIGHT
        return palette[key]
    except Exception:
        return {"ACCENT": "#ff8a1e", "TEXT": "#f0f0f2", "TEXT_DIM": "#a0a2a8",
                "TEXT_MUTED": "#6a6d75", "CARD": "#23252c"}.get(key, "#f0f0f2")
