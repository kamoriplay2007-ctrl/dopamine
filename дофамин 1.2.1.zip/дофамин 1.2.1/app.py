import customtkinter as ctk
from tkinter import messagebox, filedialog
import tkinter as tk
import pickle
import os
import json
import csv
import shutil
import re
import hashlib
import difflib
import threading
import time
import traceback
import sys
import webbrowser
import logging
from logging.handlers import RotatingFileHandler
import secrets as _secrets
from datetime import datetime, timedelta

# ===== ДОПОЛНИТЕЛЬНЫЕ БИБЛИОТЕКИ =====
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas as pdf_canvas
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    HAS_REPORTLAB = True
except Exception:
    HAS_REPORTLAB = False

try:
    from pypdf import PdfReader
    HAS_PYPDF = True
except Exception:
    try:
        from PyPDF2 import PdfReader
        HAS_PYPDF = True
    except Exception:
        HAS_PYPDF = False

try:
    import qrcode
    from PIL import Image
    HAS_QR = True
except Exception:
    HAS_QR = False

try:
    import attachments
    HAS_ATTACHMENTS = True
except Exception as _e:
    HAS_ATTACHMENTS = False
    print("attachments module FAIL:", _e)
try:
    from ai_client import ai_client
    HAS_AI = True
except Exception as _e:
    HAS_AI = False
    ai_client = None
    print("ai_client module FAIL:", _e)
try:
    import updater
    import update_ui
    HAS_UPDATER = True
except Exception as _e:
    HAS_UPDATER = False
    updater = None
    update_ui = None
    print("updater module FAIL:", _e)

ctk.set_default_color_theme("dark-blue")

DARK = {
    "BG": "#0f0f11", "PANEL": "#17181c", "PANEL_LIGHT": "#1e2026",
    "CARD": "#23252c", "CARD_HOVER": "#2d3038", "CODE_BG": "#0a0b0d",
    "ACCENT": "#ff8a1e", "ACCENT_HOVER": "#ffa947", "ACCENT_DARK": "#cc6a10",
    "TEXT": "#f0f0f2", "TEXT_DIM": "#a0a2a8", "TEXT_MUTED": "#6a6d75",
    "BOT_NAME": "#ff8a1e", "USER_NAME": "#ffc27a",
    "SUCCESS": "#4ade80", "ERROR": "#f87171",
    "DANGER": "#b91c1c", "DANGER_HOVER": "#dc2626",
    "BORDER": "#2a2c34", "CODE_TEXT": "#7ee787",
    "ON_ACCENT": "#0f0f11",
    "EMERG_BG": "#2a1518", "EMERG_HOVER": "#3d1e22",
    "SIDEBAR": "#0a0b0d", "SIDEBAR_HOVER": "#1e2026",
    "SIDEBAR_ACTIVE": "#2d3038",
}
LIGHT = {
    "BG": "#f6f6f8", "PANEL": "#ffffff", "PANEL_LIGHT": "#eef0f3",
    "CARD": "#f9fafb", "CARD_HOVER": "#e9edf2", "CODE_BG": "#1e2026",
    "ACCENT": "#e87a0c", "ACCENT_HOVER": "#ff9a2e", "ACCENT_DARK": "#b85f00",
    "TEXT": "#0f1115", "TEXT_DIM": "#4a4d55", "TEXT_MUTED": "#888b93",
    "BOT_NAME": "#c96a00", "USER_NAME": "#8a5a1a",
    "SUCCESS": "#16a34a", "ERROR": "#dc2626",
    "DANGER": "#b91c1c", "DANGER_HOVER": "#dc2626",
    "BORDER": "#d5d8de", "CODE_TEXT": "#7ee787",
    "ON_ACCENT": "#ffffff",
    "EMERG_BG": "#fee2e2", "EMERG_HOVER": "#fecaca",
    "SIDEBAR": "#ffffff", "SIDEBAR_HOVER": "#eef0f3",
    "SIDEBAR_ACTIVE": "#e5e7eb",
}

COLOR_BG = DARK["BG"]; COLOR_PANEL = DARK["PANEL"]; COLOR_PANEL_LIGHT = DARK["PANEL_LIGHT"]
COLOR_CARD = DARK["CARD"]; COLOR_CARD_HOVER = DARK["CARD_HOVER"]; COLOR_CODE_BG = DARK["CODE_BG"]
COLOR_ACCENT = DARK["ACCENT"]; COLOR_ACCENT_HOVER = DARK["ACCENT_HOVER"]; COLOR_ACCENT_DARK = DARK["ACCENT_DARK"]
COLOR_TEXT = DARK["TEXT"]; COLOR_TEXT_DIM = DARK["TEXT_DIM"]; COLOR_TEXT_MUTED = DARK["TEXT_MUTED"]
COLOR_BOT_NAME = DARK["BOT_NAME"]; COLOR_USER_NAME = DARK["USER_NAME"]
COLOR_SUCCESS = DARK["SUCCESS"]; COLOR_ERROR = DARK["ERROR"]
COLOR_DANGER = DARK["DANGER"]; COLOR_DANGER_HOVER = DARK["DANGER_HOVER"]
COLOR_BORDER = DARK["BORDER"]; COLOR_CODE_TEXT = DARK["CODE_TEXT"]; COLOR_ON_ACCENT = DARK["ON_ACCENT"]
COLOR_EMERG_BG = DARK["EMERG_BG"]; COLOR_EMERG_HOVER = DARK["EMERG_HOVER"]
COLOR_SIDEBAR = DARK["SIDEBAR"]; COLOR_SIDEBAR_HOVER = DARK["SIDEBAR_HOVER"]
COLOR_SIDEBAR_ACTIVE = DARK["SIDEBAR_ACTIVE"]

TOP_K_RESULTS = 5
MAX_LINES_IN_CHAT = 2000
MIN_LOGIN_LENGTH = 4; MAX_LOGIN_LENGTH = 20
MIN_PASSWORD_LENGTH = 4; MAX_PASSWORD_LENGTH = 20
TICKET_STALE_HOURS = 24
FUZZY_THRESHOLD = 0.6
FUZZY_MAX_CHUNKS = 1000
TICKET_NOTIFY_INTERVAL = 3
AUTOCOMPLETE_DEBOUNCE_MS = 300
MAX_BACKUPS = 10
AUTO_THEME_DAY_START = 7
AUTO_THEME_NIGHT_START = 19

DRAFT_FILE = os.path.join("data", "draft.txt")
RATINGS_FILE = os.path.join("data", "ratings.pkl")
TICKETS_FILE = os.path.join("data", "tickets.pkl")
TICKETS_ARCHIVE_FILE = os.path.join("data", "tickets_archive.pkl")
SUGGESTIONS_FILE = os.path.join("data", "suggestions.pkl")
USERS_FILE = os.path.join("data", "users.pkl")
JOURNAL_FILE = os.path.join("data", "journal.pkl")
THEME_FILE = os.path.join("data", "theme.pkl")
SYNONYMS_FILE = os.path.join("data", "synonyms.csv")
STOP_WORDS_FILE = os.path.join("data", "stop_words.csv")

if getattr(sys, 'frozen', False):
    APP_PATH = os.path.dirname(sys.executable)
else:
    APP_PATH = os.path.dirname(os.path.abspath(__file__))

DATA_DIR = os.path.join(APP_PATH, "data"); os.makedirs(DATA_DIR, exist_ok=True)
LOG_DIR = os.path.join(DATA_DIR, "logs"); os.makedirs(LOG_DIR, exist_ok=True)
BACKUP_DIR = os.path.join(DATA_DIR, "backups"); os.makedirs(BACKUP_DIR, exist_ok=True)

# === ИСПРАВЛЕНИЕ: пути к данным должны быть абсолютными ===
# Выше они объявлены как os.path.join("data", ...) — относительно
# ТЕКУЩЕЙ РАБОЧЕЙ ПАПКИ. Если приложение запустить из ярлыка, службы
# или из автозагрузки, CWD будет чужой, и появится
# FileNotFoundError: 'data\\synonyms.csv' (см. error.log от 14.09).
# Перепривязываем их к DATA_DIR — теперь путь зависит только от
# расположения exe/app.py.
DRAFT_FILE           = os.path.join(DATA_DIR, "draft.txt")
RATINGS_FILE         = os.path.join(DATA_DIR, "ratings.pkl")
TICKETS_FILE         = os.path.join(DATA_DIR, "tickets.pkl")
TICKETS_ARCHIVE_FILE = os.path.join(DATA_DIR, "tickets_archive.pkl")
SUGGESTIONS_FILE     = os.path.join(DATA_DIR, "suggestions.pkl")
USERS_FILE           = os.path.join(DATA_DIR, "users.pkl")
JOURNAL_FILE         = os.path.join(DATA_DIR, "journal.pkl")
THEME_FILE           = os.path.join(DATA_DIR, "theme.pkl")
SYNONYMS_FILE        = os.path.join(DATA_DIR, "synonyms.csv")
STOP_WORDS_FILE      = os.path.join(DATA_DIR, "stop_words.csv")
LOG_FILE = os.path.join(LOG_DIR, "error.log")
LOG_MAX_SIZE = 5 * 1024 * 1024
LOG_BACKUPS = 3

BASE_QUESTIONS_FILE = os.path.join(APP_PATH, "base_questions.json")


def _setup_logging():
    root = logging.getLogger()
    if root.handlers:
        return
    root.setLevel(logging.INFO)
    handler = RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_SIZE, backupCount=LOG_BACKUPS,
        encoding="utf-8",
    )
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(fmt)
    root.addHandler(handler)


_setup_logging()
logger = logging.getLogger("dopamine")


def log_error(exc, context=""):
    """Логирует исключение через logging (с traceback)."""
    logger.error("%s: %s", context or "error", exc,
                 exc_info=(type(exc), exc, exc.__traceback__))


def log_info(msg):
    logger.info(msg)


def atomic_pickle_dump(path, obj):
    """Безопасная (атомарная) запись pickle-файла.

    Пишет во временный файл рядом с целевым и только при успехе
    подменяет им оригинал через os.replace (атомарно и на Windows,
    и на POSIX). Если процесс упадёт или пропадёт питание посреди
    записи — старый файл БД останется целым, а не превратится
    в битый pickle, который тихо обнулит всю базу при следующей
    загрузке.
    """
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp_path = None, None
    try:
        import tempfile
        fd, tmp_path = tempfile.mkstemp(prefix=".tmp_", suffix=".pkl", dir=d)
        with os.fdopen(fd, "wb") as f:
            fd = None  # fdopen закрыл дескриптор, повторно закрывать не нужно
            pickle.dump(obj, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        tmp_path = None
        return True
    except Exception as e:
        log_error(e, f"atomic_pickle_dump({path})")
        return False
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def make_auto_backup():
    try:
        src = os.path.join(DATA_DIR, "knowledge.pkl")
        if not os.path.exists(src):
            return
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dst = os.path.join(BACKUP_DIR, f"auto_{ts}.pkl")
        shutil.copy(src, dst)
        backups = sorted([f for f in os.listdir(BACKUP_DIR)
                          if f.startswith("auto_") and f.endswith(".pkl")])
        while len(backups) > MAX_BACKUPS:
            old = os.path.join(BACKUP_DIR, backups.pop(0))
            try:
                os.remove(old)
            except Exception:
                pass
        log_info(f"Автобэкап создан: {dst}")
    except Exception as e:
        log_error(e, "make_auto_backup")


def _load_base_questions() -> list:
    """Загружает стартовые вопросы из base_questions.json."""
    if not os.path.exists(BASE_QUESTIONS_FILE):
        logger.warning("base_questions.json не найден: %s", BASE_QUESTIONS_FILE)
        return []
    try:
        with open(BASE_QUESTIONS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            logger.error("base_questions.json: ожидался массив объектов")
            return []
        valid = []
        for item in data:
            if not isinstance(item, dict):
                continue
            q = str(item.get("question", "")).strip()
            a = str(item.get("answer", "")).strip()
            if not q or not a:
                continue
            valid.append({
                "question": q,
                "answer": a,
                "category": str(item.get("category", "общие")).strip() or "общие",
                "difficulty": str(item.get("difficulty", "easy")).strip() or "easy",
                "tags": [str(t).strip() for t in item.get("tags", []) if str(t).strip()],
            })
        logger.info("Загружено базовых вопросов: %d", len(valid))
        return valid
    except Exception as e:
        log_error(e, "load_base_questions")
        return []


BASE_QUESTIONS = _load_base_questions()

TICKET_STATUSES = {
    "new":         {"name": "🆕 Новый",     "color": "#ff8a1e", "order": 1},
    "in_progress": {"name": "⚙️ В работе",   "color": "#fbbf24", "order": 2},
    "waiting":     {"name": "⏳ Ожидание",   "color": "#a78bfa", "order": 3},
    "resolved":    {"name": "✅ Решён",      "color": "#4ade80", "order": 4},
    "closed":      {"name": "🔒 Закрыт",     "color": "#6a6d75", "order": 5},
}
TICKET_PRIORITIES = {
    "low":      {"name": "🟢 Низкий",    "color": "#4ade80", "order": 1},
    "medium":   {"name": "🟡 Средний",   "color": "#ff8a1e", "order": 2},
    "high":     {"name": "🟠 Высокий",   "color": "#f97316", "order": 3},
    "critical": {"name": "🔴 Критичный", "color": "#dc2626", "order": 4},
}
PERMISSIONS = {
    "tickets":     {"name": "🚨  Тикеты",           "icon": "🚨"},
    "archive":     {"name": "📦  Архив",            "icon": "📦"},
    "suggestions": {"name": "✍️  Предложения",      "icon": "✍️"},
    "add":         {"name": "➕  Добавить",          "icon": "➕"},
    "edit":        {"name": "✏️  Редактировать",     "icon": "✏️"},
    "import":      {"name": "📥  Импорт файлов",     "icon": "📥"},
    "dictionary":  {"name": "📖  Словари",          "icon": "📖"},
    "langame":     {"name": "📚  LANGame",         "icon": "📚"},
    "tags":        {"name": "🏷️  Теги",             "icon": "🏷️"},
    "stats":       {"name": "📊  Аналитика",         "icon": "📊"},
    "journal":     {"name": "📝  Журнал",           "icon": "📝"},
    "io":          {"name": "💾  Экспорт / Бэкап",   "icon": "💾"},
}

# Категории LANGame по макету
LANGAME_CATEGORIES = ["Оборудование", "ПО", "Игры", "Античиты", "Сеть"]

MD_LINK_PATTERN = re.compile(r"\[([^\]\n]+?)\]\((https?://[^\s\)]+?)\)")


def extract_links(text):
    out = []
    for m in MD_LINK_PATTERN.finditer(text):
        out.append((m.start(), m.end(), m.group(1), m.group(2)))
    return out


def strip_md_links(text):
    return MD_LINK_PATTERN.sub(r"\1 (\2)", text)


def open_url(url):
    try:
        webbrowser.open(url, new=2)
    except Exception as e:
        log_error(e, "open_url")


def hash_password(password: str, salt: str | None = None) -> str:
    """PBKDF2-HMAC-SHA256, 200 000 итераций.
    Возвращает строку вида 'salt$hash'."""
    if salt is None:
        salt = _secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("ascii"),
        200_000,
    )
    return f"{salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Проверка пароля. Поддерживает старый SHA-256 без соли."""
    if not stored:
        return False
    if "$" in stored:
        salt, _ = stored.split("$", 1)
        return _secrets.compare_digest(hash_password(password, salt), stored)
    legacy = hashlib.sha256(password.encode("utf-8")).hexdigest()
    return _secrets.compare_digest(legacy, stored)


def normalize_text(s):
    if not s:
        return ""
    s = s.lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def chunk_to_qa(chunk):
    if not chunk:
        return "", ""
    if "Вопрос:" in chunk and "Ответ:" in chunk:
        parts = chunk.split("Ответ:", 1)
        q = parts[0].replace("Вопрос:", "").strip()
        a = parts[1].strip() if len(parts) > 1 else ""
        return q, a
    return chunk.strip(), chunk.strip()


def format_duration(seconds):
    if seconds < 60:
        return f"{int(seconds)}с"
    minutes = int(seconds / 60)
    if minutes < 60:
        return f"{minutes}м"
    hours = minutes // 60
    mins = minutes % 60
    if mins == 0:
        return f"{hours}ч"
    return f"{hours}ч {mins}м"


def open_file_in_default_app(path):
    try:
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}"')
        return True
    except Exception as e:
        log_error(e, "open_file_in_default_app")
        return False


class Dictionaries:
    def __init__(self):
        self.synonyms = {}
        self.stop_words = set()
        self.load()

    def load(self):
        self.synonyms = {}
        self.stop_words = set()
        try:
            if not os.path.exists(SYNONYMS_FILE):
                self._create_synonyms_template()
            if not os.path.exists(STOP_WORDS_FILE):
                self._create_stop_words_template()
            self._load_synonyms()
            self._load_stop_words()
        except Exception as e:
            log_error(e, "Dictionaries.load")

    def _create_synonyms_template(self):
        try:
            with open(SYNONYMS_FILE, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f)
                w.writerow(["Основное слово", "Синонимы (через запятую)"])
                w.writerow(["мышь", "мышка, мыш, mouse"])
                w.writerow(["стим", "steam, стим"])
                w.writerow(["винда", "windows, виндовс, ос"])
                w.writerow(["не работает", "не робит, сломалось, не пашет, барахлит"])
                w.writerow(["микрофон", "микро, mic, мик"])
                w.writerow(["наушники", "уши, headphones, наушник"])
                w.writerow(["клавиатура", "клава, keyboard, kb"])
                w.writerow(["игра", "игрушка, game"])
        except Exception as e:
            log_error(e, "create_synonyms_template")

    def _create_stop_words_template(self):
        try:
            with open(STOP_WORDS_FILE, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f)
                w.writerow(["Стоп-слово"])
                for word in ["как", "что", "делать", "мне", "плиз",
                             "пожалуйста", "подскажите", "помогите",
                             "можно", "ли", "а", "в", "на", "с", "и"]:
                    w.writerow([word])
        except Exception as e:
            log_error(e, "create_stop_words_template")

    def _load_synonyms(self):
        try:
            with open(SYNONYMS_FILE, "r", encoding="utf-8-sig", newline="") as f:
                rows = list(csv.reader(f))
            for row in rows[1:]:
                if len(row) < 2:
                    continue
                main = row[0].strip().lower()
                syns_raw = row[1].strip()
                if not main or not syns_raw:
                    continue
                syns = [s.strip().lower() for s in syns_raw.split(",") if s.strip()]
                all_forms = set([main] + syns)
                for word in all_forms:
                    self.synonyms.setdefault(word, set()).update(all_forms)
        except Exception as e:
            log_error(e, "load_synonyms")

    def _load_stop_words(self):
        try:
            with open(STOP_WORDS_FILE, "r", encoding="utf-8-sig", newline="") as f:
                rows = list(csv.reader(f))
            for row in rows[1:]:
                if not row:
                    continue
                word = row[0].strip().lower()
                if word:
                    self.stop_words.add(word)
        except Exception as e:
            log_error(e, "load_stop_words")

    def expand_words(self, words):
        out = set()
        for w in words:
            out.add(w)
            if w in self.synonyms:
                out.update(self.synonyms[w])
        return out

    def clean_stop_words(self, words):
        cleaned = [w for w in words if w not in self.stop_words and len(w) >= 2]
        return cleaned if cleaned else words

    def reload(self):
        self.load()
        return True


dictionaries = Dictionaries()


class KnowledgeBase:
    def get_by_source(self, source):
        return [(i, self.chunks[i], self.metadata[i])
            for i in range(len(self.chunks))
            if i < len(self.metadata)
            and self.metadata[i].get("source") == source]
    def __init__(self):
        self.chunks = []
        self.metadata = []
        self.difficulty = []
        self.categories = set()
        self._lower_chunks = []
        self.search_history = []
        self.ratings = {}
        self.all_tags = set()
        self.load()
        self._normalize_lengths()

    def _normalize_lengths(self):
        n = len(self.chunks)
        while len(self.metadata) < n:
            self.metadata.append({"category": "общие", "added": datetime.now().isoformat(),
                                  "tags": [], "views": 0, "source": "base",
                                  "attachments": []})
        while len(self.difficulty) < n:
            self.difficulty.append("easy")
        if len(self.metadata) > n:
            self.metadata = self.metadata[:n]
        if len(self.difficulty) > n:
            self.difficulty = self.difficulty[:n]
        if len(self._lower_chunks) != n:
            self._lower_chunks = [normalize_text(c) for c in self.chunks]
        for m in self.metadata:
            if "tags" not in m: m["tags"] = []
            if "views" not in m: m["views"] = 0
            if "source" not in m: m["source"] = "base"
            if "category" not in m: m["category"] = "общие"
            if "attachments" not in m: m["attachments"] = []
        self._rebuild_tags()

    def _rebuild_tags(self):
        self.all_tags = set()
        for m in self.metadata:
            for t in m.get("tags", []):
                t = t.lower().strip()
                if t: self.all_tags.add(t)

    def load(self):
        path = os.path.join(DATA_DIR, "knowledge.pkl")
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    data = pickle.load(f)
                    if len(data) == 4:
                        self.chunks, self.metadata, self.difficulty, self.categories = data
                        self._lower_chunks = [normalize_text(c) for c in self.chunks]
            except Exception as e:
                log_error(e, "KnowledgeBase.load")
        hist_path = os.path.join(DATA_DIR, "history.pkl")
        if os.path.exists(hist_path):
            try:
                with open(hist_path, "rb") as f:
                    self.search_history = pickle.load(f)
            except Exception as e:
                log_error(e, "load_history")
                self.search_history = []
        rating_path = os.path.join(DATA_DIR, "ratings.pkl")
        if os.path.exists(rating_path):
            try:
                with open(rating_path, "rb") as f:
                    self.ratings = pickle.load(f)
            except Exception as e:
                log_error(e, "load_ratings")
                self.ratings = {}

    def save_history(self):
        atomic_pickle_dump(os.path.join(DATA_DIR, "history.pkl"),
                            self.search_history[-2000:])

    def save_ratings(self):
        atomic_pickle_dump(RATINGS_FILE, self.ratings)

    def rate(self, query, helpful):
        key = query.strip().lower()
        if not key or len(key) < 2: return
        if key not in self.ratings: self.ratings[key] = {"up": 0, "down": 0}
        if helpful: self.ratings[key]["up"] += 1
        else: self.ratings[key]["down"] += 1
        self.save_ratings()

    def log_search(self, query, found):
        q = query.strip()
        if not q or len(q) < 2: return
        self.search_history.append({"query": q, "found": found, "time": datetime.now().isoformat()})
        if len(self.search_history) > 2000:
            self.search_history = self.search_history[-2000:]
        self.save_history()

    def get_top_queries(self, limit=20):
        stats = {}
        for entry in self.search_history:
            q = entry["query"].lower().strip()
            if not q or len(q) < 2: continue
            if q not in stats: stats[q] = {"count": 0, "found": 0}
            stats[q]["count"] += 1
            if entry["found"]: stats[q]["found"] += 1
        return [(q, v["count"], v["found"]) for q, v in
                sorted(stats.items(), key=lambda x: x[1]["count"], reverse=True)[:limit]]

    def get_failed_queries(self, limit=50):
        failed = {}
        for entry in self.search_history:
            if not entry["found"]:
                q = entry["query"].strip().lower()
                if not q or len(q) < 2: continue
                failed[q] = failed.get(q, 0) + 1
        return sorted(failed.items(), key=lambda x: x[1], reverse=True)[:limit]

    def get_recent_unique(self, limit=5):
        seen = []
        for entry in reversed(self.search_history):
            q = entry["query"].strip()
            if q and len(q) >= 2 and q not in seen:
                seen.append(q)
                if len(seen) >= limit: break
        return seen

    def get_top_viewed(self, limit=10, source=None):
        items = []
        for i, m in enumerate(self.metadata):
            if source and m.get("source") != source: continue
            items.append((i, m.get("views", 0)))
        items.sort(key=lambda x: x[1], reverse=True)
        return [(i, v) for i, v in items[:limit] if v > 0]

    def clear_history(self):
        self.search_history = []
        self.save_history()

    def search(self, query, top_k=TOP_K_RESULTS, source="base"):
        if not query or not self.chunks: return []
        norm_query = normalize_text(query)
        if not norm_query: return []
        candidates = []
        for i, m in enumerate(self.metadata):
            if source == "base":
                if m.get("source") == "langame": continue
            elif source == "langame":
                if m.get("source") != "langame": continue
            candidates.append(i)
        raw_words = norm_query.split()
        raw_words = dictionaries.clean_stop_words(raw_words)
        expanded = dictionaries.expand_words(raw_words)
        q_words = [w for w in expanded if len(w) >= 2]
        if not q_words: q_words = list(expanded)
        results = []
        for i in candidates:
            chunk_norm = self._lower_chunks[i] if i < len(self._lower_chunks) else ""
            if not chunk_norm: continue
            matches = 0
            tags = self.metadata[i].get("tags", [])
            tag_norm = set(t.lower().strip() for t in tags if t)
            tag_boost = 0
            for w in q_words:
                if w in tag_norm: tag_boost += 2
            for word in q_words:
                if word in chunk_norm: matches += 1
                elif len(word) >= 4:
                    for chunk_word in chunk_norm.split():
                        if chunk_word.startswith(word[:4]):
                            matches += 0.5
                            break
            total = matches + tag_boost
            if total > 0:
                results.append({"text": self.chunks[i], "difficulty": self.difficulty[i],
                                "similarity": total / max(1, len(q_words)), "index": i})
        results.sort(key=lambda x: x["similarity"], reverse=True)
        if results: return results[:top_k]
        return self._fuzzy_search(norm_query, top_k, candidates)

    def _fuzzy_search(self, query, top_k, candidates):
        if not candidates: return []
        max_check = min(len(candidates), FUZZY_MAX_CHUNKS)
        scored = []
        q_norm = query.strip()
        for j in range(max_check):
            i = candidates[j]
            chunk = self.chunks[i]
            q_part = chunk.split("Ответ:")[0].replace("Вопрос:", "").strip().lower() \
                     if "Вопрос:" in chunk else chunk.lower()
            ratio1 = difflib.SequenceMatcher(None, q_norm, q_part).ratio()
            ratio2 = difflib.SequenceMatcher(None, q_norm, self._lower_chunks[i]).ratio()
            best = max(ratio1, ratio2)
            if best >= FUZZY_THRESHOLD:
                scored.append((best, i))
        scored.sort(reverse=True)
        out = []
        for score, i in scored[:top_k]:
            out.append({"text": self.chunks[i], "difficulty": self.difficulty[i],
                        "similarity": score, "index": i, "fuzzy": True})
        return out

    def add_text(self, text, category="общие", difficulty="medium", tags=None,
                 source="base", attachments=None):
        self.chunks.append(text)
        self._lower_chunks.append(normalize_text(text))
        self.difficulty.append(difficulty)
        self.metadata.append({"category": category, "added": datetime.now().isoformat(),
                              "tags": list(tags or []), "views": 0, "source": source,
                              "attachments": list(attachments or [])})
        self.categories.add(category)
        for t in (tags or []):
            self.all_tags.add(t.lower().strip())
        self.save()
        return True

    def increment_views(self, index):
        if 0 <= index < len(self.metadata):
            self.metadata[index]["views"] = self.metadata[index].get("views", 0) + 1
            self.save()
            return self.metadata[index]["views"]
        return 0

    def add_attachment(self, index, attachment):
        if 0 <= index < len(self.metadata):
            if "attachments" not in self.metadata[index]:
                self.metadata[index]["attachments"] = []
            self.metadata[index]["attachments"].append(attachment)
            self.save()
            return True
        return False

    def get_attachments(self, index):
        if 0 <= index < len(self.metadata):
            return list(self.metadata[index].get("attachments", []))
        return []

    def remove_attachment(self, index, attachment_path):
        if 0 <= index < len(self.metadata):
            atts = self.metadata[index].get("attachments", [])
            self.metadata[index]["attachments"] = [
                a for a in atts if a.get("path") != attachment_path
            ]
            self.save()
            return True
        return False

    def question_exists(self, question, source=None):
        q_norm = normalize_text(question)
        if not q_norm: return False
        for i, chunk in enumerate(self.chunks):
            if source is not None:
                m = self.metadata[i] if i < len(self.metadata) else {}
                if m.get("source") != source: continue
            if "Вопрос:" in chunk:
                q = chunk.split("Ответ:")[0].replace("Вопрос:", "").strip()
                if normalize_text(q) == q_norm: return True
        return False

    def update_text(self, index, new_text, new_cat=None, new_diff=None, new_tags=None):
        if 0 <= index < len(self.chunks):
            self.chunks[index] = new_text
            self._lower_chunks[index] = normalize_text(new_text)
            if new_diff: self.difficulty[index] = new_diff
            if new_cat:
                self.metadata[index]["category"] = new_cat
                self.categories = set(m["category"] for m in self.metadata)
            if new_tags is not None:
                self.metadata[index]["tags"] = list(new_tags)
                self._rebuild_tags()
            self.save()
            return True
        return False

    def delete_by_index(self, index):
        if 0 <= index < len(self.chunks):
            del self.chunks[index]
            del self._lower_chunks[index]
            del self.metadata[index]
            del self.difficulty[index]
            self.categories = set(m["category"] for m in self.metadata)
            self._rebuild_tags()
            self.save()
            return True
        return False

    def save(self):
        atomic_pickle_dump(
            os.path.join(DATA_DIR, "knowledge.pkl"),
            (self.chunks, self.metadata, self.difficulty, self.categories))

    def export_json(self, filepath):
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump({"chunks": self.chunks, "metadata": self.metadata,
                       "difficulty": self.difficulty, "categories": list(self.categories)},
                      f, ensure_ascii=False, indent=2)

    def import_json(self, filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.chunks = data["chunks"]
        self.metadata = data["metadata"]
        self.difficulty = data["difficulty"]
        self.categories = set(data.get("categories", []))
        self._lower_chunks = [normalize_text(c) for c in self.chunks]
        self._normalize_lengths()
        self.save()

    def backup(self):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(BACKUP_DIR, f"manual_{ts}.pkl")
        src = os.path.join(DATA_DIR, "knowledge.pkl")
        if os.path.exists(src):
            shutil.copy(src, path)
        return path

    def clear(self, keep_langame=True):
        if keep_langame:
            new_chunks, new_meta, new_diff = [], [], []
            for i, c in enumerate(self.chunks):
                m = self.metadata[i] if i < len(self.metadata) else {}
                if m.get("source") == "langame":
                    new_chunks.append(c); new_meta.append(m)
                    new_diff.append(self.difficulty[i] if i < len(self.difficulty) else "easy")
            self.chunks = new_chunks; self.metadata = new_meta; self.difficulty = new_diff
            self._lower_chunks = [normalize_text(c) for c in self.chunks]
            self.categories = set(m.get("category", "общие") for m in self.metadata)
        else:
            self.chunks = []; self._lower_chunks = []; self.metadata = []
            self.difficulty = []; self.categories = set()
        self._rebuild_tags()
        self.save()

    def import_from_file(self, filepath, source="base"):
        ext = os.path.splitext(filepath)[1].lower()
        try:
            if ext == ".json":
                return self._import_json_questions(filepath, source)
            elif ext == ".pdf":
                return self._import_pdf_questions(filepath, source)
            else:
                return False, 0, 0, f"Формат {ext} не поддерживается (только .json и .pdf)"
        except Exception as e:
            log_error(e, "import_from_file")
            return False, 0, 0, str(e)

    def _add_question_safe(self, q, a, cat, diff, tags, source):
        if self.question_exists(q, source=source): return False
        text = f"Вопрос: {q}\nОтвет: {a}"
        self.add_text(text, category=cat, difficulty=diff, tags=tags, source=source)
        return True

    def _import_json_questions(self, filepath, source):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            return False, 0, 0, "JSON должен содержать массив объектов"
        added = 0; skipped = 0
        for item in data:
            if not isinstance(item, dict): continue
            q = str(item.get("question", "")).strip()
            a = str(item.get("answer", "")).strip()
            if not q or not a: continue
            cat = str(item.get("category", "общие")).strip() or "общие"
            diff = str(item.get("difficulty", "easy")).strip() or "easy"
            if diff not in ("easy", "medium", "hard"): diff = "easy"
            tags = item.get("tags", [])
            if not isinstance(tags, list): tags = []
            tags = [str(t).strip() for t in tags if str(t).strip()]
            if self._add_question_safe(q, a, cat, diff, tags, source): added += 1
            else: skipped += 1
        return True, added, skipped, ""

    def _import_pdf_questions(self, filepath, source):
        if not HAS_PYPDF:
            return False, 0, 0, "Для импорта PDF установите pypdf (pip install pypdf)"
        try:
            reader = PdfReader(filepath)
            text_parts = []
            for page in reader.pages:
                try:
                    text_parts.append(page.extract_text() or "")
                except Exception:
                    continue
        except Exception as e:
            return False, 0, 0, (
                f"PDF повреждён или сохранён в нестандартном формате.\n"
                f"Попробуйте пересохранить его из Word или браузера.\n\n({e})")

        raw = "\n".join(text_parts)
        if not raw.strip():
            return False, 0, 0, "PDF не содержит текста (возможно, это скан-картинка)"

        added = 0; skipped = 0; seen_q = set()

        for raw_line in raw.split("\n"):
            line = raw_line.strip()
            if not line or line.startswith("#"): continue
            if "Вопрос:" in line or "Ответ:" in line: continue
            if "|" not in line: continue
            parts = line.split("|", 1)
            if len(parts) != 2: continue
            q = parts[0].strip(); a = parts[1].strip()
            q = re.sub(r"^\d+\s*$", "", q).strip()
            if not q or not a: continue
            if len(q) < 3 or len(a) < 3: continue
            key = normalize_text(q)
            if key in seen_q: continue
            seen_q.add(key)
            if self._add_question_safe(q, a, "общие", "easy", [], source): added += 1
            else: skipped += 1

        if added == 0:
            blocks = re.split(r"(?=Вопрос\s*:)", raw, flags=re.IGNORECASE)
            for block in blocks:
                block = block.strip()
                if not block: continue
                m = re.search(r"Вопрос\s*:\s*(.+?)\s*Ответ\s*:\s*(.+)",
                              block, flags=re.IGNORECASE | re.DOTALL)
                if not m: continue
                q = m.group(1).strip(); a = m.group(2).strip()
                q = re.sub(r"^[-—–\s]+", "", q); q = re.sub(r"[-—–\s]+$", "", q)
                a = re.sub(r"^[-—–\s]+", "", a); a = re.sub(r"[-—–\s]+$", "", a)
                if not q or not a: continue
                if len(q) < 3 or len(a) < 3: continue
                key = normalize_text(q)
                if key in seen_q: continue
                seen_q.add(key)
                if self._add_question_safe(q, a, "общие", "easy", [], source): added += 1
                else: skipped += 1

        if added == 0 and skipped == 0:
            return False, 0, 0, (
                "Не удалось распознать структуру PDF.\n\n"
                "Поддерживаются два формата:\n\n"
                "1) Строка вида:\n"
                "     Как перезагрузить роутер? | Отключить питание на 10 секунд\n\n"
                "2) Блок вида:\n"
                "     Вопрос: Как перезагрузить роутер?\n"
                "     Ответ: Отключить питание на 10 секунд")
        return True, added, skipped, ""


make_auto_backup()
kb = KnowledgeBase()
ALL_QUESTIONS = []


def rebuild_all_questions():
    global ALL_QUESTIONS
    ALL_QUESTIONS = []
    for i, c in enumerate(kb.chunks):
        q, a = chunk_to_qa(c)
        m = kb.metadata[i] if i < len(kb.metadata) else {}
        ALL_QUESTIONS.append({"question": q, "answer": a,
                              "category": m.get("category", "общие"),
                              "difficulty": kb.difficulty[i] if i < len(kb.difficulty) else "easy",
                              "tags": list(m.get("tags", [])),
                              "source": m.get("source", "base")})


def load_all_questions():
    if len(kb.chunks) == 0:
        for q in BASE_QUESTIONS:
            text = f"Вопрос: {q['question']}\nОтвет: {q['answer']}"
            kb.add_text(text, category=q['category'], difficulty=q['difficulty'],
                        tags=q.get("tags", []), source="base")
    rebuild_all_questions()


load_all_questions()
# ===== PDF ЭКСПОРТ =====
def export_knowledge_to_pdf(filepath):
    if not HAS_REPORTLAB:
        raise RuntimeError("Для экспорта в PDF установите reportlab (pip install reportlab)")
    font_name = "Helvetica"
    for fp in [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\DejaVuSans.ttf",
               "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/Library/Fonts/Arial.ttf"]:
        if os.path.exists(fp):
            try:
                pdfmetrics.registerFont(TTFont("CyrFont", fp))
                font_name = "CyrFont"; break
            except Exception:
                continue
    c = pdf_canvas.Canvas(filepath, pagesize=A4)
    width, height = A4
    margin = 18 * mm
    y = height - margin

    def new_page():
        nonlocal y
        c.showPage(); y = height - margin

    def ensure_space(needed):
        nonlocal y
        if y - needed < margin: new_page()

    c.setFont(font_name, 16)
    c.drawString(margin, y, "Dopamine — База знаний")
    y -= 8 * mm
    c.setFont(font_name, 10)
    c.drawString(margin, y, f"Сформировано: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
    y -= 5 * mm
    c.drawString(margin, y, f"Всего записей: {len(kb.chunks)}")
    y -= 10 * mm
    c.setLineWidth(0.5); c.line(margin, y, width - margin, y); y -= 8 * mm

    def wrap_text(text, max_width, font, size):
        words = text.split(" "); lines = []; current = ""
        for w in words:
            candidate = (current + " " + w).strip()
            if pdfmetrics.stringWidth(candidate, font, size) <= max_width:
                current = candidate
            else:
                if current: lines.append(current)
                current = w
        if current: lines.append(current)
        return lines or [""]

    for i, chunk in enumerate(kb.chunks):
        q, a = chunk_to_qa(chunk)
        q = strip_md_links(q); a = strip_md_links(a)
        m = kb.metadata[i] if i < len(kb.metadata) else {}
        cat = m.get("category", "общие"); tags = m.get("tags", [])
        src = m.get("source", "base")
        atts = m.get("attachments", [])
        q_lines = []; a_lines = []
        for raw_line in q.split("\n"):
            q_lines.extend(wrap_text(raw_line, width - 2 * margin, font_name, 12))
        for raw_line in a.split("\n"):
            a_lines.extend(wrap_text(raw_line, width - 2 * margin, font_name, 10))
        block_h = (len(q_lines) * 6 + 4) + (len(a_lines) * 5 + 4) + 14
        if atts: block_h += 5 * mm
        ensure_space(block_h)
        c.setFont(font_name, 9)
        meta_txt = f"#{i+1}  [{cat}]"
        if src == "langame": meta_txt += "  LANGame"
        c.drawString(margin, y, meta_txt); y -= 5 * mm
        c.setFont(font_name, 12)
        for line in q_lines:
            ensure_space(6); c.drawString(margin, y, line); y -= 6 * mm
        y -= 1 * mm
        c.setFont(font_name, 10)
        for line in a_lines:
            ensure_space(5); c.drawString(margin + 6, y, line); y -= 5 * mm
        if tags:
            c.setFont(font_name, 8); ensure_space(4)
            c.drawString(margin, y, "Теги: " + ", ".join(tags)); y -= 5 * mm
        if atts:
            c.setFont(font_name, 8); ensure_space(4)
            names = ", ".join(a.get("name", "?") for a in atts)
            c.drawString(margin, y, f"📎 Вложения: {names}"); y -= 5 * mm
        y -= 3 * mm
        c.setLineWidth(0.3); c.line(margin, y, width - margin, y); y -= 6 * mm
    c.save()


class TicketsDB:
    def __init__(self):
        self.tickets = []
        self.archive = []
        self._max_id_cache = None
        self.load()
        self._migrate_old_statuses()
        self._ensure_max_id()

    def _migrate_old_statuses(self):
        changed = False
        for t in self.tickets + self.archive:
            old = t.get("status", "new")
            if old == "progress":
                t["status"] = "in_progress"
                changed = True
            elif old == "done":
                t["status"] = "resolved"
                changed = True
            if "priority" not in t:
                sev = t.get("severity", "medium")
                t["priority"] = sev if sev in TICKET_PRIORITIES else "medium"
                changed = True
            if "zone" not in t:
                t["zone"] = "стандарт"
                changed = True
            if "started_at" not in t:
                t["started_at"] = t.get("created", datetime.now().isoformat())
                changed = True
            if "resolved_at" not in t:
                t["resolved_at"] = t.get("updated") if old in ("resolved", "closed", "done") else ""
                changed = True
            if "assignee" not in t:
                t["assignee"] = ""
                changed = True
            if "attachments" not in t:
                t["attachments"] = []
                changed = True
        self._max_id_cache = None
        if changed:
            self.save()
            self.save_archive()

    def load(self):
        if os.path.exists(TICKETS_FILE):
            try:
                with open(TICKETS_FILE, "rb") as f: self.tickets = pickle.load(f)
            except Exception as e:
                log_error(e, "Tickets.load"); self.tickets = []
        if os.path.exists(TICKETS_ARCHIVE_FILE):
            try:
                with open(TICKETS_ARCHIVE_FILE, "rb") as f: self.archive = pickle.load(f)
            except Exception as e:
                log_error(e, "Tickets.load archive"); self.archive = []

    def save(self):
        atomic_pickle_dump(TICKETS_FILE, self.tickets)

    def save_archive(self):
        atomic_pickle_dump(TICKETS_ARCHIVE_FILE, self.archive)

    def add(self, pc, problem, severity, author, priority=None,
            zone="стандарт", assignee=""):
        if priority is None:
            priority = severity if severity in TICKET_PRIORITIES else "medium"
        now = datetime.now().isoformat()
        new_id = self._ensure_max_id() + 1
        self._max_id_cache = new_id
        t = {
            "id": new_id,
            "pc": str(pc).strip(),
            "problem": str(problem).strip(),
            "severity": severity,
            "priority": priority,
            "zone": zone,
            "author": str(author).strip(),
            "assignee": str(assignee).strip(),
            "attachments": [],
            "status": "new",
            "created": now,
            "updated": now,
            "started_at": now,
            "resolved_at": "",
            "resolved_by": "", "note": "", "archived": False
        }
        self.tickets.append(t)
        self.save()
        return t

    def update_status(self, ticket_id, status, resolver="", note=""):
        for t in list(self.tickets):
            if t["id"] == ticket_id:
                t["status"] = status
                t["updated"] = datetime.now().isoformat()
                if resolver: t["resolved_by"] = resolver
                if note: t["note"] = note
                if status in ("resolved", "closed"):
                    t["resolved_at"] = t["updated"]; t["archived"] = True
                    self.tickets.remove(t); self.archive.append(t)
                    self.save(); self.save_archive()
                else: self.save()
                return True
        for t in list(self.archive):
            if t["id"] == ticket_id:
                if status not in ("resolved", "closed"):
                    t["status"] = status; t["archived"] = False
                    t["updated"] = datetime.now().isoformat()
                    self.archive.remove(t); self.tickets.append(t)
                    self.save(); self.save_archive()
                    return True
        return False

    def delete(self, ticket_id):
        self.tickets = [t for t in self.tickets if t["id"] != ticket_id]; self.save()

    def restore_from_archive(self, ticket_id):
        for t in self.archive:
            if t["id"] == ticket_id:
                t["archived"] = False; t["status"] = "new"
                t["updated"] = datetime.now().isoformat(); t["resolved_at"] = ""
                self.archive.remove(t); self.tickets.append(t)
                self.save(); self.save_archive()
                return True
        return False

    def delete_from_archive(self, ticket_id):
        self.archive = [t for t in self.archive if t["id"] != ticket_id]
        self.save_archive()

    def get_all(self): return list(reversed(self.tickets))
    def get_archive(self): return list(reversed(self.archive))

    def get_active(self):
        return [t for t in reversed(self.tickets) if t.get("status") not in ("resolved", "closed")]

    def get_by_status(self, status):
        return [t for t in reversed(self.tickets) if t.get("status") == status]

    def get_by_pc(self, pc):
        pc_norm = str(pc).strip().lower()
        all_t = self.tickets + self.archive
        return [t for t in reversed(all_t) if str(t.get("pc", "")).strip().lower() == pc_norm]

    def get_by_assignee(self, login):
        login_norm = str(login).strip().lower()
        return [t for t in reversed(self.tickets)
                if str(t.get("assignee", "")).strip().lower() == login_norm]

    def set_assignee(self, ticket_id, assignee):
        for t in self.tickets + self.archive:
            if t["id"] == ticket_id:
                t["assignee"] = str(assignee).strip()
                t["updated"] = datetime.now().isoformat()
                self.save()
                self.save_archive()
                return True
        return False

    def add_attachment(self, ticket_id, attachment):
        for t in self.tickets + self.archive:
            if t["id"] == ticket_id:
                if "attachments" not in t:
                    t["attachments"] = []
                t["attachments"].append(attachment)
                t["updated"] = datetime.now().isoformat()
                self.save()
                self.save_archive()
                return True
        return False

    def remove_attachment(self, ticket_id, attachment_path):
        for t in self.tickets + self.archive:
            if t["id"] == ticket_id:
                if "attachments" in t:
                    t["attachments"] = [a for a in t["attachments"]
                                        if a.get("path") != attachment_path]
                    t["updated"] = datetime.now().isoformat()
                    self.save()
                    self.save_archive()
                    return True
        return False

    def _ensure_max_id(self):
        if getattr(self, "_max_id_cache", None) is None:
            ids = [t["id"] for t in self.tickets] + [t["id"] for t in self.archive]
            self._max_id_cache = max(ids) if ids else 0
        return self._max_id_cache

    def get_max_id(self):
        return self._ensure_max_id()

    def is_stale(self, ticket):
        if ticket.get("status") not in ("new", "in_progress"): return False
        try:
            dt = datetime.fromisoformat(ticket.get("updated") or ticket.get("created"))
            return (datetime.now() - dt) > timedelta(hours=TICKET_STALE_HOURS)
        except Exception:
            return False

    def stats(self):
        return {"total": len(self.tickets),
                "new": sum(1 for t in self.tickets if t.get("status") == "new"),
                "in_progress": sum(1 for t in self.tickets if t.get("status") == "in_progress"),
                "waiting": sum(1 for t in self.tickets if t.get("status") == "waiting"),
                "critical": sum(1 for t in self.tickets
                                if t.get("priority") == "critical"
                                and t.get("status") not in ("resolved", "closed")),
                "archive": len(self.archive)}

    def get_technician_stats(self, limit=5):
        stats = {}
        for t in self.archive:
            resolver = t.get("resolved_by", "").strip()
            if not resolver: continue
            stats[resolver] = stats.get(resolver, 0) + 1
        return sorted(stats.items(), key=lambda x: x[1], reverse=True)[:limit]

    def get_avg_resolution_time(self):
        times = []
        for t in self.archive:
            try:
                start = datetime.fromisoformat(t.get("created", ""))
                end = datetime.fromisoformat(t.get("resolved_at", "") or t.get("updated", ""))
                delta = (end - start).total_seconds()
                if delta > 0: times.append(delta)
            except Exception:
                pass
        if not times: return 0
        return sum(times) / len(times)

    def get_problem_pcs(self, limit=5):
        stats = {}
        all_t = self.tickets + self.archive
        for t in all_t:
            pc = str(t.get("pc", "")).strip()
            if pc: stats[pc] = stats.get(pc, 0) + 1
        return sorted(stats.items(), key=lambda x: x[1], reverse=True)[:limit]

    def get_daily_stats(self, days=14):
        today = datetime.now().date()
        days_list = [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
        stats = {d: 0 for d in days_list}
        all_t = self.tickets + self.archive
        for t in all_t:
            try:
                d = t.get("created", "")[:10]
                if d in stats: stats[d] += 1
            except Exception:
                pass
        return [(d, stats[d]) for d in days_list]


tickets_db = TicketsDB()


class SuggestionsDB:
    def __init__(self):
        self.suggestions = []; self.load()

    def load(self):
        if os.path.exists(SUGGESTIONS_FILE):
            try:
                with open(SUGGESTIONS_FILE, "rb") as f: self.suggestions = pickle.load(f)
            except Exception as e:
                log_error(e, "Suggestions.load"); self.suggestions = []

    def save(self):
        atomic_pickle_dump(SUGGESTIONS_FILE, self.suggestions)

    def add(self, question, answer, author, source="no_answer"):
        s = {"id": len(self.suggestions) + 1, "question": str(question).strip(),
             "answer": str(answer).strip(), "author": str(author).strip() or "Аноним",
             "source": source, "status": "pending", "created": datetime.now().isoformat()}
        self.suggestions.append(s); self.save()
        return s

    def update(self, sid, new_question, new_answer):
        for s in self.suggestions:
            if s["id"] == sid:
                s["question"] = str(new_question).strip()
                s["answer"] = str(new_answer).strip()
                self.save(); return True
        return False

    def approve(self, sid, category="общие", difficulty="easy", tags=None):
        for s in self.suggestions:
            if s["id"] == sid:
                text = f"Вопрос: {s['question']}\nОтвет: {s['answer']}"
                kb.add_text(text, category=category, difficulty=difficulty,
                            tags=tags or [], source="base")
                s["status"] = "approved"; self.save()
                rebuild_all_questions(); return True
        return False

    def reject(self, sid):
        for s in self.suggestions:
            if s["id"] == sid:
                s["status"] = "rejected"; self.save(); return True
        return False

    def delete(self, sid):
        self.suggestions = [s for s in self.suggestions if s["id"] != sid]; self.save()

    def get_pending(self):
        return [s for s in reversed(self.suggestions) if s["status"] == "pending"]

    def count_pending(self):
        return sum(1 for s in self.suggestions if s["status"] == "pending")


suggestions_db = SuggestionsDB()


class UsersDB:
    ROLES = {"tech": {"name": "Тех-админ", "icon": "🔧"},
             "admin": {"name": "Админ", "icon": "🔐"}}

    def __init__(self):
        self.users = {}; self.load()

    def load(self):
        if os.path.exists(USERS_FILE):
            try:
                with open(USERS_FILE, "rb") as f: self.users = pickle.load(f)
            except Exception as e:
                log_error(e, "Users.load"); self.users = {}
        if "tech" not in self.users:
            self.users["tech"] = {"password_hash": hash_password("dopamine2025"),
                                  "role": "tech", "permissions": list(PERMISSIONS.keys()),
                                  "created": datetime.now().isoformat(), "auto_theme": False}
            self.save()
        changed = False
        for login, u in list(self.users.items()):
            if u.get("role") == "intern":
                del self.users[login]; changed = True; continue
            if "permissions" not in u:
                u["permissions"] = list(PERMISSIONS.keys()) if u.get("role") == "tech" else []
                changed = True
            if "auto_theme" not in u:
                u["auto_theme"] = False; changed = True
            if u.get("role") == "admin":
                for new_perm in ("archive", "dictionary", "langame", "tags"):
                    if new_perm not in u["permissions"]:
                        u["permissions"].append(new_perm); changed = True
        if changed: self.save()

    def save(self):
        atomic_pickle_dump(USERS_FILE, self.users)

    def auth(self, login, password):
        login = login.strip().lower()
        if login not in self.users:
            return None
        stored = self.users[login].get("password_hash", "")
        if not verify_password(password, stored):
            return None
        # Апгрейд старого SHA-256 до PBKDF2
        if "$" not in stored:
            try:
                self.users[login]["password_hash"] = hash_password(password)
                self.save()
                logger.info("Пароль пользователя %s переведён на PBKDF2", login)
            except Exception as e:
                log_error(e, "auth upgrade hash")
        return self.users[login]["role"]

    def has_permission(self, login, perm):
        login = login.strip().lower()
        if login not in self.users: return False
        u = self.users[login]
        if u.get("role") == "tech": return True
        return perm in u.get("permissions", [])

    def get_permissions(self, login):
        login = login.strip().lower()
        if login not in self.users: return []
        u = self.users[login]
        if u.get("role") == "tech": return list(PERMISSIONS.keys())
        return list(u.get("permissions", []))

    def get_auto_theme(self, login):
        return self.users.get(login.strip().lower(), {}).get("auto_theme", False)

    def set_auto_theme(self, login, value):
        login = login.strip().lower()
        if login in self.users:
            self.users[login]["auto_theme"] = bool(value); self.save(); return True
        return False

    def add_user(self, login, password, role, permissions=None):
        login = login.strip().lower()
        if not login or not password: return False, "Логин и пароль обязательны"
        if len(login) < MIN_LOGIN_LENGTH: return False, f"Логин слишком короткий (мин. {MIN_LOGIN_LENGTH})"
        if len(login) > MAX_LOGIN_LENGTH: return False, f"Логин слишком длинный (макс. {MAX_LOGIN_LENGTH})"
        if login in self.users: return False, "Такой логин уже существует"
        if role not in self.ROLES: return False, "Неверная роль"
        if len(password) < MIN_PASSWORD_LENGTH: return False, f"Пароль слишком короткий (мин. {MIN_PASSWORD_LENGTH})"
        if len(password) > MAX_PASSWORD_LENGTH: return False, f"Пароль слишком длинный (макс. {MAX_PASSWORD_LENGTH})"
        if permissions is None:
            permissions = list(PERMISSIONS.keys()) if role == "tech" else []
        self.users[login] = {"password_hash": hash_password(password), "role": role,
                             "permissions": list(permissions),
                             "created": datetime.now().isoformat(), "auto_theme": False}
        self.save()
        return True, "Пользователь создан"

    def change_login(self, old_login, new_login):
        old_login = old_login.strip().lower(); new_login = new_login.strip().lower()
        if old_login == "tech": return False, "Нельзя менять логин главного тех-админа"
        if old_login not in self.users: return False, "Пользователь не найден"
        if not new_login: return False, "Логин не может быть пустым"
        if len(new_login) < MIN_LOGIN_LENGTH: return False, f"Логин слишком короткий (мин. {MIN_LOGIN_LENGTH})"
        if len(new_login) > MAX_LOGIN_LENGTH: return False, f"Логин слишком длинный (макс. {MAX_LOGIN_LENGTH})"
        if new_login in self.users and new_login != old_login:
            return False, "Такой логин уже существует"
        self.users[new_login] = self.users.pop(old_login); self.save()
        return True, "Логин изменён"

    def change_password(self, login, new_password):
        login = login.strip().lower()
        if login not in self.users: return False, "Пользователь не найден"
        if len(new_password) < MIN_PASSWORD_LENGTH: return False, f"Пароль слишком короткий (мин. {MIN_PASSWORD_LENGTH})"
        if len(new_password) > MAX_PASSWORD_LENGTH: return False, f"Пароль слишком длинный (макс. {MAX_PASSWORD_LENGTH})"
        self.users[login]["password_hash"] = hash_password(new_password); self.save()
        return True, "Пароль изменён"

    def change_role(self, login, new_role):
        login = login.strip().lower()
        if login not in self.users: return False, "Пользователь не найден"
        if login == "tech": return False, "Нельзя менять роль главного тех-админа"
        if new_role not in self.ROLES: return False, "Неверная роль"
        self.users[login]["role"] = new_role
        if new_role == "tech": self.users[login]["permissions"] = list(PERMISSIONS.keys())
        self.save(); return True, "Роль изменена"

    def change_permissions(self, login, permissions):
        login = login.strip().lower()
        if login not in self.users: return False, "Пользователь не найден"
        if login == "tech": return False, "У тех-админа всегда полный доступ"
        self.users[login]["permissions"] = list(permissions); self.save()
        return True, "Права обновлены"

    def delete_user(self, login):
        login = login.strip().lower()
        if login == "tech": return False, "Нельзя удалить главного тех-админа"
        if login in self.users: del self.users[login]; self.save(); return True
        return False

    def list_users(self):
        return [(login, u["role"], u.get("permissions", []), u.get("created", ""))
                for login, u in self.users.items()]

    def list_admins_and_techs(self):
        result = []
        for login, u in self.users.items():
            role = u.get("role", "")
            if role in ("tech", "admin"):
                result.append(login)
        return sorted(result)

    def get_display_name(self, login):
        login = login.strip().lower()
        if login not in self.users:
            return login or "—"
        role = self.users[login].get("role", "")
        icon = self.ROLES.get(role, {}).get("icon", "👤")
        return f"{icon} {login}"


users_db = UsersDB()


class JournalDB:
    IGNORED_ACTIONS = {"Смена темы", "Вход в админку", "Выход из админки",
                       "Открыл вкладку", "Обновил список", "Смена фильтра"}

    def __init__(self):
        self.entries = []; self.load()

    def load(self):
        if os.path.exists(JOURNAL_FILE):
            try:
                with open(JOURNAL_FILE, "rb") as f: self.entries = pickle.load(f)
            except Exception as e:
                log_error(e, "Journal.load"); self.entries = []

    def save(self):
        atomic_pickle_dump(JOURNAL_FILE, self.entries[-5000:])

    def log(self, user, role, action, details=""):
        if action in self.IGNORED_ACTIONS: return
        self.entries.append({"time": datetime.now().isoformat(), "user": user or "—",
                             "role": role or "—", "action": action,
                             "details": str(details)[:300]})
        if len(self.entries) > 5000: self.entries = self.entries[-5000:]
        self.save()

    def get_all(self): return list(reversed(self.entries))
    def clear(self): self.entries = []; self.save()


journal_db = JournalDB()


class ThemeManager:
    def __init__(self):
        self.theme = "dark"; self.auto_theme = False; self.load()

    def load(self):
        if os.path.exists(THEME_FILE):
            try:
                with open(THEME_FILE, "rb") as f:
                    data = pickle.load(f)
                    self.theme = data.get("theme", "dark")
                    self.auto_theme = data.get("auto_theme", False)
            except Exception:
                self.theme = "dark"

    def save(self):
        atomic_pickle_dump(THEME_FILE,
                            {"theme": self.theme, "auto_theme": self.auto_theme})

    def set(self, theme):
        self.theme = theme; self.save()

    def get_auto_theme_for_time(self):
        h = datetime.now().hour
        return "light" if AUTO_THEME_DAY_START <= h < AUTO_THEME_NIGHT_START else "dark"


theme_mgr = ThemeManager()

BOT_TIRED_PHRASES = [
    "😅  Ох, я уже 5 раз подряд не смог помочь...\n\n"
    "Может, чай? ☕  А потом переформулируй вопрос — вдруг найду.\n"
    "Или обратись к живому админу — он точно знает.",
    "🥵  Так, всё, у меня перегрев.\n\n"
    "☕  Пойду налью себе виртуальный чай.\n"
    "Попробуй спросить иначе или позови администратора.",
    "😴  Я уже сбился со счёта...\n\n"
    "Давай так: ты — чай ☕, я — пауза 🛋️,\n"
    "а потом снова в бой. Или позови админа — он живой и умный.",
]

CODE_PATTERNS = [
    r"`[^`]+`", r"\b[a-z_]{3,}_[a-z_]+\b",
    r"\bconnect\s+\d+\.\d+\.\d+\.\d+(?::\d+)?",
    r"\b\d+\.\d+\.\d+\.\d+(?::\d+)?",
    r"\b(?:cmd|ipconfig|ping|taskkill)\b",
    r"\bWin\+[A-Za-zА-Яа-я]\b", r"\bCtrl\+[A-Za-zА-Яа-я]\b",
    r"\bAlt\+[A-Za-zА-Яа-я0-9]+\b", r"\bq_[a-z_]+\b",
]


# ===== ПРИЛОЖЕНИЕ =====
class ModernSupportApp:
    def __init__(self):
        self.app = ctk.CTk()
        self.app.title("Dopamine Assistant")
        self.app.geometry("1280x780")
        self.app.minsize(1024, 620)
        self.app.configure(fg_color=COLOR_BG)

        try:
            icon_path = os.path.join(APP_PATH, "icon.ico")
            if os.path.exists(icon_path):
                self.app.iconbitmap(icon_path)
        except Exception:
            pass

        self.history = []
        self.is_admin = False
        self.last_query = ""
        self.last_response = ""
        self.fail_streak = 0
        self.current_user = None
        self.current_role = None
        self.current_permissions = []

        self._typing_job = None
        self.is_typing = False
        self._autocomplete_job = None
        self._last_copied_response = ""

        self.sidebar_buttons = {}
        self.current_admin_section = None

        self._last_notified_ticket_id = tickets_db.get_max_id()
        self._notify_stop = False
        self._notify_thread = None
        self._notify_enabled = True

        self.apply_theme_colors()
        self.show_startup_login()
        # Поток уведомлений стартует после входа — см. launch_main_app

    def apply_theme_colors(self):
        global COLOR_BG, COLOR_PANEL, COLOR_PANEL_LIGHT, COLOR_CARD, COLOR_CARD_HOVER
        global COLOR_CODE_BG, COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_ACCENT_DARK
        global COLOR_TEXT, COLOR_TEXT_DIM, COLOR_TEXT_MUTED, COLOR_BOT_NAME, COLOR_USER_NAME
        global COLOR_SUCCESS, COLOR_ERROR, COLOR_DANGER, COLOR_DANGER_HOVER
        global COLOR_BORDER, COLOR_CODE_TEXT, COLOR_ON_ACCENT
        global COLOR_EMERG_BG, COLOR_EMERG_HOVER, COLOR_SIDEBAR, COLOR_SIDEBAR_HOVER, COLOR_SIDEBAR_ACTIVE

        p = DARK if theme_mgr.theme == "dark" else LIGHT
        COLOR_BG = p["BG"]; COLOR_PANEL = p["PANEL"]; COLOR_PANEL_LIGHT = p["PANEL_LIGHT"]
        COLOR_CARD = p["CARD"]; COLOR_CARD_HOVER = p["CARD_HOVER"]; COLOR_CODE_BG = p["CODE_BG"]
        COLOR_ACCENT = p["ACCENT"]; COLOR_ACCENT_HOVER = p["ACCENT_HOVER"]; COLOR_ACCENT_DARK = p["ACCENT_DARK"]
        COLOR_TEXT = p["TEXT"]; COLOR_TEXT_DIM = p["TEXT_DIM"]; COLOR_TEXT_MUTED = p["TEXT_MUTED"]
        COLOR_BOT_NAME = p["BOT_NAME"]; COLOR_USER_NAME = p["USER_NAME"]
        COLOR_SUCCESS = p["SUCCESS"]; COLOR_ERROR = p["ERROR"]
        COLOR_DANGER = p["DANGER"]; COLOR_DANGER_HOVER = p["DANGER_HOVER"]
        COLOR_BORDER = p["BORDER"]; COLOR_CODE_TEXT = p["CODE_TEXT"]; COLOR_ON_ACCENT = p["ON_ACCENT"]
        COLOR_EMERG_BG = p["EMERG_BG"]; COLOR_EMERG_HOVER = p["EMERG_HOVER"]
        COLOR_SIDEBAR = p["SIDEBAR"]; COLOR_SIDEBAR_HOVER = p["SIDEBAR_HOVER"]
        COLOR_SIDEBAR_ACTIVE = p["SIDEBAR_ACTIVE"]

    def has_perm(self, perm):
        if not self.current_user:
            return False
        if self.current_role == "tech":
            return True
        return perm in self.current_permissions

    def is_tech(self):
        return self.current_role == "tech"

    def _start_notification_thread(self):
        self._notify_stop = False
        self._notify_thread = threading.Thread(target=self._notify_loop, daemon=True)
        self._notify_thread.start()

    def _notify_loop(self):
        while not self._notify_stop:
            try:
                time.sleep(TICKET_NOTIFY_INTERVAL)
                if self._notify_stop:
                    break
                cur_max = tickets_db.get_max_id()
                if cur_max > self._last_notified_ticket_id:
                    new_count = cur_max - self._last_notified_ticket_id
                    self._last_notified_ticket_id = cur_max
                    if self._notify_enabled:
                        self.app.after(0, lambda c=new_count: self._on_new_ticket(c))
            except Exception as e:
                log_error(e, "notify_loop")

    def _on_new_ticket(self, count):
        try:
            if sys.platform == "win32":
                try:
                    import winsound
                    for _ in range(min(count, 3)):
                        winsound.MessageBeep(winsound.MB_ICONASTERISK)
                except Exception:
                    pass
            self._flash_window_title(f"🔴 Новый тикет! ({count})")
        except Exception as e:
            log_error(e, "_on_new_ticket")

    def _flash_window_title(self, text):
        original = "Dopamine Assistant"
        def blink(n):
            if n <= 0:
                try:
                    self.app.title(original)
                except Exception:
                    pass
                return
            try:
                self.app.title(text if n % 2 == 1 else original)
                self.app.after(500, lambda: blink(n - 1))
            except Exception:
                pass
        blink(6)

    def _attach_clipboard_support(self, widget):
        """Ctrl+C/V/X/A — работает в любой раскладке, для CTkEntry и CTkTextbox."""
        try:
            if hasattr(widget, "_textbox"):
                inner = widget._textbox
                is_text = True
            elif hasattr(widget, "_entry"):
                inner = widget._entry
                is_text = False
            else:
                inner = widget
                is_text = False

            def handler(event):
                ch = event.char or ""
                try:
                    if ch == "\x03":
                        inner.event_generate("<<Copy>>")
                        return "break"
                    if ch == "\x16":
                        inner.event_generate("<<Paste>>")
                        return "break"
                    if ch == "\x18":
                        inner.event_generate("<<Cut>>")
                        return "break"
                    if ch == "\x01":
                        if is_text:
                            inner.tag_add("sel", "1.0", "end")
                            inner.mark_set("insert", "end")
                        else:
                            inner.select_range(0, "end")
                            inner.icursor("end")
                        return "break"
                except Exception:
                    pass
                return None

            inner.bind("<Control-KeyPress>", handler, add="+")
        except Exception as e:
            log_error(e, "_attach_clipboard_support")

    # ===== ЭКРАН ВХОДА =====
    def show_startup_login(self):
        self.app.configure(fg_color=COLOR_BG)
        self.startup_frame = ctk.CTkFrame(self.app, fg_color=COLOR_BG, corner_radius=0)
        self.startup_frame.pack(fill="both", expand=True)

        top = ctk.CTkFrame(self.startup_frame, fg_color="transparent")
        top.pack(pady=(70, 20))

        logo = ctk.CTkFrame(top, width=80, height=80, corner_radius=20, fg_color=COLOR_ACCENT)
        logo.pack()
        logo.pack_propagate(False)
        ctk.CTkLabel(logo, text="🤖", font=("Segoe UI", 40)
                     ).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(top, text="DOPAMINE", font=("Segoe UI", 32, "bold"),
                     text_color=COLOR_ACCENT).pack(pady=(20, 0))
        ctk.CTkLabel(top, text="Assistant", font=("Segoe UI", 18),
                     text_color=COLOR_TEXT).pack()
        ctk.CTkLabel(top, text="Ассистент компьютерного клуба",
                     font=("Segoe UI", 12),
                     text_color=COLOR_TEXT_MUTED).pack(pady=(6, 0))

        card = ctk.CTkFrame(self.startup_frame, fg_color=COLOR_PANEL,
                            corner_radius=18, border_width=1, border_color=COLOR_BORDER)
        card.pack(pady=(20, 0))

        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(padx=60, pady=40)

        ctk.CTkLabel(inner, text="Вход в систему",
                     font=("Segoe UI", 20, "bold"),
                     text_color=COLOR_TEXT).pack(pady=(0, 24))

        ctk.CTkLabel(inner, text="Логин",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        login_entry = ctk.CTkEntry(
            inner, placeholder_text=f"{MIN_LOGIN_LENGTH}-{MAX_LOGIN_LENGTH} символов",
            placeholder_text_color=COLOR_TEXT_MUTED,
            font=("Segoe UI", 13), height=44, width=340,
            fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
            text_color=COLOR_TEXT, corner_radius=10)
        login_entry.pack(pady=(4, 12))
        self._attach_clipboard_support(login_entry)
        login_entry.focus()

        ctk.CTkLabel(inner, text="Пароль",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        pass_entry = ctk.CTkEntry(
            inner, placeholder_text=f"{MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} символов",
            placeholder_text_color=COLOR_TEXT_MUTED,
            show="*", font=("Segoe UI", 13), height=44, width=340,
            fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
            text_color=COLOR_TEXT, corner_radius=10)
        pass_entry.pack(pady=(4, 6))
        self._attach_clipboard_support(pass_entry)

        def limit_login(event):
            if event.keysym in ("BackSpace", "Delete", "Left", "Right",
                                "Up", "Down", "Home", "End", "Tab",
                                "Return", "KP_Enter", "Escape"):
                return
            if len(login_entry.get()) >= MAX_LOGIN_LENGTH:
                return "break"

        def limit_pass(event):
            if event.keysym in ("BackSpace", "Delete", "Left", "Right",
                                "Up", "Down", "Home", "End", "Tab",
                                "Return", "KP_Enter", "Escape"):
                return
            if len(pass_entry.get()) >= MAX_PASSWORD_LENGTH:
                return "break"

        login_entry.bind("<KeyPress>", limit_login)
        pass_entry.bind("<KeyPress>", limit_pass)

        err_label = ctk.CTkLabel(inner, text="",
                                 font=("Segoe UI", 11),
                                 text_color=COLOR_ERROR)
        err_label.pack(pady=(0, 6))

        def do_login():
            login = login_entry.get().strip()
            password = pass_entry.get()
            if not login or not password:
                err_label.configure(text="❌ Введите логин и пароль")
                return
            if len(login) < MIN_LOGIN_LENGTH or len(login) > MAX_LOGIN_LENGTH:
                err_label.configure(text=f"❌ Логин: {MIN_LOGIN_LENGTH}-{MAX_LOGIN_LENGTH} символов")
                return
            if len(password) < MIN_PASSWORD_LENGTH or len(password) > MAX_PASSWORD_LENGTH:
                err_label.configure(text=f"❌ Пароль: {MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} символов")
                return
            role = users_db.auth(login, password)
            if role is None:
                err_label.configure(text="❌ Неверный логин или пароль")
                return
            self.current_user = login.lower()
            self.current_role = role
            self.current_permissions = users_db.get_permissions(self.current_user)
            if users_db.get_auto_theme(self.current_user):
                new_theme = theme_mgr.get_auto_theme_for_time()
                if new_theme != theme_mgr.theme:
                    theme_mgr.set(new_theme)
                    self.apply_theme_colors()
            self.startup_frame.destroy()
            self.launch_main_app()

        login_entry.bind("<Return>", lambda e: do_login())
        pass_entry.bind("<Return>", lambda e: do_login())

        self._accent_button(inner, "🔓  Войти",
                            command=do_login,
                            width=340, height=46).pack(pady=(4, 0))

        ctk.CTkLabel(
            self.startup_frame,
            text="💡 Доступ выдаёт тех-админ клуба",
            font=("Segoe UI", 10),
            text_color=COLOR_TEXT_MUTED
        ).pack(pady=(16, 0))

    def launch_main_app(self):
        self.create_header()
        self.create_body()
        self.create_status_bar()
        self.setup_hotkeys()
        self.restore_draft()

        # Уведомления запускаем только после успешного входа
        # и синхронизируем счётчик с текущим максимумом ID тикетов
        self._last_notified_ticket_id = tickets_db.get_max_id()
        self._start_notification_thread()

        self._type_message_safe(
            "👋  Добро пожаловать!\n\n"
            "Я помогу найти ответ на любой вопрос про клуб Dopamine.\n\n"
            "📌  Доступные темы:\n"
            "     🎮  Игры — CS2, Minecraft, DBD, GTA 5\n"
            "     🎤  Периферия — микрофон, мышка, клавиатура\n"
            "     🛠  Софт — VPN, Steam, античит\n"
            "     🏢  Клуб — бронь, оплата\n"
            "     📡  Сеть — пинг, интернет\n"
            "     💻  Общее — тормозит, завис, скриншот\n\n"
            "💡  Введи вопрос в чат или кликни по вопросу справа.\n"
            "🚨  Проблема с ПК? Жми «Аварийный список».\n\n"
            "⌨  Ctrl+K — ввод  •  Ctrl+L — очистить  •  Ctrl+N — новый тикет\n"
            "⌨  Ctrl+F — поиск  •  Ctrl+J — журнал  •  Ctrl+1..9 — разделы",
            show_actions=False
        )
                # Тихая проверка обновлений. Не блокирует запуск: уходит в
        # daemon-поток через 4 секунды после появления окна, в GUI
        # возвращается только через app.after — так же, как _notify_loop.
        if HAS_UPDATER:
            update_ui.start_background_check(self)

    def _accent_button(self, parent, text, command, width=140, height=42, font_size=13):
        return ctk.CTkButton(
            parent, text=text,
            font=("Segoe UI", font_size, "bold"),
            fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
            text_color=COLOR_ON_ACCENT,
            corner_radius=11, height=height, width=width, command=command)

    def _ghost_button(self, parent, text, command, width=120, height=32, font_size=11):
        return ctk.CTkButton(
            parent, text=text,
            font=("Segoe UI", font_size, "bold"),
            fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
            text_color=COLOR_TEXT, corner_radius=10,
            height=height, width=width,
            border_width=1, border_color=COLOR_BORDER,
            command=command)

    # ===== ГОРЯЧИЕ КЛАВИШИ =====
    def setup_hotkeys(self):
        try:
            self.app.bind_class("all", "<Control-KeyPress>",
                                self._global_ctrl_handler, add="+")
            self.app.bind_class("all", "<Escape>",
                                self._global_escape_handler, add="+")
        except Exception as e:
            log_error(e, "setup_hotkeys bind_class")

        for i in range(1, 10):
            try:
                self.app.bind_class("all", f"<Control-Key-{i}>",
                                    lambda e, n=i: self._quick_nav(n), add="+")
            except Exception as e:
                log_error(e, f"bind Ctrl+{i}")

        if hasattr(self, "input_entry"):
            self.input_entry.bind("<Up>", self.on_up_arrow)
            self.input_entry.bind("<KeyRelease>", self.on_input_key)
        self.app.protocol("WM_DELETE_WINDOW", self.on_close)

    def _global_ctrl_handler(self, event):
        try:
            keysym = (event.keysym or "").lower()
            char = ""
            try:
                char = (event.char or "").lower()
            except Exception:
                pass

            all_keys = {keysym, char}

            cyrillic_map = {
                "cyrillic_ka": "k", "cyrillic_el": "l", "cyrillic_en": "n",
                "cyrillic_ef": "f", "cyrillic_o": "j", "cyrillic_es": "c",
                "cyrillic_em": "v", "cyrillic_a": "f", "cyrillic_che": "x",
                "cyrillic_de": "d",
            }
            for ck, lk in cyrillic_map.items():
                if ck in keysym:
                    all_keys.add(lk)

            ru_to_lat = {
                "к": "k", "л": "l", "д": "l", "т": "n", "а": "f",
                "о": "j", "с": "c", "м": "v", "ф": "a", "ч": "x",
            }
            if char in ru_to_lat:
                all_keys.add(ru_to_lat[char])

            if "n" in all_keys:
                return self.hotkey_new_ticket()
            if "f" in all_keys:
                return self.hotkey_search()
            if "j" in all_keys:
                return self.hotkey_journal()
            if "k" in all_keys:
                return self.hotkey_focus()
            if "l" in all_keys:
                return self.hotkey_clear()
            if "c" in all_keys or "v" in all_keys or "x" in all_keys or "a" in all_keys:
                return
        except Exception as e:
            log_error(e, "_global_ctrl_handler")
        return

    def _global_escape_handler(self, event=None):
        try:
            if self.is_admin:
                self.exit_admin()
                return "break"
            elif hasattr(self, "page_tickets") and self.page_tickets.winfo_ismapped():
                self.show_page("user")
                return "break"
        except Exception as e:
            log_error(e, "_global_escape_handler")
        return "break"

    def hotkey_escape(self, event=None):
        return self._global_escape_handler(event)

    def hotkey_new_ticket(self, event=None):
        try:
            if not self.is_admin:
                self.show_page("tickets")
        except Exception:
            pass
        return "break"

    def hotkey_search(self, event=None):
        try:
            if not self.is_admin and hasattr(self, "input_entry"):
                self.input_entry.focus_set()
        except Exception:
            pass
        return "break"

    def hotkey_journal(self, event=None):
        try:
            if self.has_perm("journal"):
                if not self.is_admin:
                    self.show_page("admin")
                self.show_admin_section("journal")
        except Exception:
            pass
        return "break"

    def hotkey_focus(self, event=None):
        try:
            if hasattr(self, "input_entry") and self.page_user.winfo_ismapped():
                self.input_entry.focus_set()
        except Exception:
            pass
        return "break"

    def hotkey_clear(self, event=None):
        try:
            if hasattr(self, "clear_chat") and self.page_user.winfo_ismapped():
                self.clear_chat()
        except Exception:
            pass
        return "break"

    def _quick_nav(self, n):
        if not self.current_user:
            return "break"
        if not self.is_admin:
            self.show_page("admin")
        try:
            sections = self.get_available_sections()
            if 1 <= n <= len(sections):
                sec_id, _, _ = sections[n - 1]
                self.show_admin_section(sec_id)
        except Exception as e:
            log_error(e, f"_quick_nav({n})")
        return "break"

    # ===== HEADER =====
    def create_header(self):
        self.header = ctk.CTkFrame(self.app, height=76, corner_radius=0, fg_color=COLOR_PANEL)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)
        ctk.CTkFrame(self.header, height=2, corner_radius=0,
                     fg_color=COLOR_ACCENT).pack(fill="x", side="bottom")

        left = ctk.CTkFrame(self.header, fg_color="transparent")
        left.pack(side="left", padx=20, pady=14)

        logo = ctk.CTkFrame(left, width=42, height=42, corner_radius=11, fg_color=COLOR_ACCENT)
        logo.pack(side="left")
        logo.pack_propagate(False)
        ctk.CTkLabel(logo, text="🤖", font=("Segoe UI", 20)
                     ).place(relx=0.5, rely=0.5, anchor="center")

        tb = ctk.CTkFrame(left, fg_color="transparent")
        tb.pack(side="left", padx=(12, 0))
        ctk.CTkLabel(tb, text="DOPAMINE", font=("Segoe UI", 18, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w")
        self.header_subtitle = ctk.CTkLabel(
            tb, text="Ассистент компьютерного клуба",
            font=("Segoe UI", 10), text_color=COLOR_TEXT_MUTED)
        self.header_subtitle.pack(anchor="w")

        right = ctk.CTkFrame(self.header, fg_color="transparent")
        right.pack(side="right", padx=20, pady=14)
        self.header_right = right   # сюда апдейтер вешает плашку «⬆ 1.3.0»

        self.btn_back = ctk.CTkButton(
            right, text="←  Назад",
            font=("Segoe UI", 12, "bold"),
            fg_color=COLOR_ACCENT_DARK, hover_color=COLOR_ACCENT,
            text_color=COLOR_ON_ACCENT,
            corner_radius=10, height=36, width=110, command=self.go_back)

        # Кнопка AI-помощника
        self._ghost_button(right, "🤖", command=self.open_ai_window,
                           width=42, height=36, font_size=14).pack(
            side="left", padx=(0, 8))
    
        theme_icon = "🌙" if theme_mgr.theme == "light" else "☀️"
        self._ghost_button(right, theme_icon, command=self.toggle_theme,
                           width=42, height=36, font_size=14).pack(side="left", padx=(0, 8))

        if self.current_user and self.current_role:
            role_icon = UsersDB.ROLES[self.current_role]["icon"]
            role_name = UsersDB.ROLES[self.current_role]["name"]
            user_box = ctk.CTkFrame(right, fg_color=COLOR_PANEL_LIGHT,
                                    corner_radius=10, border_width=1, border_color=COLOR_BORDER)
            user_box.pack(side="left")
            ctk.CTkLabel(user_box, text=f"{role_icon}  {self.current_user}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left", padx=(10, 4), pady=6)
            ctk.CTkLabel(user_box, text=role_name,
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 10), pady=6)

        self._ghost_button(right, "🚪", command=self.logout,
                           width=42, height=36, font_size=14).pack(side="left", padx=(8, 0))

    def logout(self):
        if not messagebox.askyesno("Выход", "Выйти из системы?"):
            return
        try:
            draft_path = os.path.join(APP_PATH, DRAFT_FILE)
            if os.path.exists(draft_path):
                os.remove(draft_path)
        except Exception as e:
            log_error(e, "logout_clear_draft")

        # Останавливаем поток уведомлений перед возвратом на экран логина
        self._notify_stop = True

        for w in self.app.winfo_children():
            w.destroy()
        self.current_user = None
        self.current_role = None
        self.current_permissions = []
        self.is_admin = False
        self.history = []
        self.show_startup_login()

    def toggle_theme(self):
        theme_mgr.set("light" if theme_mgr.theme == "dark" else "dark")
        if self.current_user:
            users_db.set_auto_theme(self.current_user, False)
        self.apply_theme_colors()
        for w in self.app.winfo_children():
            w.destroy()
        self.create_header()
        self.create_body()
        self.create_status_bar()
        self.show_page("user")

    def create_body(self):
        self.body = ctk.CTkFrame(self.app, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=14, pady=(4, 8))

        self.page_user = ctk.CTkFrame(self.body, fg_color="transparent")
        self.page_tickets = ctk.CTkFrame(self.body, fg_color="transparent")
        self.page_admin = ctk.CTkFrame(self.body, fg_color="transparent")

        self.build_user_page()
        self.build_tickets_page()

        self.show_page("user")

    def create_status_bar(self):
        bar = ctk.CTkFrame(self.app, height=30, corner_radius=0, fg_color=COLOR_PANEL)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        ctk.CTkFrame(bar, height=1, fg_color=COLOR_BORDER).pack(fill="x", side="top")

        self.status_label = ctk.CTkLabel(bar, text="●  Готов к работе",
                                         font=("Segoe UI", 10),
                                         text_color=COLOR_SUCCESS)
        self.status_label.pack(side="left", padx=20, pady=6)

        self.msg_count = ctk.CTkLabel(bar, text="Сообщений: 0",
                                      font=("Segoe UI", 10),
                                      text_color=COLOR_TEXT_MUTED)
        self.msg_count.pack(side="right", padx=20, pady=6)

        ctk.CTkLabel(bar, text="Ctrl+K ввод  •  Ctrl+N тикет  •  Ctrl+F поиск  •  Esc назад",
                     font=("Segoe UI", 9), text_color=COLOR_TEXT_MUTED
                     ).pack(side="right", padx=10, pady=6)

    def show_page(self, name):
        if name == "admin" and not self.current_user:
            return

        pages = (self.page_user, self.page_tickets, self.page_admin)
        for p in pages:
            p.pack_forget()

        if name == "user":
            self.page_user.pack(fill="both", expand=True)
            self.btn_back.pack_forget()
            self.header_subtitle.configure(text="Ассистент компьютерного клуба")
            self.is_admin = False
        elif name == "admin":
            self.page_admin.pack(fill="both", expand=True)
            self.btn_back.pack(side="left", padx=(0, 12))
            role_name = UsersDB.ROLES.get(self.current_role, {}).get("name", "—")
            self.header_subtitle.configure(text=f"Админ-режим  •  {role_name}")
            self.is_admin = True
            self.build_admin_page()
        elif name == "tickets":
            self.page_tickets.pack(fill="both", expand=True)
            self.btn_back.pack(side="left", padx=(0, 12))
            self.header_subtitle.configure(text="Аварийный список")
            self.build_tickets_page()
            self.refresh_tickets_list()

    def go_back(self):
        if self.is_admin:
            self.is_admin = False
        self.show_page("user")

    def exit_admin(self):
        self.is_admin = False
        self.show_page("user")

    # =================================================================
    # ============ ПОЛЬЗОВАТЕЛЬСКАЯ СТРАНИЦА =========================
    # =================================================================
    def build_user_page(self):
        for w in self.page_user.winfo_children():
            w.destroy()

        chat_panel = ctk.CTkFrame(self.page_user, fg_color=COLOR_PANEL,
                                  corner_radius=16, border_width=1, border_color=COLOR_BORDER)
        chat_panel.pack(side="left", fill="both", expand=True, padx=(0, 10))

        ch = ctk.CTkFrame(chat_panel, fg_color="transparent", height=52)
        ch.pack(fill="x", padx=16, pady=(12, 0))
        ch.pack_propagate(False)

        ctk.CTkLabel(ch, text="💬  Диалог",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_TEXT).pack(side="left")

        self.records_label = ctk.CTkLabel(
            ch, text=f"{len(kb.chunks)}  записей",
            font=("Segoe UI", 10, "bold"),
            text_color=COLOR_ON_ACCENT,
            fg_color=COLOR_ACCENT, corner_radius=9, padx=10, pady=4)
        self.records_label.pack(side="right", padx=(6, 0))

        self._ghost_button(ch, "📥  Экспорт", command=self.export_dialog,
                           width=105, height=32).pack(side="right", padx=4)
        self._ghost_button(ch, "🧹  Очистить", command=self.clear_chat,
                           width=105, height=32).pack(side="right", padx=4)

        ic = ctk.CTkFrame(chat_panel, fg_color=COLOR_CARD, corner_radius=12,
                          height=68, border_width=1, border_color=COLOR_BORDER)
        ic.pack(side="bottom", fill="x", padx=12, pady=(0, 12))
        ic.pack_propagate(False)

        ew = ctk.CTkFrame(ic, fg_color=COLOR_PANEL_LIGHT, corner_radius=10)
        ew.pack(side="left", fill="x", expand=True, padx=(10, 8), pady=12)

        ctk.CTkLabel(ew, text="⌨", font=("Segoe UI", 13),
                     text_color=COLOR_TEXT_MUTED).pack(side="left", padx=(12, 0))

        self.input_entry = ctk.CTkEntry(
            ew, placeholder_text="Задай свой вопрос...",
            placeholder_text_color=COLOR_TEXT_MUTED,
            font=("Segoe UI", 13), height=44,
            fg_color="transparent", border_width=0,
            text_color=COLOR_TEXT, corner_radius=10)
        self.input_entry.pack(side="left", fill="x", expand=True, padx=(8, 10), pady=4)
        self.input_entry.bind("<Return>", lambda e: self.send_message())
        self._attach_clipboard_support(self.input_entry)

        self.send_btn = ctk.CTkButton(
            ic, text="➤  Найти",
            font=("Segoe UI", 13, "bold"), height=44, width=120,
            corner_radius=10, fg_color=COLOR_ACCENT,
            hover_color=COLOR_ACCENT_HOVER,
            text_color=COLOR_ON_ACCENT, command=self.send_message)
        self.send_btn.pack(side="right", padx=(0, 10), pady=12)

        cc = ctk.CTkFrame(chat_panel, fg_color=COLOR_BG,
                          corner_radius=12, border_width=1, border_color=COLOR_BORDER)
        cc.pack(fill="both", expand=True, padx=12, pady=(8, 0))

        self.chat_text = tk.Text(
            cc, wrap="word", bg=COLOR_BG, fg=COLOR_TEXT, bd=0,
            highlightthickness=0, font=("Segoe UI", 12),
            padx=18, pady=12, cursor="arrow", insertwidth=0,
            spacing1=3, spacing3=8, state="disabled",
            selectbackground=COLOR_ACCENT_DARK, selectforeground="#fff")
        self.chat_text.pack(side="left", fill="both", expand=True, padx=(6, 0), pady=6)

        sb = ctk.CTkScrollbar(cc, command=self.chat_text.yview,
                              width=12, corner_radius=6,
                              button_color=COLOR_ACCENT_DARK,
                              button_hover_color=COLOR_ACCENT)
        sb.pack(side="right", fill="y", padx=(0, 6), pady=6)
        self.chat_text.configure(yscrollcommand=sb.set)

        self._setup_chat_tags()
        self._bind_chat_scroll()

        rp = ctk.CTkFrame(self.page_user, width=360, fg_color=COLOR_PANEL,
                          corner_radius=16, border_width=1, border_color=COLOR_BORDER)
        rp.pack(side="right", fill="y")
        rp.pack_propagate(False)

        ba = ctk.CTkFrame(rp, fg_color="transparent")
        ba.pack(side="bottom", fill="x", padx=12, pady=(0, 12))

        self._ghost_button(ba, "📊  Статистика",
                           command=self.show_stats,
                           width=120, height=40, font_size=12).pack(side="left")

        # ⬇️ НОВАЯ КНОПКА LANGAME
        self._ghost_button(ba, "🎓  LAnGame",
                           command=self.open_langame_window,
                           width=110, height=40, font_size=12
                           ).pack(side="left", padx=(6, 0))
        # ⬆️

        ctk.CTkButton(
            ba, text="🔐  Админ",
            font=("Segoe UI", 12, "bold"),
            fg_color=COLOR_ACCENT_DARK, hover_color=COLOR_ACCENT,
            text_color=COLOR_ON_ACCENT,
            corner_radius=10, height=40, width=110,
            command=lambda: self.show_page("admin")
        ).pack(side="right")

        emerg_row = ctk.CTkFrame(rp, fg_color="transparent")
        emerg_row.pack(side="bottom", fill="x", padx=12, pady=(4, 6))

        active_cnt = len(tickets_db.get_active())
        emerg_text = "🚨  Аварийный список"
        if active_cnt:
            emerg_text += f"  ({active_cnt})"

        ctk.CTkButton(
            emerg_row, text=emerg_text,
            font=("Segoe UI", 12, "bold"),
            fg_color=COLOR_EMERG_BG, hover_color=COLOR_EMERG_HOVER,
            text_color=COLOR_TEXT, corner_radius=10,
            height=44, border_width=1, border_color=COLOR_DANGER,
            command=lambda: self.show_page("tickets")
        ).pack(fill="x")

        fh = ctk.CTkFrame(rp, fg_color="transparent", height=46)
        fh.pack(fill="x", padx=14, pady=(12, 0))
        fh.pack_propagate(False)
        ctk.CTkLabel(fh, text="📚  База знаний",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLOR_TEXT).pack(side="left")
        self.faq_count_label = ctk.CTkLabel(
            fh, text=f"{len(kb.chunks)}",
            font=("Segoe UI", 10, "bold"),
            text_color=COLOR_ON_ACCENT,
            fg_color=COLOR_ACCENT,
            corner_radius=8, padx=10, pady=3)
        self.faq_count_label.pack(side="right")

        ctk.CTkLabel(rp, text="Кликни по вопросу — он уйдёт в чат",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", padx=14, pady=(2, 6))

        self.recent_frame = ctk.CTkFrame(rp, fg_color="transparent")
        self.recent_frame.pack(fill="x", padx=12, pady=(0, 4))

        self.faq_scrollable = ctk.CTkScrollableFrame(
            rp, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.faq_scrollable.pack(fill="both", expand=True, padx=12, pady=(4, 8))
        self.load_faq_questions()

    def _setup_chat_tags(self):
        self.chat_text.tag_configure("bot_name", foreground=COLOR_BOT_NAME,
                                     font=("Segoe UI", 12, "bold"), spacing1=10)
        self.chat_text.tag_configure("user_name", foreground=COLOR_USER_NAME,
                                     font=("Segoe UI", 12, "bold"), spacing1=10)
        self.chat_text.tag_configure("time", foreground=COLOR_TEXT_MUTED,
                                     font=("Segoe UI", 9))
        self.chat_text.tag_configure("bot_text", foreground=COLOR_TEXT,
                                     font=("Segoe UI", 12),
                                     lmargin1=10, lmargin2=10, spacing3=10)
        self.chat_text.tag_configure("user_text", foreground=COLOR_TEXT,
                                     font=("Segoe UI", 12),
                                     lmargin1=10, lmargin2=10, spacing3=10)
        self.chat_text.tag_configure("diff_easy", foreground=COLOR_SUCCESS,
                                     font=("Segoe UI", 9, "bold"))
        self.chat_text.tag_configure("diff_medium", foreground=COLOR_ACCENT,
                                     font=("Segoe UI", 9, "bold"))
        self.chat_text.tag_configure("diff_hard", foreground=COLOR_ERROR,
                                     font=("Segoe UI", 9, "bold"))
        self.chat_text.tag_configure("fuzzy_hint", foreground=COLOR_ACCENT,
                                     font=("Segoe UI", 10, "italic"))
        self.chat_text.tag_configure("tags_line", foreground=COLOR_TEXT_MUTED,
                                     font=("Segoe UI", 9, "italic"),
                                     lmargin1=20, lmargin2=20)
        self.chat_text.tag_configure("views_line", foreground=COLOR_TEXT_MUTED,
                                     font=("Segoe UI", 9),
                                     lmargin1=20, lmargin2=20)
        self.chat_text.tag_configure("langame_badge", foreground="#a78bfa",
                                     font=("Segoe UI", 10, "bold"))
        self.chat_text.tag_configure("code", font=("Consolas", 11, "bold"),
                                     foreground=COLOR_CODE_TEXT,
                                     background=COLOR_CODE_BG,
                                     lmargin1=20, lmargin2=20,
                                     spacing1=2, spacing3=2)
        self.chat_text.tag_configure("copy_answer", foreground=COLOR_ACCENT,
                                     font=("Segoe UI", 10, "bold"),
                                     underline=True)
        self.chat_text.tag_configure("qr_answer", foreground="#a78bfa",
                                     font=("Segoe UI", 10, "bold"),
                                     underline=True)
        self.chat_text.tag_configure("feedback_up", foreground=COLOR_SUCCESS,
                                     font=("Segoe UI", 11, "bold"), underline=True)
        self.chat_text.tag_configure("feedback_down", foreground=COLOR_ERROR,
                                     font=("Segoe UI", 11, "bold"), underline=True)

    def _bind_chat_scroll(self):
        def on_wheel(e):
            d = e.delta
            if d == 0:
                return
            s = -int(d / 40) if abs(d) >= 40 else (-1 if d > 0 else 1)
            if s == 0:
                s = -1 if d > 0 else 1
            self.chat_text.yview_scroll(s * 3, "units")
            return "break"

        def on_wheel_lx(e):
            if e.num == 4:
                self.chat_text.yview_scroll(-3, "units")
            elif e.num == 5:
                self.chat_text.yview_scroll(3, "units")
            return "break"

        self.chat_text.bind("<MouseWheel>", on_wheel)
        self.chat_text.bind("<Button-4>", on_wheel_lx)
        self.chat_text.bind("<Button-5>", on_wheel_lx)

    def _cancel_typing(self, add_separator=True):
        was_typing = self.is_typing
        if self._typing_job is not None:
            try:
                self.app.after_cancel(self._typing_job)
            except Exception:
                pass
            self._typing_job = None
        self.is_typing = False
        if was_typing and add_separator:
            try:
                self.chat_text.configure(state="normal")
                self.chat_text.insert("end", "\n", "bot_text")
                self.chat_text.insert("end", "─" * 70 + "\n", "time")
                self.chat_text.configure(state="disabled")
                self.chat_text.see("end")
            except Exception:
                pass
        try:
            if hasattr(self, "send_btn"):
                self.send_btn.configure(state="normal")
            if hasattr(self, "input_entry"):
                self.input_entry.configure(state="normal")
                self.input_entry.focus()
        except Exception:
            pass

    def _append_action_buttons(self, text, kb_index=None):
        try:
            self.chat_text.insert("end", "   ", "time")
            self.chat_text.insert("end", "📋 Копировать", ("copy_answer", text))
            self.chat_text.insert("end", "     ", "time")
            self.chat_text.insert("end", "📱 QR", ("qr_answer", text))
            if kb_index is not None:
                self.chat_text.insert("end", "     ", "time")
                self.chat_text.insert("end", "📎 Файлы",
                                     ("attach_view", str(kb_index)))
            self.chat_text.insert("end", "\n\n", "time")

            self.chat_text.tag_bind("copy_answer", "<Button-1>",
                                    lambda e, t=text: self._copy_text_to_clipboard(t))
            self.chat_text.tag_bind("qr_answer", "<Button-1>",
                                    lambda e, t=text: self._show_qr_code(t))
            if kb_index is not None:
                self.chat_text.tag_bind("attach_view", "<Button-1>",
                                        lambda e, idx=kb_index:
                                        self._show_attachments_from_kb(idx))
            self.chat_text.tag_bind("copy_answer", "<Enter>",
                                    lambda e: self.chat_text.configure(cursor="hand2"))
            self.chat_text.tag_bind("copy_answer", "<Leave>",
                                    lambda e: self.chat_text.configure(cursor="arrow"))
            self.chat_text.tag_bind("qr_answer", "<Enter>",
                                    lambda e: self.chat_text.configure(cursor="hand2"))
            self.chat_text.tag_bind("qr_answer", "<Leave>",
                                    lambda e: self.chat_text.configure(cursor="arrow"))
            if kb_index is not None:
                self.chat_text.tag_bind("attach_view", "<Enter>",
                                        lambda e: self.chat_text.configure(cursor="hand2"))
                self.chat_text.tag_bind("attach_view", "<Leave>",
                                        lambda e: self.chat_text.configure(cursor="arrow"))
        except Exception as e:
            log_error(e, "_append_action_buttons")

    def _show_attachments_from_kb(self, index):
        atts = kb.get_attachments(index)
        self._show_attachments_window(f"Вложения — запись #{index}", atts)

    def _show_attachments_window(self, title, attachments):
        if not attachments:
            messagebox.showinfo("Вложения", "Нет вложений.")
            return
        win = ctk.CTkToplevel(self.app)
        win.title(title)
        win.geometry("520x500")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app)
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL, corner_radius=14,
                           border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(box, text=title, font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=16, pady=(14, 8))
        scroll = ctk.CTkScrollableFrame(box, fg_color=COLOR_BG,
                                        corner_radius=10,
                                        border_width=1,
                                        border_color=COLOR_BORDER)
        scroll.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        for att in attachments:
            row = ctk.CTkFrame(scroll, fg_color=COLOR_CARD,
                               corner_radius=9, border_width=1,
                               border_color=COLOR_BORDER)
            row.pack(fill="x", pady=3, padx=4)
            name = att.get("name", "?")
            fname = att.get("path", "")
            size = att.get("size", 0)
            icon = "📎"
            try:
                if HAS_ATTACHMENTS:
                    if attachments_module_is_image(name): icon = "🖼"
                    elif attachments_module_is_video(name): icon = "🎬"
                    elif attachments_module_is_audio(name): icon = "🎵"
            except Exception:
                pass
            ctk.CTkLabel(row, text=f"{icon}  {name}  ({size} МБ)",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT, anchor="w"
                         ).pack(side="left", padx=10, pady=8, fill="x", expand=True)
            ctk.CTkButton(row, text="Открыть", width=80, height=28,
                          font=("Segoe UI", 10, "bold"),
                          fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                          text_color=COLOR_ON_ACCENT,
                          command=lambda p=fname: self._open_attachment(p)
                          ).pack(side="right", padx=6, pady=6)
        self._ghost_button(box, "Закрыть", command=win.destroy,
                           width=120, height=36).pack(anchor="e", padx=16, pady=(0, 14))

    def _open_attachment(self, rel_path):
        if HAS_ATTACHMENTS:
            try:
                if attachments.open_attachment(rel_path):
                    return
            except Exception as e:
                log_error(e, "_open_attachment")
        messagebox.showerror("Ошибка", f"Не удалось открыть файл:\n{rel_path}")

    def _type_message_safe(self, text, sender="bot", difficulty=None, query=None,
                           fuzzy_hint=None, tags_line=None, views_line=None,
                           langame=False, show_actions=True, kb_index=None):
        self._cancel_typing(add_separator=False)
        self.is_typing = True

        self.chat_text.configure(state="normal")
        name = "🤖  Ассистент" if sender == "bot" else "👤  Вы"
        name_tag = "bot_name" if sender == "bot" else "user_name"
        text_tag = "bot_text" if sender == "bot" else "user_text"
        ts = datetime.now().strftime("%H:%M")

        self.chat_text.insert("end", name, name_tag)
        if sender == "bot":
            if langame:
                self.chat_text.insert("end", "  [📚 LANGame]", "langame_badge")
            if difficulty:
                diff_map = {
                    "easy": ("  [простой]", "diff_easy"),
                    "medium": ("  [средний]", "diff_medium"),
                    "hard": ("  [сложный]", "diff_hard")
                }
                dtext, dtag = diff_map.get(difficulty, ("", "time"))
                self.chat_text.insert("end", dtext, dtag)
        self.chat_text.insert("end", f"     {ts}\n", "time")
        if fuzzy_hint:
            self.chat_text.insert("end", fuzzy_hint + "\n", "fuzzy_hint")
        if tags_line:
            self.chat_text.insert("end", tags_line + "\n", "tags_line")
        self.chat_text.configure(state="disabled")

        self._last_copied_response = text

        total_len = len(text)
        chunk_size = 3 if total_len > 400 else 2
        delay = 15 if total_len < 300 else 8 if total_len < 800 else 4

        has_md_links = bool(extract_links(text))

        if has_md_links:
            self.chat_text.configure(state="normal")
            for line in text.split("\n"):
                self._insert_with_code_highlight(line, text_tag)
            self.chat_text.configure(state="normal")
            if views_line:
                self.chat_text.insert("end", views_line + "\n", "views_line")
            self.chat_text.insert("end", "\n", "bot_text")
            self.chat_text.insert("end", "─" * 70 + "\n", "time")
            if sender == "bot" and show_actions:
                self._append_action_buttons(text, kb_index=kb_index)
            self.chat_text.configure(state="disabled")
            self.chat_text.see("end")
            if sender == "bot" and query:
                self._append_feedback_links(query)
            self.is_typing = False
            self._typing_job = None
            try:
                self.send_btn.configure(state="normal")
                self.input_entry.configure(state="normal")
                self.input_entry.focus()
            except Exception:
                pass
            return

        def step(pos):
            if not self.chat_text.winfo_exists():
                self.is_typing = False
                return
            if pos >= total_len:
                self.chat_text.configure(state="normal")
                if views_line:
                    self.chat_text.insert("end", views_line + "\n", "views_line")
                self.chat_text.insert("end", "\n", "bot_text")
                self.chat_text.insert("end", "─" * 70 + "\n", "time")
                if sender == "bot" and show_actions:
                    self._append_action_buttons(text, kb_index=kb_index)
                self.chat_text.configure(state="disabled")
                self.chat_text.see("end")
                if sender == "bot" and query:
                    self._append_feedback_links(query)
                self.is_typing = False
                self._typing_job = None
                try:
                    self.send_btn.configure(state="normal")
                    self.input_entry.configure(state="normal")
                    self.input_entry.focus()
                except Exception:
                    pass
                return

            end = min(pos + chunk_size, total_len)
            chunk = text[pos:end]
            self.chat_text.configure(state="normal")
            self.chat_text.insert("end", chunk, text_tag)
            self.chat_text.configure(state="disabled")
            self.chat_text.see("end")
            d = delay
            if not chunk.strip():
                d = max(2, delay // 3)
            self._typing_job = self.app.after(d, lambda: step(end))

        step(0)
    def _copy_text_to_clipboard(self, text):
        try:
            self.app.clipboard_clear()
            self.app.clipboard_append(text)
            self.status_label.configure(text="✅ Скопировано в буфер", text_color=COLOR_SUCCESS)
            self.app.after(2000, lambda: self.status_label.configure(
                text="●  Готов к работе", text_color=COLOR_SUCCESS))
        except Exception as e:
            log_error(e, "_copy_text_to_clipboard")

    def _show_qr_code(self, text):
        if not HAS_QR:
            messagebox.showerror(
                "QR-код недоступен",
                "Для генерации QR-кода установите библиотеки:\n\n"
                "pip install qrcode[pil] pillow")
            return
        try:
            qr = qrcode.QRCode(version=None,
                               error_correction=qrcode.constants.ERROR_CORRECT_M,
                               box_size=8, border=2)
            qr.add_data(text)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

            tmp_dir = os.path.join(DATA_DIR, "tmp")
            os.makedirs(tmp_dir, exist_ok=True)
            qr_path = os.path.join(tmp_dir, f"qr_{int(time.time()*1000)}.png")
            img.save(qr_path)

            win = ctk.CTkToplevel(self.app)
            win.title("📱 QR-код ответа")
            win.geometry("560x720")
            win.configure(fg_color=COLOR_BG)
            win.transient(self.app)

            box = ctk.CTkFrame(win, fg_color=COLOR_PANEL,
                               corner_radius=14, border_width=1,
                               border_color=COLOR_BORDER)
            box.pack(fill="both", expand=True, padx=20, pady=20)

            ctk.CTkLabel(box, text="📱  QR-код ответа",
                         font=("Segoe UI", 16, "bold"),
                         text_color=COLOR_ACCENT).pack(anchor="w", padx=16, pady=(14, 2))
            ctk.CTkLabel(box,
                         text="Наведи камеру телефона — откроется текст ответа.\n"
                              "Покажи экран клиенту.",
                         font=("Segoe UI", 10, "italic"),
                         text_color=COLOR_TEXT_MUTED,
                         anchor="w", justify="left", wraplength=500
                         ).pack(fill="x", padx=16, pady=(0, 8))

            qr_size = 380
            pil_img = img.resize((qr_size, qr_size))
            ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img,
                                   size=(qr_size, qr_size))
            lbl = ctk.CTkLabel(box, image=ctk_img, text="")
            lbl.image = ctk_img
            lbl.pack(pady=10)

            preview = text if len(text) <= 200 else text[:200] + "..."
            txt = ctk.CTkTextbox(box, font=("Consolas", 10), height=120,
                                 fg_color=COLOR_BG, text_color=COLOR_TEXT,
                                 corner_radius=10, wrap="word")
            txt.pack(fill="x", padx=16, pady=(4, 8))
            txt.insert("1.0", preview)
            txt.configure(state="disabled")

            btn_row = ctk.CTkFrame(box, fg_color="transparent")
            btn_row.pack(fill="x", padx=16, pady=(0, 14))
            self._ghost_button(btn_row, "💾  Сохранить PNG",
                               command=lambda: self._save_qr_png(img),
                               width=170, height=38).pack(side="left")
            self._ghost_button(btn_row, "Закрыть",
                               command=win.destroy,
                               width=120, height=38).pack(side="right")
        except Exception as e:
            log_error(e, "_show_qr_code")
            messagebox.showerror("Ошибка QR", f"Не удалось создать QR-код:\n{e}")

    def _save_qr_png(self, img):
        try:
            path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG", "*.png")],
                initialfile=f"qr_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
            if not path:
                return
            img.save(path)
            messagebox.showinfo("Готово", f"✅ QR сохранён:\n{path}")
        except Exception as e:
            log_error(e, "_save_qr_png")
            messagebox.showerror("Ошибка", str(e))

    def _append_feedback_links(self, query):
        self.chat_text.insert("end", "   ", "time")
        self.chat_text.insert("end", "✅ Помогло", ("feedback_up", query))
        self.chat_text.insert("end", "     ", "time")
        self.chat_text.insert("end", "❌ Не помогло", ("feedback_down", query))
        self.chat_text.insert("end", "\n\n", "time")
        self.chat_text.tag_bind("feedback_up", "<Button-1>",
                                lambda e, q=query: self.feedback_up(q))
        self.chat_text.tag_bind("feedback_down", "<Button-1>",
                                lambda e, q=query: self.feedback_down(q))

    def feedback_up(self, query):
        kb.rate(query, True)
        self.add_bot_message("🙌  Спасибо! Рад, что помогло.", show_actions=False)

    def feedback_down(self, query):
        kb.rate(query, False)
        self.open_suggest_dialog(question=query, source="bad_answer")

    def add_bot_message(self, text, difficulty=None, query=None, animate=True,
                        fuzzy_hint=None, show_actions=True):
        if animate:
            self._type_message_safe(text, sender="bot", difficulty=difficulty,
                                    query=query, fuzzy_hint=fuzzy_hint,
                                    show_actions=show_actions)
        else:
            self.chat_text.configure(state="normal")
            name = "🤖  Ассистент"
            ts = datetime.now().strftime("%H:%M")
            self.chat_text.insert("end", name, "bot_name")
            if difficulty:
                diff_map = {
                    "easy": ("  [простой]", "diff_easy"),
                    "medium": ("  [средний]", "diff_medium"),
                    "hard": ("  [сложный]", "diff_hard")
                }
                dtext, dtag = diff_map.get(difficulty, ("", "time"))
                self.chat_text.insert("end", dtext, dtag)
            self.chat_text.insert("end", f"     {ts}\n", "time")
            if fuzzy_hint:
                self.chat_text.insert("end", fuzzy_hint + "\n", "fuzzy_hint")
            for line in text.split("\n"):
                self._insert_with_code_highlight(line, "bot_text")
            self.chat_text.insert("end", "─" * 70 + "\n", "time")
            if show_actions:
                self._append_action_buttons(text)
            if query:
                self._append_feedback_links(query)
            self.chat_text.configure(state="disabled")
            self.chat_text.see("end")

    def add_user_message(self, text):
        self.chat_text.configure(state="normal")
        name = "👤  Вы"
        ts = datetime.now().strftime("%H:%M")
        self.chat_text.insert("end", name, "user_name")
        self.chat_text.insert("end", f"     {ts}\n", "time")
        self.chat_text.insert("end", text + "\n", "user_text")
        self.chat_text.insert("end", "─" * 70 + "\n", "time")
        self.chat_text.configure(state="disabled")
        self.chat_text.see("end")

    def _insert_with_code_highlight(self, text, base_tag):
        try:
            spans = []
            for pat in CODE_PATTERNS:
                for m in re.finditer(pat, text):
                    spans.append((m.start(), m.end(), "code", None))
            for s, e, label, url in extract_links(text):
                spans.append((s, e, "link", (label, url)))
            spans.sort(key=lambda x: (x[0], x[1]))

            merged = []
            for s, e, kind, extra in spans:
                if merged and s < merged[-1][1]:
                    continue
                merged.append((s, e, kind, extra))

            if not merged:
                self.chat_text.insert("end", text + "\n", base_tag)
                return

            pos = 0
            for s, e, kind, extra in merged:
                if pos < s:
                    self.chat_text.insert("end", text[pos:s], base_tag)
                if kind == "code":
                    self.chat_text.insert("end", text[s:e], "code")
                else:
                    label, url = extra
                    tag_name = f"mdlink_{abs(hash(url)) % 1000000}_{s}"
                    self.chat_text.tag_configure(
                        tag_name, foreground="#4ea1ff",
                        font=("Segoe UI", 12, "underline"))
                    self.chat_text.insert("end", label, tag_name)
                    self.chat_text.tag_bind(
                        tag_name, "<Button-1>", lambda ev, u=url: open_url(u))
                    self.chat_text.tag_bind(
                        tag_name, "<Enter>",
                        lambda ev: self.chat_text.configure(cursor="hand2"))
                    self.chat_text.tag_bind(
                        tag_name, "<Leave>",
                        lambda ev: self.chat_text.configure(cursor="arrow"))
                pos = e
            if pos < len(text):
                self.chat_text.insert("end", text[pos:], base_tag)
            self.chat_text.insert("end", "\n", base_tag)
        except Exception as e:
            log_error(e, "_insert_with_code_highlight")
            self.chat_text.insert("end", text + "\n", base_tag)

    def load_faq_questions(self):
        if not hasattr(self, "faq_scrollable"):
            return
        for w in self.faq_scrollable.winfo_children():
            w.destroy()
        self.render_recent_queries()
        categories = {}
        for i, chunk in enumerate(kb.chunks):
            m = kb.metadata[i] if i < len(kb.metadata) else {}
            if m.get("source") == "langame":
                continue
            cat = m.get("category", "общие")
            q_text, _ = chunk_to_qa(chunk)
            if not q_text:
                continue
            categories.setdefault(cat, []).append((i, q_text))

        cat_icons = {"игры": "🎮", "периферия": "🎤", "софт": "🛠️",
                     "админ": "🏢", "сеть": "📡", "общие": "💻"}
        for cat_name, items in sorted(categories.items()):
            icon = cat_icons.get(cat_name, "📂")
            cr = ctk.CTkFrame(self.faq_scrollable, fg_color="transparent")
            cr.pack(fill="x", padx=6, pady=(8, 4))
            ctk.CTkLabel(cr, text=f"{icon}  {cat_name.upper()}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left")
            ctk.CTkLabel(cr, text=f"{len(items)}",
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_MUTED).pack(side="right")
            for kb_index, q_text in items:
                display_q = MD_LINK_PATTERN.sub(r"\1", q_text)
                ctk.CTkButton(
                    self.faq_scrollable, text=display_q,
                    font=("Segoe UI", 11), height=34, corner_radius=9,
                    fg_color=COLOR_CARD, hover_color=COLOR_CARD_HOVER,
                    text_color=COLOR_TEXT, border_width=1, border_color=COLOR_BORDER,
                    anchor="w",
                    command=lambda idx=kb_index: self.quick_question_by_index(idx)
                ).pack(fill="x", padx=6, pady=2)
        try:
            self.faq_count_label.configure(text=f"{len(kb.chunks)}")
        except Exception:
            pass

    def quick_question_by_index(self, kb_index):
        try:
            if not (0 <= kb_index < len(kb.chunks)):
                return
            chunk = kb.chunks[kb_index]
            q_text, a_text = chunk_to_qa(chunk)
            difficulty = kb.difficulty[kb_index] if kb_index < len(kb.difficulty) else None
            m = kb.metadata[kb_index] if kb_index < len(kb.metadata) else {}
            tags = m.get("tags", [])
            is_langame = m.get("source") == "langame"

            if self.is_typing:
                self._cancel_typing()

            self.last_query = q_text
            self.add_user_message(q_text)
            self.history.append({"role": "user", "text": q_text})

            views = kb.increment_views(kb_index)

            response = f"📖  Ответ из базы:\n\n📌  {q_text}\n\n{a_text}"
            tags_line = f"🏷️ Теги: {', '.join(tags)}" if tags else None
            views_line = f"👁️ Просмотров: {views}"

            kb.log_search(q_text, found=True)
            self._type_message_safe(response, sender="bot",
                                    difficulty=difficulty,
                                    fuzzy_hint=None,
                                    tags_line=tags_line,
                                    views_line=views_line,
                                    langame=is_langame,
                                    show_actions=True,
                                    kb_index=kb_index)
            self.last_response = response
            self.history.append({"role": "assistant", "text": response})
            self.msg_count.configure(text=f"Сообщений: {len(self.history)}")
            self.status_label.configure(text="●  Готов к работе", text_color=COLOR_SUCCESS)
            self.render_recent_queries()
        except Exception as e:
            log_error(e, "quick_question_by_index")

    def render_recent_queries(self):
        if not hasattr(self, "recent_frame"):
            return
        for w in self.recent_frame.winfo_children():
            w.destroy()
        recent = kb.get_recent_unique(limit=4)
        if not recent:
            return
        ctk.CTkLabel(self.recent_frame, text="🕐  Недавние",
                     font=("Segoe UI", 10, "bold"),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", padx=2, pady=(2, 4))
        for q in recent:
            display_q = MD_LINK_PATTERN.sub(r"\1", q)
            ctk.CTkButton(
                self.recent_frame,
                text=f"↻  {display_q[:36]}{'...' if len(display_q) > 36 else ''}",
                font=("Segoe UI", 10), height=26, corner_radius=8,
                fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                text_color=COLOR_TEXT_DIM, anchor="w",
                command=lambda query=q: self.quick_question(query)
            ).pack(fill="x", pady=1)

    def quick_question(self, question):
        self.input_entry.delete(0, "end")
        self.input_entry.insert(0, question)
        self.send_message()

    def send_message(self):
        if self.is_typing:
            self._cancel_typing()

        query = self.input_entry.get().strip()
        if not query:
            return

        self.last_query = query
        self.add_user_message(query)
        self.history.append({"role": "user", "text": query})
        self.input_entry.delete(0, "end")
        self.save_draft()
        self.msg_count.configure(text=f"Сообщений: {len(self.history)}")
        self.status_label.configure(text="🔍  Поиск...", text_color=COLOR_ACCENT)
        self.send_btn.configure(state="disabled")
        self.input_entry.configure(state="disabled")

        results = kb.search(query, source="all")
        kb.log_search(query, found=bool(results))

        if not results:
            self.fail_streak += 1
            if self.fail_streak >= 5:
                import random
                phrase = random.choice(BOT_TIRED_PHRASES)
                self._type_message_safe(phrase, sender="bot", show_actions=True)
                self.last_response = phrase
                self.history.append({"role": "assistant", "text": phrase})
                self.msg_count.configure(text=f"Сообщений: {len(self.history)}")
                self.status_label.configure(text="●  Готов к работе", text_color=COLOR_SUCCESS)
                try:
                    self.send_btn.configure(state="normal")
                    self.input_entry.configure(state="normal")
                    self.input_entry.focus()
                except Exception:
                    pass
                self.fail_streak = 0
            else:
                similar = []
                qw = normalize_text(query).split()
                qw = dictionaries.clean_stop_words(qw)
                for item in ALL_QUESTIONS:
                    qn = normalize_text(item["question"])
                    hits = sum(1 for w in qw if len(w) >= 2 and w in qn)
                    if hits > 0:
                        similar.append((item["question"], hits))
                similar.sort(key=lambda x: x[1], reverse=True)
                similar = similar[:3]
                response = "😅  Не нашёл точного ответа.\n"
                if similar:
                    response += "\n💡  Возможно, тебе подойдёт:\n"
                    for q, _ in similar:
                        response += f"     •  {q}\n"
                else:
                    response += "\n💡  Попробуй переформулировать или обратись к администратору.\n"
                response += "\n✍️  Знаешь ответ? Нажми «Не помогло» ниже — предложи свой."
                self._type_message_safe(response, sender="bot", show_actions=False)
                self.last_response = response
                self.history.append({"role": "assistant", "text": response})
                self.msg_count.configure(text=f"Сообщений: {len(self.history)}")
                self.status_label.configure(text="●  Готов к работе", text_color=COLOR_SUCCESS)
                self.chat_text.configure(state="normal")
                self.chat_text.insert("end", "   ", "time")
                self.chat_text.insert("end", "✍️ Напиши правильный ответ",
                                     ("feedback_down", query))
                self.chat_text.insert("end", "\n\n", "time")
                self.chat_text.tag_bind("feedback_down", "<Button-1>",
                                        lambda e, q=query: self.open_suggest_dialog(
                                            question=q, source="no_answer"))
                self.chat_text.configure(state="disabled")
                self.chat_text.see("end")
                try:
                    self.send_btn.configure(state="normal")
                    self.input_entry.configure(state="normal")
                    self.input_entry.focus()
                except Exception:
                    pass
        else:
            self.fail_streak = 0
            best = results[0]
            is_fuzzy = best.get("fuzzy", False)
            fuzzy_hint = None
            if is_fuzzy:
                fuzzy_hint = f"🔍 Похоже, ты имел в виду именно это (точность {int(best['similarity']*100)}%)"

            idx = best["index"]
            m = kb.metadata[idx] if idx < len(kb.metadata) else {}
            is_langame = m.get("source") == "langame"
            tags = m.get("tags", [])
            views = kb.increment_views(idx)

            text = best["text"]
            if "Вопрос:" in text and "Ответ:" in text:
                parts = text.split("Ответ:")
                qp = parts[0].replace("Вопрос:", "").strip()
                ap = parts[1].strip() if len(parts) > 1 else text
                response = f"📖  Нашёл ответ!\n\n📌  {qp}\n\n{ap}"
            else:
                response = "📖  Нашёл ответ!\n\n" + text

            tags_line = f"🏷️ Теги: {', '.join(tags)}" if tags else None
            views_line = f"👁️ Просмотров: {views}"

            self._type_message_safe(response, sender="bot",
                                    difficulty=best["difficulty"],
                                    query=query,
                                    fuzzy_hint=fuzzy_hint,
                                    tags_line=tags_line,
                                    views_line=views_line,
                                    langame=is_langame,
                                    show_actions=True,
                                    kb_index=idx)
            self.last_response = response
            self.history.append({"role": "assistant", "text": response})
            self.msg_count.configure(text=f"Сообщений: {len(self.history)}")
            self.status_label.configure(text="●  Готов к работе", text_color=COLOR_SUCCESS)
            self.render_recent_queries()

    def open_suggest_dialog(self, question="", source="no_answer"):
        win = ctk.CTkToplevel(self.app)
        win.title("✍️  Предложить ответ")
        win.geometry("620x560")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app); win.grab_set()
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL, corner_radius=14,
                           border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(box, text="✍️  Предложить ответ",
                     font=("Segoe UI", 18, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=20, pady=(20, 4))
        ctk.CTkLabel(box, text="Твой ответ отправится на проверку админу.",
                     font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED,
                     justify="left").pack(anchor="w", padx=20, pady=(0, 16))
        ctk.CTkLabel(box, text="Вопрос", font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20)
        q_entry = ctk.CTkEntry(box, font=("Segoe UI", 12), height=40,
                               fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=10)
        q_entry.pack(fill="x", padx=20, pady=(4, 12))
        self._attach_clipboard_support(q_entry)
        q_entry.insert(0, question)
        ctk.CTkLabel(box, text="Правильный ответ", font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20)
        a_text = ctk.CTkTextbox(box, font=("Segoe UI", 12), height=150,
                                fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                border_width=1, text_color=COLOR_TEXT,
                                corner_radius=10, wrap="word")
        a_text.pack(fill="both", expand=True, padx=20, pady=(4, 12))
        self._attach_clipboard_support(a_text)
        role_icon = UsersDB.ROLES.get(self.current_role, {}).get("icon", "👤")
        role_name = UsersDB.ROLES.get(self.current_role, {}).get("name", "—")
        ctk.CTkLabel(box, text="Отправитель:", font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20)
        ctk.CTkLabel(box, text=f"{role_icon}  {self.current_user}  ({role_name})",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=20, pady=(4, 16))

        def submit():
            q = q_entry.get().strip()
            a = a_text.get("1.0", "end").strip()
            name = self.current_user or "Аноним"
            if not q or not a:
                messagebox.showerror("Ошибка", "❌ Заполните вопрос и ответ!")
                return
            suggestions_db.add(q, a, name, source)
            journal_db.log(self.current_user, self.current_role,
                           "Предложил ответ", q[:100])
            messagebox.showinfo("Готово", "✅ Спасибо! Отправлено на проверку.")
            win.destroy()
            self.add_bot_message("🙏  Спасибо! Твой ответ ушёл админу.",
                                 show_actions=False)

        btn_row = ctk.CTkFrame(box, fg_color="transparent")
        btn_row.pack(fill="x", padx=20, pady=(0, 20))
        self._accent_button(btn_row, "📨  Отправить",
                            command=submit, width=180, height=42).pack(side="left")
        self._ghost_button(btn_row, "Отмена",
                           command=win.destroy, width=120, height=42).pack(side="right")

    # =================================================================
    # ============ ТИКЕТЫ ============================================
    # =================================================================
    def _attach_files_dialog(self, target_type, target_data):
        if not HAS_ATTACHMENTS:
            messagebox.showerror("Ошибка",
                                 "Модуль attachments не загружен.\n\n"
                                 "Проверьте, что файл attachments.py лежит рядом с app.py.")
            return target_data.get("files", [])
        max_files = getattr(attachments, "MAX_FILES_PER_ITEM", 3)
        existing = list(target_data.get("files", []))
        if len(existing) >= max_files:
            messagebox.showinfo("Лимит", f"Уже {len(existing)} файлов. Максимум — {max_files}.")
            return existing

        remaining = max_files - len(existing)
        path = filedialog.askopenfilename(
            title=f"Выберите файл (можно прикрепить ещё {remaining})",
            filetypes=[
                ("Изображения", "*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp"),
                ("Видео", "*.mp4;*.avi;*.mkv;*.mov"),
                ("Аудио", "*.mp3;*.wav;*.ogg;*.m4a"),
                ("Документы", "*.pdf;*.txt;*.docx;*.zip"),
                ("Все файлы", "*.*"),
            ])
        if not path:
            return existing

        ok, result = attachments.save_attachment(path)
        if not ok:
            messagebox.showerror("Ошибка", f"❌ {result}")
            return existing

        existing.append(result)
        target_data["files"] = existing
        messagebox.showinfo("Готово", f"✅ Прикреплено: {result['name']} ({result['size']} МБ)")
        return existing


    def build_tickets_page(self):
        for w in self.page_tickets.winfo_children():
            w.destroy()
        container = ctk.CTkFrame(self.page_tickets, fg_color="transparent")
        container.pack(fill="both", expand=True)

        form_panel = ctk.CTkFrame(container, fg_color=COLOR_PANEL,
                                  corner_radius=16, border_width=1,
                                  border_color=COLOR_BORDER, width=540)
        form_panel.pack(side="left", fill="y", padx=(0, 10))
        form_panel.pack_propagate(False)

        ctk.CTkLabel(form_panel, text="🚨  Новый тикет",
                     font=("Segoe UI", 17, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=20, pady=(16, 4))
        ctk.CTkLabel(form_panel, text="Сообщи о технической проблеме с ПК",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", padx=20, pady=(0, 12))

        ctk.CTkLabel(form_panel, text="1.  Номер ПК *",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20, pady=(4, 2))
        pc_entry = ctk.CTkEntry(form_panel, placeholder_text="Например: ПК-7 или 7",
                                placeholder_text_color=COLOR_TEXT_MUTED,
                                font=("Segoe UI", 12), height=40,
                                fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                text_color=COLOR_TEXT, corner_radius=10)
        pc_entry.pack(fill="x", padx=20, pady=(0, 8))
        self._attach_clipboard_support(pc_entry)

        ctk.CTkLabel(form_panel, text="2.  Зона *",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20, pady=(4, 2))
        zone_menu = ctk.CTkOptionMenu(
            form_panel, values=["стандарт", "VIP", "PS5", "bootcamp"],
            font=("Segoe UI", 12), height=36, width=180,
            fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK, button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=10)
        zone_menu.set("стандарт")
        zone_menu.pack(anchor="w", padx=20, pady=(0, 8))

        ctk.CTkLabel(form_panel, text="3.  Проблема *",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20, pady=(4, 2))
        problem_text = ctk.CTkTextbox(form_panel, font=("Segoe UI", 12), height=80,
                                      fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                      border_width=1, text_color=COLOR_TEXT,
                                      corner_radius=10, wrap="word")
        problem_text.pack(fill="x", padx=20, pady=(0, 4))
        self._attach_clipboard_support(problem_text)

        self.autocomplete_frame = ctk.CTkFrame(form_panel, fg_color=COLOR_BG,
                                               corner_radius=10,
                                               border_width=1, border_color=COLOR_BORDER)
        self.autocomplete_label = ctk.CTkLabel(
            self.autocomplete_frame, text="",
            font=("Segoe UI", 10), text_color=COLOR_TEXT_DIM,
            justify="left", anchor="w", wraplength=460)
        self.autocomplete_label.pack(fill="x", padx=10, pady=6)

        def on_problem_change(event=None):
            if self._autocomplete_job is not None:
                try:
                    self.app.after_cancel(self._autocomplete_job)
                except Exception:
                    pass
            self._autocomplete_job = self.app.after(
                AUTOCOMPLETE_DEBOUNCE_MS,
                lambda: self._run_autocomplete(problem_text,
                                               self.autocomplete_frame,
                                               self.autocomplete_label))
        problem_text.bind("<KeyRelease>", on_problem_change)

        ctk.CTkLabel(form_panel, text="4.  Приоритет *",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20, pady=(4, 2))
        priority_menu = ctk.CTkOptionMenu(
            form_panel, values=list(TICKET_PRIORITIES.keys()),
            font=("Segoe UI", 12), height=36, width=180,
            fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK, button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=10)
        priority_menu.set("medium")
        priority_menu.pack(anchor="w", padx=20, pady=(0, 8))

        ctk.CTkLabel(form_panel, text="5.  Исполнитель",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=20, pady=(4, 2))
        assignees_list = users_db.list_admins_and_techs() or ["—"]
        assignee_menu = ctk.CTkOptionMenu(
            form_panel, values=assignees_list,
            font=("Segoe UI", 12), height=36, width=180,
            fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK, button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=10)
        if self.current_user and self.current_user in assignees_list:
            assignee_menu.set(self.current_user)
        else:
            assignee_menu.set(assignees_list[0])
        assignee_menu.pack(anchor="w", padx=20, pady=(0, 8))

        # ---- Вложения (создание тикета) ----
        attach_state = {"files": []}
        attach_frame = ctk.CTkFrame(form_panel, fg_color="transparent")
        attach_frame.pack(fill="x", padx=20, pady=(4, 4))
        ctk.CTkLabel(attach_frame, text="6.  Вложения",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 8))
        attach_label = ctk.CTkLabel(attach_frame, text="(0/3)",
                                    font=("Segoe UI", 10),
                                    text_color=COLOR_TEXT_MUTED)
        attach_label.pack(side="left")

        def attach_files():
            files = self._attach_files_dialog("ticket", attach_state)
            attach_state["files"] = files
            attach_label.configure(text=f"({len(files)}/3)")

        self._ghost_button(form_panel, "📎  Прикрепить файл",
                           command=attach_files,
                           width=180, height=34).pack(anchor="w", padx=20, pady=(0, 8))

        author_row = ctk.CTkFrame(form_panel, fg_color="transparent")
        author_row.pack(fill="x", padx=20, pady=(4, 12))
        ctk.CTkLabel(author_row, text="7.  Отправитель:",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 8))
        role_icon = UsersDB.ROLES.get(self.current_role, {}).get("icon", "👤")
        role_name = UsersDB.ROLES.get(self.current_role, {}).get("name", "—")
        ctk.CTkLabel(author_row,
                     text=f"{role_icon}  {self.current_user}  ({role_name})",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")

        def submit_ticket():
            pc = pc_entry.get().strip()
            prob = problem_text.get("1.0", "end").strip()
            priority = priority_menu.get()
            zone = zone_menu.get()
            author = self.current_user or "Гость"
            assignee = assignee_menu.get()
            if assignee == "—":
                assignee = ""
            if not pc or not prob:
                messagebox.showerror("Ошибка", "ПК и проблема обязательны!")
                return
            t = tickets_db.add(pc, prob, priority, author, priority=priority,
                               zone=zone, assignee=assignee)
            # прикрепляем файлы
            for f in attach_state.get("files", []):
                tickets_db.add_attachment(t["id"], f)
            self._last_notified_ticket_id = tickets_db.get_max_id()
            journal_db.log(self.current_user, self.current_role,
                           "Создал тикет", f"ПК {pc} [{priority}]")
            messagebox.showinfo("Готово", "✅ Тикет создан!")
            pc_entry.delete(0, "end")
            problem_text.delete("1.0", "end")
            priority_menu.set("medium")
            zone_menu.set("стандарт")
            if self.current_user and self.current_user in assignees_list:
                assignee_menu.set(self.current_user)
            else:
                assignee_menu.set(assignees_list[0])
            attach_state["files"] = []
            attach_label.configure(text="(0/3)")
            self.autocomplete_frame.pack_forget()
            self.refresh_tickets_list()

        self._accent_button(form_panel, "📨  Отправить тикет",
                            command=submit_ticket,
                            width=200, height=44).pack(anchor="w", padx=20, pady=(0, 16))

        list_panel = ctk.CTkFrame(container, fg_color=COLOR_PANEL,
                                  corner_radius=16, border_width=1,
                                  border_color=COLOR_BORDER)
        list_panel.pack(side="right", fill="both", expand=True)

        lh = ctk.CTkFrame(list_panel, fg_color="transparent", height=56)
        lh.pack(fill="x", padx=18, pady=(14, 0))
        lh.pack_propagate(False)
        ctk.CTkLabel(lh, text="📋  Активные заявки",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_TEXT).pack(side="left")
        self.tickets_count_label = ctk.CTkLabel(lh, text="0",
                                                font=("Segoe UI", 10, "bold"),
                                                text_color="#fff", fg_color=COLOR_ERROR,
                                                corner_radius=8, padx=10, pady=3)
        self.tickets_count_label.pack(side="right")

        self.tickets_scrollable = ctk.CTkScrollableFrame(
            list_panel, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.tickets_scrollable.pack(fill="both", expand=True, padx=18, pady=(8, 18))
        self.refresh_tickets_list()

    def _run_autocomplete(self, textbox, frame, label):
        try:
            text = textbox.get("1.0", "end").strip()
            self._autocomplete_job = None
            if len(text) < 4:
                frame.pack_forget()
                return
            lines = []
            q_norm = normalize_text(text)
            qw = q_norm.split()
            qw = dictionaries.clean_stop_words(qw)
            similar_tickets = []
            for t in tickets_db.get_all()[:200]:
                prob_norm = normalize_text(t.get("problem", ""))
                hits = sum(1 for w in qw if len(w) >= 3 and w in prob_norm)
                if hits > 0:
                    similar_tickets.append((t, hits))
            similar_tickets.sort(key=lambda x: x[1], reverse=True)
            similar_tickets = similar_tickets[:3]
            res = kb.search(text, top_k=3, source="all")
            if similar_tickets:
                lines.append("🎫 Похожие тикеты:")
                for t, _ in similar_tickets:
                    lines.append(f"   #{t['id']} ПК {t.get('pc','?')} — {t.get('problem','')[:55]}")
            if res:
                lines.append("📚 Возможно, из базы:")
                for r in res:
                    q_txt = chunk_to_qa(r["text"])[0]
                    lines.append(f"   • {q_txt[:55]}")
            if lines:
                label.configure(text="\n".join(lines))
                frame.pack(fill="x", padx=20, pady=(0, 8))
            else:
                frame.pack_forget()
        except Exception as e:
            log_error(e, "_run_autocomplete")

    def refresh_tickets_list(self):
        if not hasattr(self, "tickets_scrollable") or not self.tickets_scrollable.winfo_exists():
            return
        for w in self.tickets_scrollable.winfo_children():
            w.destroy()
        all_tickets = tickets_db.get_all()
        active = [t for t in all_tickets
                  if t.get("status") not in ("resolved", "closed")]
        try:
            self.tickets_count_label.configure(text=str(len(active)))
        except Exception:
            pass
        if not all_tickets:
            ctk.CTkLabel(self.tickets_scrollable,
                         text="📭  Пока нет ни одной заявки",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return
        for t in all_tickets:
            self._render_ticket_card(self.tickets_scrollable, t, admin_view=False)

    def _render_ticket_card(self, parent, t, admin_view=False, archive_view=False):
        status = t.get("status", "new")
        priority = t.get("priority", "medium")
        st = TICKET_STATUSES.get(status, TICKET_STATUSES["new"])
        pr = TICKET_PRIORITIES.get(priority, TICKET_PRIORITIES["medium"])

        is_stale = tickets_db.is_stale(t) and status in ("new", "in_progress")
        border_col = pr["color"] if is_stale else st["color"]

        card = ctk.CTkFrame(parent, fg_color=COLOR_CARD, corner_radius=12,
                            border_width=2, border_color=border_col)
        card.pack(fill="x", pady=5, padx=4)

        top = ctk.CTkFrame(card, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(10, 4))

        pc_label = ctk.CTkLabel(top,
                                text=f"#{t['id']}  •  ПК {t.get('pc', '?')}  •  {t.get('zone', 'стандарт')}",
                                font=("Segoe UI", 13, "bold"),
                                text_color=COLOR_TEXT)
        pc_label.pack(side="left")
        pc_label.bind("<Button-1>",
                      lambda e, pc=t.get("pc", ""): self._show_pc_history(pc))
        pc_label.configure(cursor="hand2")

        badges = ctk.CTkFrame(top, fg_color="transparent")
        badges.pack(side="right")
        ctk.CTkLabel(badges, text=pr["name"],
                     font=("Segoe UI", 9, "bold"),
                     text_color=pr["color"], fg_color=COLOR_BG,
                     corner_radius=6, padx=8, pady=2).pack(side="left", padx=(0, 4))
        ctk.CTkLabel(badges, text=st["name"],
                     font=("Segoe UI", 9, "bold"),
                     text_color=st["color"], fg_color=COLOR_BG,
                     corner_radius=6, padx=8, pady=2).pack(side="left")

        if is_stale:
            ctk.CTkLabel(top, text="⚠️ ВИСИТ",
                         font=("Segoe UI", 9, "bold"),
                         text_color="#fff", fg_color=COLOR_ERROR,
                         corner_radius=6, padx=6, pady=2).pack(side="right", padx=(0, 6))

        meta = ctk.CTkFrame(card, fg_color="transparent")
        meta.pack(fill="x", padx=12, pady=(0, 4))
        ctk.CTkLabel(meta, text=f"👤  {t.get('author', '?')}",
                     font=("Segoe UI", 10, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left", padx=(0, 6))
        assignee = t.get("assignee", "").strip()
        if assignee:
            ctk.CTkLabel(meta, text="→",
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_MUTED).pack(side="left", padx=(0, 6))
            ctk.CTkLabel(meta, text=f"🛠  {assignee}",
                         font=("Segoe UI", 10, "bold"),
                         text_color=COLOR_SUCCESS).pack(side="left", padx=(0, 10))
        try:
            dt = datetime.fromisoformat(t.get("created", "")).strftime("%d.%m  %H:%M")
        except Exception:
            dt = "?"
        ctk.CTkLabel(meta, text=f"🕐 {dt}",
                     font=("Segoe UI", 9),
                     text_color=COLOR_TEXT_MUTED).pack(side="left")

        prob_box = ctk.CTkFrame(card, fg_color=COLOR_BG, corner_radius=8)
        prob_box.pack(fill="x", padx=12, pady=(2, 8))
        problem_text = t.get("problem", "")
        problem_display = MD_LINK_PATTERN.sub(r"\1", problem_text)
        prob_label = tk.Label(
            prob_box, text=problem_display,
            font=("Segoe UI", 11),
            fg=COLOR_TEXT, bg=COLOR_BG,
            justify="left", anchor="w", wraplength=520)
        prob_label.pack(fill="x", padx=10, pady=8)

        links_in_problem = extract_links(problem_text)
        if links_in_problem:
            link_row = tk.Frame(prob_box, bg=COLOR_BG)
            link_row.pack(fill="x", padx=10, pady=(0, 8))
            for _, _, label, url in links_in_problem:
                lbl = tk.Label(link_row, text=f"🔗 {label}",
                               font=("Segoe UI", 10, "underline"),
                               fg="#4ea1ff", bg=COLOR_BG, cursor="hand2")
                lbl.pack(side="left", padx=(0, 10))
                lbl.bind("<Button-1>", lambda e, u=url: open_url(u))

        # Вложения
        atts = t.get("attachments", [])
        if atts:
            att_row = ctk.CTkFrame(card, fg_color="transparent")
            att_row.pack(fill="x", padx=12, pady=(0, 6))
            ctk.CTkLabel(att_row, text=f"📎 {len(atts)} файл(ов):",
                         font=("Segoe UI", 10, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left", padx=(0, 6))
            ctk.CTkButton(att_row, text="Открыть",
                          width=80, height=26, font=("Segoe UI", 10, "bold"),
                          fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                          text_color=COLOR_ACCENT,
                          border_width=1, border_color=COLOR_BORDER,
                          command=lambda a=atts: self._show_attachments_window(
                              f"Вложения тикета #{t['id']}", a)
                          ).pack(side="left")

        if t.get("resolved_by"):
            ctk.CTkLabel(card, text=f"✔️ Решил: {t['resolved_by']}",
                         font=("Segoe UI", 10, "italic"),
                         text_color=COLOR_SUCCESS).pack(anchor="w", padx=14, pady=(0, 6))

        if archive_view:
            btn_row = ctk.CTkFrame(card, fg_color="transparent")
            btn_row.pack(fill="x", padx=12, pady=(0, 10))
            ctk.CTkButton(btn_row, text="↩️  Восстановить",
                          font=("Segoe UI", 10, "bold"), height=30, corner_radius=8,
                          fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                          text_color=COLOR_ON_ACCENT,
                          command=lambda tid=t["id"]: self.ticket_restore(tid)
                          ).pack(side="left", padx=(0, 6))
            ctk.CTkButton(btn_row, text="📋  Копировать",
                          font=("Segoe UI", 10, "bold"), height=30, corner_radius=8,
                          fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                          text_color=COLOR_TEXT, border_width=1, border_color=COLOR_BORDER,
                          command=lambda tt=t: self._copy_ticket(tt)
                          ).pack(side="left", padx=(0, 6))
            ctk.CTkButton(btn_row, text="🗑️  Удалить навсегда",
                          font=("Segoe UI", 10, "bold"), height=30, corner_radius=8,
                          fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                          text_color="#fff",
                          command=lambda tid=t["id"]: self.ticket_delete_from_archive(tid)
                          ).pack(side="right")
        elif admin_view:
            btn_row = ctk.CTkFrame(card, fg_color="transparent")
            btn_row.pack(fill="x", padx=12, pady=(0, 10))
            for new_status, st_data in TICKET_STATUSES.items():
                if new_status == status:
                    continue
                ctk.CTkButton(
                    btn_row, text=st_data["name"],
                    font=("Segoe UI", 9, "bold"), height=28, corner_radius=8,
                    fg_color=st_data["color"], hover_color=st_data["color"],
                    text_color="#0f0f11" if new_status != "closed" else "#fff",
                    command=lambda tid=t["id"], ns=new_status: self.ticket_set_status(tid, ns)
                ).pack(side="left", padx=(0, 4))
            ctk.CTkButton(btn_row, text="🛠",
                          font=("Segoe UI", 11, "bold"),
                          width=30, height=28, corner_radius=8,
                          fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                          text_color=COLOR_ACCENT,
                          command=lambda tt=t: self._reassign_dialog(tt)
                          ).pack(side="right", padx=(4, 0))
            ctk.CTkButton(btn_row, text="📋",
                          font=("Segoe UI", 11, "bold"),
                          width=30, height=28, corner_radius=8,
                          fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                          text_color=COLOR_ACCENT,
                          command=lambda tt=t: self._copy_ticket(tt)
                          ).pack(side="right", padx=(4, 0))
            ctk.CTkButton(btn_row, text="🗑️",
                          font=("Segoe UI", 11, "bold"),
                          width=30, height=28, corner_radius=8,
                          fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                          text_color="#fff",
                          command=lambda tid=t["id"]: self.ticket_delete(tid)
                          ).pack(side="right")
        elif not archive_view:
            btn_row = ctk.CTkFrame(card, fg_color="transparent")
            btn_row.pack(fill="x", padx=12, pady=(0, 10))
            ctk.CTkButton(btn_row, text="📋  Копировать",
                          font=("Segoe UI", 10, "bold"), height=28, corner_radius=8,
                          fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                          text_color=COLOR_ACCENT, border_width=1, border_color=COLOR_BORDER,
                          command=lambda tt=t: self._copy_ticket(tt)
                          ).pack(side="left")

    def _reassign_dialog(self, t):
        if not self.has_perm("tickets") and not self.is_tech():
            return
        admins = users_db.list_admins_and_techs() or ["—"]
        win = ctk.CTkToplevel(self.app)
        win.title(f"🛠  Исполнитель тикета #{t['id']}")
        win.geometry("420x220")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app); win.grab_set()
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL, corner_radius=14,
                           border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(box, text=f"🛠  Исполнитель тикета #{t['id']}",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=16, pady=(14, 8))
        menu = ctk.CTkOptionMenu(box, values=admins,
                                 font=("Segoe UI", 12), height=36, width=180,
                                 fg_color=COLOR_PANEL_LIGHT,
                                 button_color=COLOR_ACCENT_DARK,
                                 button_hover_color=COLOR_ACCENT,
                                 text_color=COLOR_TEXT,
                                 dropdown_fg_color=COLOR_PANEL_LIGHT,
                                 dropdown_text_color=COLOR_TEXT,
                                 dropdown_hover_color=COLOR_CARD_HOVER,
                                 corner_radius=10)
        cur = t.get("assignee", "").strip()
        if cur in admins:
            menu.set(cur)
        else:
            menu.set(admins[0])
        menu.pack(anchor="w", padx=16, pady=(4, 12))

        def save():
            new_a = menu.get()
            if new_a == "—":
                new_a = ""
            tickets_db.set_assignee(t["id"], new_a)
            journal_db.log(self.current_user, self.current_role,
                           f"Назначил исполнителя тикета #{t['id']}", new_a or "—")
            win.destroy()
            self.refresh_admin_tickets()
            self.refresh_tickets_list()

        btn_row = ctk.CTkFrame(box, fg_color="transparent")
        btn_row.pack(fill="x", padx=16, pady=(0, 14))
        self._accent_button(btn_row, "💾  Сохранить",
                            command=save, width=140, height=38).pack(side="left")
        self._ghost_button(btn_row, "Отмена",
                           command=win.destroy, width=110, height=38).pack(side="right")

    def _copy_ticket(self, t):
        try:
            st = TICKET_STATUSES.get(t.get("status", "new"), {})
            pr = TICKET_PRIORITIES.get(t.get("priority", "medium"), {})
            text = (f"Тикет #{t.get('id','?')}\n"
                    f"ПК: {t.get('pc','?')}  •  Зона: {t.get('zone','стандарт')}\n"
                    f"Статус: {st.get('name','?')}  •  Приоритет: {pr.get('name','?')}\n"
                    f"Автор: {t.get('author','?')}  •  Исполнитель: {t.get('assignee','—') or '—'}\n"
                    f"Создан: {t.get('created','?')[:16].replace('T', ' ')}\n\n"
                    f"Проблема:\n{t.get('problem','')}")
            self.app.clipboard_clear()
            self.app.clipboard_append(text)
            self.status_label.configure(text="✅ Тикет скопирован", text_color=COLOR_SUCCESS)
            self.app.after(2000, lambda: self.status_label.configure(
                text="●  Готов к работе", text_color=COLOR_SUCCESS))
        except Exception as e:
            log_error(e, "_copy_ticket")

    def _show_pc_history(self, pc):
        if not pc:
            return
        hist = tickets_db.get_by_pc(pc)
        win = ctk.CTkToplevel(self.app)
        win.title(f"🖥️  История ПК {pc}")
        win.geometry("640x600")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app)
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL,
                           corner_radius=14, border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(box, text=f"🖥️  История по ПК {pc}",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=16, pady=(14, 4))
        ctk.CTkLabel(box, text=f"Всего заявок: {len(hist)}",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", padx=16, pady=(0, 10))
        scroll = ctk.CTkScrollableFrame(box, fg_color=COLOR_BG, corner_radius=10,
                                        border_width=1, border_color=COLOR_BORDER)
        scroll.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        if not hist:
            ctk.CTkLabel(scroll, text="📭  Заявок по этому ПК не было",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=30)
        else:
            for t in hist:
                st = TICKET_STATUSES.get(t.get("status", "new"), {})
                pr = TICKET_PRIORITIES.get(t.get("priority", "medium"), {})
                row = ctk.CTkFrame(scroll, fg_color=COLOR_CARD,
                                   corner_radius=9, border_width=1,
                                   border_color=COLOR_BORDER)
                row.pack(fill="x", pady=3, padx=4)
                head = ctk.CTkFrame(row, fg_color="transparent")
                head.pack(fill="x", padx=10, pady=(6, 2))
                ctk.CTkLabel(head, text=f"#{t.get('id','?')}",
                             font=("Segoe UI", 11, "bold"),
                             text_color=COLOR_ACCENT).pack(side="left", padx=(0, 8))
                ctk.CTkLabel(head, text=st.get("name", "?"),
                             font=("Segoe UI", 10, "bold"),
                             text_color=st.get("color", COLOR_TEXT)).pack(side="left", padx=(0, 6))
                ctk.CTkLabel(head, text=pr.get("name", "?"),
                             font=("Segoe UI", 10, "bold"),
                             text_color=pr.get("color", COLOR_TEXT)).pack(side="left")
                try:
                    dt = datetime.fromisoformat(t.get("created", "")).strftime("%d.%m.%Y %H:%M")
                except Exception:
                    dt = "?"
                ctk.CTkLabel(head, text=dt,
                             font=("Segoe UI", 9),
                             text_color=COLOR_TEXT_MUTED).pack(side="right")
                ctk.CTkLabel(row, text=t.get("problem", ""),
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT,
                             anchor="w", justify="left", wraplength=560
                             ).pack(fill="x", padx=10, pady=(0, 6))
        self._ghost_button(box, "Закрыть",
                           command=win.destroy,
                           width=120, height=36).pack(anchor="e", padx=16, pady=(0, 14))

    def ticket_set_status(self, tid, status):
        tickets_db.update_status(tid, status)
        self.refresh_admin_tickets()
        self.refresh_tickets_list()
        self.refresh_archive()

    def ticket_delete(self, tid):
        if messagebox.askyesno("Удаление", f"Удалить тикет #{tid}?"):
            tickets_db.delete(tid)
            journal_db.log(self.current_user, self.current_role,
                           f"Тикет #{tid} удалён", "")
            self.refresh_admin_tickets()
            self.refresh_tickets_list()

    def ticket_restore(self, tid):
        if messagebox.askyesno("Восстановить", f"Вернуть тикет #{tid} из архива?"):
            if tickets_db.restore_from_archive(tid):
                journal_db.log(self.current_user, self.current_role,
                               f"Тикет #{tid} восстановлен из архива", "")
                self.refresh_admin_tickets()
                self.refresh_archive()

    def ticket_delete_from_archive(self, tid):
        if messagebox.askyesno("Удалить", f"Удалить тикет #{tid} навсегда?"):
            tickets_db.delete_from_archive(tid)
            journal_db.log(self.current_user, self.current_role,
                           f"Тикет #{tid} удалён из архива", "")
            self.refresh_archive()

    def refresh_admin_tickets(self):
        if not hasattr(self, "admin_tickets_list") or not self.admin_tickets_list.winfo_exists():
            return
        for w in self.admin_tickets_list.winfo_children():
            w.destroy()
        filt = "all"
        if hasattr(self, "admin_ticket_filter"):
            filt = self.admin_ticket_filter.get()
        if filt == "all":
            tickets = tickets_db.get_all()
        elif filt == "mine":
            tickets = tickets_db.get_by_assignee(self.current_user or "")
        else:
            tickets = tickets_db.get_by_status(filt)
        st = tickets_db.stats()
        try:
            self.ticket_stats_label.configure(
                text=f"Всего: {st['total']}  •  🆕 {st['new']}  •  ⚙️ {st['in_progress']}  •  ⏳ {st['waiting']}  •  📦 {st['archive']}")
        except Exception:
            pass
        if not tickets:
            ctk.CTkLabel(self.admin_tickets_list,
                         text="📭  Нет тикетов по фильтру",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return
        for t in tickets:
            self._render_ticket_card(self.admin_tickets_list, t, admin_view=True)

    def refresh_archive(self):
        if not hasattr(self, "archive_list") or not self.archive_list.winfo_exists():
            return
        for w in self.archive_list.winfo_children():
            w.destroy()
        arch = tickets_db.get_archive()
        if not arch:
            ctk.CTkLabel(self.archive_list,
                         text="📭  Архив пуст",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return
        for t in arch:
            self._render_ticket_card(self.archive_list, t, archive_view=True)

    # =================================================================
    # ============ АДМИНКА ===========================================
    # =================================================================
    def get_available_sections(self):
        sections = []
        for sec_id, sec_data in PERMISSIONS.items():
            if self.has_perm(sec_id):
                sections.append((sec_id, sec_data["name"], sec_data["icon"]))
        if self.is_tech():
            sections.append(("users", "👥  Пользователи", "👥"))
            # Обновление — только для тех-админа, как и управление людьми
            if HAS_UPDATER:
                sections.append(("update", "⬆️  Обновление", "⬆️"))
        return sections

    def build_admin_page(self):
        if not self.current_user:
            return
        for w in self.page_admin.winfo_children():
            w.destroy()

        wrapper = ctk.CTkFrame(self.page_admin, fg_color="transparent")
        wrapper.pack(fill="both", expand=True)

        sidebar = ctk.CTkFrame(wrapper, width=220, fg_color=COLOR_SIDEBAR,
                               corner_radius=14, border_width=1,
                               border_color=COLOR_BORDER)
        sidebar.pack(side="left", fill="y", padx=(0, 10))
        sidebar.pack_propagate(False)

        ctk.CTkLabel(sidebar, text="⚙️  Админ-панель",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLOR_ACCENT,
                     anchor="w").pack(fill="x", padx=14, pady=(14, 10))

        sections = self.get_available_sections()

        menu_scroll = ctk.CTkScrollableFrame(
            sidebar, fg_color="transparent",
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT)
        menu_scroll.pack(fill="both", expand=True, padx=4, pady=(0, 10))

        self.sidebar_buttons = {}
        for sec_id, sec_name, sec_icon in sections:
            btn = ctk.CTkButton(
                menu_scroll, text=f"  {sec_name}",
                font=("Segoe UI", 12, "bold"),
                height=40, corner_radius=9,
                fg_color="transparent",
                hover_color=COLOR_SIDEBAR_HOVER,
                text_color=COLOR_TEXT,
                anchor="w",
                command=lambda sid=sec_id: self.show_admin_section(sid))
            btn.pack(fill="x", padx=2, pady=1)
            self.sidebar_buttons[sec_id] = btn

        self.admin_content = ctk.CTkFrame(wrapper, fg_color=COLOR_PANEL,
                                          corner_radius=14, border_width=1,
                                          border_color=COLOR_BORDER)
        self.admin_content.pack(side="right", fill="both", expand=True)

        if sections:
            self.show_admin_section(sections[0][0])
        else:
            ctk.CTkLabel(self.admin_content,
                         text="🔒  У вас нет доступных разделов",
                         font=("Segoe UI", 14),
                         text_color=COLOR_TEXT_MUTED).pack(expand=True)

    def show_admin_section(self, sec_id):
        if sec_id not in ("users", "update") and not self.has_perm(sec_id):
            return
        if sec_id in ("users", "update") and not self.is_tech():
            return
        for sid, btn in self.sidebar_buttons.items():
            if sid == sec_id:
                btn.configure(fg_color=COLOR_ACCENT, text_color=COLOR_ON_ACCENT)
            else:
                btn.configure(fg_color="transparent", text_color=COLOR_TEXT)

        self.current_admin_section = sec_id

        for w in self.admin_content.winfo_children():
            w.destroy()

        builders = {
            "tickets":     self.build_admin_tickets_tab,
            "archive":     self.build_archive_tab,
            "suggestions": self.build_admin_suggestions_tab,
            "add":         self.build_add_tab,
            "edit":        self.build_edit_tab,
            "import":      self.build_import_tab,
            "langame":     self.build_langame_tab,
            "tags":        self.build_tags_tab,
            "dictionary":  self.build_dictionary_tab,
            "stats":       self.build_stats_tab,
            "journal":     self.build_journal_tab,
            "io":          self.build_io_tab,
            "users":       self.build_users_tab,
            "update":      self.build_update_tab,
        }
        builder = builders.get(sec_id)
        if builder:
            builder(self.admin_content)

    # ---- LANGame по макету ----
    def build_langame_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)

        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="📚  Раздел LANGame",
                     font=("Segoe UI", 16, "bold"),
                     text_color="#a78bfa").pack(side="left")
        self.langame_stats_label = ctk.CTkLabel(head, text="",
                                                font=("Segoe UI", 11),
                                                text_color=COLOR_TEXT_DIM)
        self.langame_stats_label.pack(side="right")

        # Фильтр по категориям
        cat_row = ctk.CTkFrame(box, fg_color="transparent")
        cat_row.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(cat_row, text="Категория:",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 8))
        self.langame_cat_filter = ctk.CTkOptionMenu(
            cat_row, values=["Все"] + LANGAME_CATEGORIES,
            font=("Segoe UI", 11), height=32, width=180,
            fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER,
            corner_radius=8,
            command=lambda v: self.refresh_langame_list())
        self.langame_cat_filter.set("Все")
        self.langame_cat_filter.pack(side="left")

        # Форма добавления
        add_frame = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT,
                                 corner_radius=12, border_width=1,
                                 border_color=COLOR_BORDER)
        add_frame.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(add_frame, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=14)

        ctk.CTkLabel(inner, text="➕  Добавить материал LANGame",
                     font=("Segoe UI", 13, "bold"),
                     text_color="#a78bfa").pack(anchor="w", pady=(0, 8))

        lq = ctk.CTkEntry(inner, placeholder_text="Название / вопрос...",
                          placeholder_text_color=COLOR_TEXT_MUTED,
                          font=("Segoe UI", 12), height=36,
                          fg_color=COLOR_PANEL, border_color=COLOR_BORDER,
                          text_color=COLOR_TEXT, corner_radius=10)
        lq.pack(fill="x", pady=4)
        self._attach_clipboard_support(lq)

        cat_menu = ctk.CTkOptionMenu(
            inner, values=LANGAME_CATEGORIES,
            font=("Segoe UI", 11), height=32, width=200,
            fg_color=COLOR_PANEL,
            button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER,
            corner_radius=8)
        cat_menu.set(LANGAME_CATEGORIES[0])
        cat_menu.pack(anchor="w", pady=4)

        la = ctk.CTkTextbox(inner, font=("Segoe UI", 12), height=100,
                            fg_color=COLOR_PANEL, border_color=COLOR_BORDER,
                            border_width=1, text_color=COLOR_TEXT,
                            corner_radius=10, wrap="word")
        la.pack(fill="x", pady=4)
        self._attach_clipboard_support(la)

        ltag = ctk.CTkEntry(inner, placeholder_text="Теги через запятую",
                            placeholder_text_color=COLOR_TEXT_MUTED,
                            font=("Segoe UI", 11), height=32,
                            fg_color=COLOR_PANEL, border_color=COLOR_BORDER,
                            text_color=COLOR_TEXT, corner_radius=10)
        ltag.pack(fill="x", pady=4)
        self._attach_clipboard_support(ltag)

        # Вложения для LANGame
        langame_attach = {"files": []}
        la_att_row = ctk.CTkFrame(inner, fg_color="transparent")
        la_att_row.pack(fill="x", pady=(6, 0))
        la_att_label = ctk.CTkLabel(la_att_row, text="📎 Вложений: 0/3",
                                    font=("Segoe UI", 10),
                                    text_color=COLOR_TEXT_MUTED)
        la_att_label.pack(side="left", padx=(0, 8))

        def la_attach():
            files = self._attach_files_dialog("langame", langame_attach)
            langame_attach["files"] = files
            la_att_label.configure(text=f"📎 Вложений: {len(files)}/3")

        self._ghost_button(la_att_row, "📎  Прикрепить",
                           command=la_attach,
                           width=140, height=28).pack(side="left")

        def add_langame():
            q = lq.get().strip()
            a = la.get("1.0", "end").strip()
            tags_raw = ltag.get().strip()
            cat = cat_menu.get()
            if not q or not a:
                messagebox.showerror("Ошибка", "Название и описание обязательны!")
                return
            if kb.question_exists(q, source="langame"):
                messagebox.showwarning("Дубликат", "Такая запись уже есть!")
                return
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()] if tags_raw else []
            text = f"Вопрос: {q}\nОтвет: {a}"
            kb.add_text(text, category=cat, difficulty="medium",
                        tags=tags, source="langame",
                        attachments=langame_attach["files"])
            journal_db.log(self.current_user, self.current_role,
                           "Добавил материал LANGame", q[:80])
            rebuild_all_questions()
            self.load_faq_questions()
            self.refresh_langame_list()
            messagebox.showinfo("Готово", "✅ Материал добавлен!")
            lq.delete(0, "end")
            la.delete("1.0", "end")
            ltag.delete(0, "end")
            langame_attach["files"] = []
            la_att_label.configure(text="📎 Вложений: 0/3")

        self._accent_button(inner, "➕  Добавить материал",
                            command=add_langame,
                            width=220, height=38).pack(anchor="w", pady=(10, 0))

        # Список
        ctk.CTkLabel(box, text="📋  Материалы LANGame",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(8, 4))
        self.langame_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.langame_list.pack(fill="both", expand=True, pady=4)
        self.refresh_langame_list()

    def refresh_langame_list(self):
        if not hasattr(self, "langame_list") or not self.langame_list.winfo_exists():
            return
        for w in self.langame_list.winfo_children():
            w.destroy()

        filt = "Все"
        if hasattr(self, "langame_cat_filter"):
            filt = self.langame_cat_filter.get()

        items = []
        for i, c in enumerate(kb.chunks):
            m = kb.metadata[i] if i < len(kb.metadata) else {}
            if m.get("source") == "langame":
                cat = m.get("category", "LANGame")
                if filt != "Все" and cat != filt:
                    continue
                items.append((i, c, m))

        try:
            self.langame_stats_label.configure(text=f"Материалов: {len(items)}")
        except Exception:
            pass

        if not items:
            ctk.CTkLabel(self.langame_list,
                         text="📭  Пока нет материалов LANGame",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return

        cat_icons = {"Оборудование": "🖥", "ПО": "💾", "Игры": "🎮",
                     "Античиты": "🛡", "Сеть": "📡"}

        for i, chunk, m in items:
            q, a = chunk_to_qa(chunk)
            cat = m.get("category", "LANGame")
            icon = cat_icons.get(cat, "📚")
            tags = m.get("tags", [])
            atts = m.get("attachments", [])
            try:
                dt_added = datetime.fromisoformat(m.get("added", "")).strftime("%d.%m.%Y")
            except Exception:
                dt_added = "?"

            card = ctk.CTkFrame(self.langame_list, fg_color=COLOR_CARD,
                                corner_radius=10, border_width=1,
                                border_color="#a78bfa")
            card.pack(fill="x", pady=4, padx=4)
            ctk.CTkLabel(card, text=f"{icon}  {q}",
                         font=("Segoe UI", 12, "bold"),
                         text_color="#a78bfa",
                         anchor="w", justify="left", wraplength=760
                         ).pack(fill="x", padx=12, pady=(10, 2))
            meta_line = f"📂 {cat}"
            if tags:
                meta_line += f"  •  🏷️ {', '.join(tags)}"
            meta_line += f"  •  🕐 {dt_added}"
            ctk.CTkLabel(card, text=meta_line,
                         font=("Segoe UI", 9, "italic"),
                         text_color=COLOR_TEXT_MUTED,
                         anchor="w").pack(fill="x", padx=12, pady=(0, 4))
            ctk.CTkLabel(card, text=a,
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT,
                         anchor="w", justify="left", wraplength=760
                         ).pack(fill="x", padx=12, pady=(0, 6))

            # Вложения
            if atts:
                ctk.CTkLabel(card, text=f"📎 {len(atts)} файл(ов)",
                             font=("Segoe UI", 9, "italic"),
                             text_color=COLOR_ACCENT,
                             anchor="w").pack(fill="x", padx=12, pady=(0, 4))

            # Связанные тикеты (по совпадению ключевых слов)
            related = self._find_related_tickets(q, a)
            if related:
                rel_text = "🎫 Связанные тикеты: " + ", ".join(
                    f"#{tid}" for tid in related[:3])
                ctk.CTkLabel(card, text=rel_text,
                             font=("Segoe UI", 9, "italic"),
                             text_color=COLOR_TEXT_DIM,
                             anchor="w").pack(fill="x", padx=12, pady=(0, 4))

            btn_row = ctk.CTkFrame(card, fg_color="transparent")
            btn_row.pack(fill="x", padx=12, pady=(4, 10))

            def to_base(idx=i, qq=q, aa=a, cc=cat, tt=tags):
                # Копировать в основную базу
                text = f"Вопрос: {qq}\nОтвет: {aa}"
                kb.add_text(text, category=cc if cc in
                            ["общие", "игры", "периферия", "софт", "админ", "сеть"]
                            else "общие",
                            difficulty="medium", tags=list(tt), source="base")
                rebuild_all_questions()
                self.load_faq_questions()
                journal_db.log(self.current_user, self.current_role,
                               "Скопировал LANGame в базу знаний", qq[:80])
                messagebox.showinfo("Готово", "✅ Скопировано в базу знаний!")

            def del_langame(idx=i, qq=q):
                if messagebox.askyesno("Удалить", "Удалить материал LANGame?"):
                    kb.delete_by_index(idx)
                    journal_db.log(self.current_user, self.current_role,
                                   "Удалил материал LANGame", qq[:80])
                    rebuild_all_questions()
                    self.load_faq_questions()
                    self.refresh_langame_list()

            ctk.CTkButton(btn_row, text="📥  В базу знаний",
                          font=("Segoe UI", 10, "bold"),
                          height=28, corner_radius=8,
                          fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                          text_color=COLOR_ON_ACCENT,
                          command=to_base).pack(side="left", padx=(0, 6))
            if atts:
                ctk.CTkButton(btn_row, text="📎  Файлы",
                              font=("Segoe UI", 10, "bold"),
                              height=28, corner_radius=8,
                              fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                              text_color=COLOR_ACCENT,
                              border_width=1, border_color=COLOR_BORDER,
                              command=lambda a=atts, qq=q: self._show_attachments_window(
                                  f"Вложения: {qq[:40]}", a)
                              ).pack(side="left", padx=(0, 6))
            ctk.CTkButton(btn_row, text="🗑️  Удалить",
                          font=("Segoe UI", 10, "bold"),
                          height=28, corner_radius=8,
                          fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                          text_color="#fff",
                          command=del_langame).pack(side="right")

    def _find_related_tickets(self, q, a):
        text = normalize_text(q + " " + a)
        words = [w for w in text.split() if len(w) >= 4]
        if not words:
            return []
        result = []
        for t in tickets_db.get_all()[:200]:
            prob = normalize_text(t.get("problem", ""))
            hits = sum(1 for w in words if w in prob)
            if hits >= 2:
                result.append((t["id"], hits))
        result.sort(key=lambda x: x[1], reverse=True)
        return [tid for tid, _ in result]

    def build_tags_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="🏷️  Управление тегами",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self._ghost_button(head, "🔄  Обновить",
                           command=self._refresh_tags_tab_content,
                           width=140, height=32).pack(side="right")
        ctk.CTkLabel(box, text="Все теги из базы. Клик по тегу → фильтр по нему.",
                     font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED,
                     justify="left").pack(anchor="w", pady=(0, 12))
        self.tags_cloud_frame = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12, height=220,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.tags_cloud_frame.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(box, text="📋  Вопросы с выбранным тегом",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(4, 4))
        self.tag_filter_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.tag_filter_list.pack(fill="both", expand=True, pady=4)
        ctk.CTkLabel(self.tag_filter_list,
                     text="Выбери тег выше, чтобы увидеть вопросы.",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_MUTED).pack(pady=20)
        self._refresh_tags_tab_content()

    def _refresh_tags_tab_content(self):
        if not hasattr(self, "tags_cloud_frame") or not self.tags_cloud_frame.winfo_exists():
            return
        for w in self.tags_cloud_frame.winfo_children():
            w.destroy()
        tag_counts = {}
        for m in kb.metadata:
            for t in m.get("tags", []):
                t = t.lower().strip()
                if t:
                    tag_counts[t] = tag_counts.get(t, 0) + 1
        if not tag_counts:
            ctk.CTkLabel(self.tags_cloud_frame,
                         text="🏷️  Пока нет тегов.",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return
        sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)
        row_frame = ctk.CTkFrame(self.tags_cloud_frame, fg_color="transparent")
        row_frame.pack(fill="x", padx=4, pady=4)
        col = 0
        for tag, cnt in sorted_tags:
            ctk.CTkButton(
                row_frame, text=f"🏷️ {tag} ({cnt})",
                font=("Segoe UI", 11),
                height=32, corner_radius=8, width=0,
                fg_color=COLOR_CARD, hover_color=COLOR_CARD_HOVER,
                text_color=COLOR_TEXT,
                border_width=1, border_color=COLOR_BORDER,
                command=lambda t=tag: self._filter_by_tag(t)
            ).pack(side="left", padx=3, pady=3)
            col += 1
            if col % 4 == 0:
                row_frame = ctk.CTkFrame(self.tags_cloud_frame, fg_color="transparent")
                row_frame.pack(fill="x", padx=4, pady=0)

    def _filter_by_tag(self, tag):
        if not hasattr(self, "tag_filter_list") or not self.tag_filter_list.winfo_exists():
            return
        for w in self.tag_filter_list.winfo_children():
            w.destroy()
        tag_low = tag.lower().strip()
        found = 0
        for i, c in enumerate(kb.chunks):
            m = kb.metadata[i] if i < len(kb.metadata) else {}
            tags = [t.lower().strip() for t in m.get("tags", [])]
            if tag_low in tags:
                found += 1
                q, _ = chunk_to_qa(c)
                source = m.get("source", "base")
                badge = "📚 " if source == "langame" else ""
                row = ctk.CTkFrame(self.tag_filter_list, fg_color=COLOR_CARD,
                                   corner_radius=9, border_width=1,
                                   border_color=COLOR_BORDER)
                row.pack(fill="x", pady=2, padx=4)
                ctk.CTkLabel(row, text=f"{badge}#{i}  {q}",
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT, anchor="w"
                             ).pack(fill="x", padx=10, pady=6)
        if found == 0:
            ctk.CTkLabel(self.tag_filter_list,
                         text=f"Нет вопросов с тегом «{tag}»",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=20)

    def build_archive_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="📦  Архив тикетов",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        ctk.CTkLabel(head, text="resolved/closed попадают сюда сразу",
                     font=("Segoe UI", 10, "italic"),
                     text_color=COLOR_TEXT_MUTED).pack(side="right")
        self.archive_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.archive_list.pack(fill="both", expand=True, pady=4)
        self.refresh_archive()

    def build_dictionary_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        ctk.CTkLabel(box, text="📖  Словари (синонимы и стоп-слова)",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 8))
        info = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT,
                            corner_radius=10, border_width=1,
                            border_color=COLOR_BORDER)
        info.pack(fill="x", pady=(0, 12))
        ii = ctk.CTkFrame(info, fg_color="transparent")
        ii.pack(fill="x", padx=16, pady=12)
        ctk.CTkLabel(ii,
                     text=("📄 Файлы словарей (открываются в Excel):\n"
                           f"     {SYNONYMS_FILE}\n"
                           f"     {STOP_WORDS_FILE}\n\n"
                           "📌 synonyms.csv: A — основное слово, B — синонимы через запятую\n"
                           "📌 stop_words.csv: A — слово, игнорируемое при поиске"),
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM,
                     justify="left").pack(anchor="w")
        stats_row = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT,
                                 corner_radius=10, border_width=1,
                                 border_color=COLOR_BORDER)
        stats_row.pack(fill="x", pady=(0, 12))
        si = ctk.CTkFrame(stats_row, fg_color="transparent")
        si.pack(fill="x", padx=16, pady=12)
        syn_count = len(dictionaries.synonyms)
        stop_count = len(dictionaries.stop_words)
        ctk.CTkLabel(si,
                     text=f"📊  Загружено:  синонимов — {syn_count}  •  стоп-слов — {stop_count}",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w")

        def reload_dicts():
            dictionaries.reload()
            messagebox.showinfo("Готово",
                                f"✅ Перезагружено:\n"
                                f"   синонимов: {len(dictionaries.synonyms)}\n"
                                f"   стоп-слов: {len(dictionaries.stop_words)}")
            journal_db.log(self.current_user, self.current_role,
                           "Перезагрузил словари", "")
            self.show_admin_section("dictionary")

        def open_syn():
            if not open_file_in_default_app(SYNONYMS_FILE):
                messagebox.showerror("Ошибка", "Не удалось открыть файл")

        def open_stop():
            if not open_file_in_default_app(STOP_WORDS_FILE):
                messagebox.showerror("Ошибка", "Не удалось открыть файл")

        btn_row = ctk.CTkFrame(box, fg_color="transparent")
        btn_row.pack(fill="x", pady=(0, 10))
        self._accent_button(btn_row, "🔄  Перезагрузить словари",
                            command=reload_dicts,
                            width=240, height=42).pack(side="left", padx=(0, 8))
        self._ghost_button(btn_row, "📂  Открыть synonyms.csv",
                           command=open_syn,
                           width=220, height=42).pack(side="left", padx=(0, 8))
        self._ghost_button(btn_row, "📂  Открыть stop_words.csv",
                           command=open_stop,
                           width=220, height=42).pack(side="left")

    def build_import_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        ctk.CTkLabel(box, text="📥  Импорт вопросов",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 8))
        ctk.CTkLabel(box, text="Поддерживаются только .json и .pdf. Дубликаты пропускаются.",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_MUTED,
                     justify="left").pack(anchor="w", pady=(0, 16))
        ctk.CTkLabel(box, text="Куда импортировать:",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", pady=(0, 4))
        target_var = tk.StringVar(value="base")
        target_row = ctk.CTkFrame(box, fg_color="transparent")
        target_row.pack(anchor="w", pady=(0, 12))
        ctk.CTkRadioButton(target_row, text="📚  Обычная база",
                           font=("Segoe UI", 11),
                           variable=target_var, value="base",
                           fg_color=COLOR_ACCENT,
                           text_color=COLOR_TEXT,
                           hover_color=COLOR_ACCENT_HOVER).pack(side="left", padx=(0, 20))
        ctk.CTkRadioButton(target_row, text="🎓  LANGame",
                           font=("Segoe UI", 11),
                           variable=target_var, value="langame",
                           fg_color="#a78bfa",
                           text_color=COLOR_TEXT,
                           hover_color="#c4b5fd").pack(side="left")
        formats_box = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT,
                                   corner_radius=12, border_width=1,
                                   border_color=COLOR_BORDER)
        formats_box.pack(fill="x", pady=(0, 16))
        fi = ctk.CTkFrame(formats_box, fg_color="transparent")
        fi.pack(fill="x", padx=16, pady=14)
        ctk.CTkLabel(fi, text="📄  JSON",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w")
        ctk.CTkLabel(fi,
                     text='[{"question": "...", "answer": "...", "category": "...", '
                          '"difficulty": "easy", "tags": ["tag1"]}]',
                     font=("Consolas", 10),
                     text_color=COLOR_TEXT_DIM,
                     justify="left").pack(anchor="w", pady=(2, 10))
        ctk.CTkLabel(fi, text="📄  PDF (формат 1 — через |)",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w")
        ctk.CTkLabel(fi, text="Как перезагрузить роутер? | Отключить питание на 10 секунд",
                     font=("Consolas", 10),
                     text_color=COLOR_TEXT_DIM,
                     justify="left").pack(anchor="w", pady=(2, 10))
        ctk.CTkLabel(fi, text="📄  PDF (формат 2 — Вопрос/Ответ)",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w")
        ctk.CTkLabel(fi, text="Вопрос: Как перезагрузить роутер?\nОтвет: Отключить питание на 10 секунд",
                     font=("Consolas", 10),
                     text_color=COLOR_TEXT_DIM,
                     justify="left").pack(anchor="w", pady=(2, 0))

        def do_import():
            path = filedialog.askopenfilename(
                title="Выберите файл",
                filetypes=[
                    ("Поддерживаемые", "*.json;*.pdf"),
                    ("JSON", "*.json"),
                    ("PDF", "*.pdf"),
                    ("Все файлы", "*.*"),
                ])
            if not path:
                return
            source = target_var.get()
            ok, added, skipped, err = kb.import_from_file(path, source=source)
            if not ok:
                messagebox.showerror("Ошибка импорта",
                                     f"❌ Не удалось импортировать:\n\n{err}")
                return
            rebuild_all_questions()
            journal_db.log(self.current_user, self.current_role,
                           f"Импорт {source}",
                           f"{added} добавлено, {skipped} пропущено")
            self.load_faq_questions()
            try:
                self.records_label.configure(text=f"{len(kb.chunks)}  записей")
            except Exception:
                pass
            if self.current_admin_section == "edit":
                self.refresh_delete_list()
            elif self.current_admin_section == "tags":
                self._refresh_tags_tab_content()
            elif self.current_admin_section == "langame":
                self.refresh_langame_list()
            if added == 0 and skipped == 0:
                messagebox.showwarning("Импорт", "⚠️ Добавлено 0 записей.")
            else:
                messagebox.showinfo(
                    "Готово",
                    f"✅ Импорт завершён!\n\n"
                    f"  Добавлено: {added}\n"
                    f"  Пропущено: {skipped}\n\n"
                    f"Всего в базе: {len(kb.chunks)}")

        self._accent_button(box, "📥  Выбрать файл и импортировать",
                            command=do_import,
                            width=320, height=44).pack(anchor="w", pady=(8, 16))

    def build_admin_tickets_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="🚨  Тикеты технических проблем",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self.ticket_stats_label = ctk.CTkLabel(head, text="",
                                               font=("Segoe UI", 11),
                                               text_color=COLOR_TEXT_DIM)
        self.ticket_stats_label.pack(side="right")
        frow = ctk.CTkFrame(box, fg_color="transparent")
        frow.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(frow, text="Фильтр:",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 8))
        self.admin_ticket_filter = ctk.CTkOptionMenu(
            frow, values=["all", "mine", "new", "in_progress", "waiting"],
            font=("Segoe UI", 11), height=34, width=200,
            fg_color=COLOR_PANEL_LIGHT, button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT, text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER,
            corner_radius=10,
            command=lambda v: self.refresh_admin_tickets())
        self.admin_ticket_filter.set("all")
        self.admin_ticket_filter.pack(side="left")
        self._ghost_button(frow, "🔄  Обновить",
                           command=self.refresh_admin_tickets,
                           width=140, height=34).pack(side="left", padx=8)
        self.admin_tickets_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.admin_tickets_list.pack(fill="both", expand=True, pady=4)
        self.refresh_admin_tickets()

    def build_admin_suggestions_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="✍️  Предложения от пользователей",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self.sugg_stats_label = ctk.CTkLabel(head, text="",
                                             font=("Segoe UI", 11),
                                             text_color=COLOR_TEXT_DIM)
        self.sugg_stats_label.pack(side="right")
        ctk.CTkLabel(box, text="✎ Изменить — правка. ✅ Одобрить — попадает в базу.",
                     font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED,
                     justify="left").pack(anchor="w", pady=(0, 10))
        self._ghost_button(box, "🔄  Обновить",
                           command=self.refresh_admin_suggestions,
                           width=140, height=34).pack(anchor="w", pady=(0, 8))
        self.admin_sugg_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.admin_sugg_list.pack(fill="both", expand=True, pady=4)
        self.refresh_admin_suggestions()

    def refresh_admin_suggestions(self):
        if not hasattr(self, "admin_sugg_list") or not self.admin_sugg_list.winfo_exists():
            return
        for w in self.admin_sugg_list.winfo_children():
            w.destroy()
        pending = suggestions_db.get_pending()
        try:
            self.sugg_stats_label.configure(text=f"На модерации: {len(pending)}")
        except Exception:
            pass
        if not pending:
            ctk.CTkLabel(self.admin_sugg_list,
                         text="✅  Нет предложений на модерации",
                         font=("Segoe UI", 12),
                         text_color=COLOR_SUCCESS).pack(pady=40)
            return
        for s in pending:
            self._render_suggestion_card(s)

    def _render_suggestion_card(self, s):
        card = ctk.CTkFrame(self.admin_sugg_list, fg_color=COLOR_CARD,
                            corner_radius=12, border_width=1,
                            border_color=COLOR_ACCENT)
        card.pack(fill="x", pady=5, padx=4)
        top = ctk.CTkFrame(card, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(10, 4))
        src_text = "🚫 Бот не нашёл" if s["source"] == "no_answer" else "⚠️ Ответ не помог"
        ctk.CTkLabel(top, text=f"#{s['id']}  •  {src_text}",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        try:
            dt = datetime.fromisoformat(s["created"]).strftime("%d.%m %H:%M")
        except Exception:
            dt = "?"
        ctk.CTkLabel(top, text=f"🕐 {dt}",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_MUTED).pack(side="right")
        ctk.CTkLabel(card, text=f"👤  Отправитель: {s['author']}",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=12, pady=(0, 4))
        qbox = ctk.CTkFrame(card, fg_color=COLOR_BG, corner_radius=8)
        qbox.pack(fill="x", padx=12, pady=4)
        ctk.CTkLabel(qbox, text="❓  " + s["question"],
                     font=("Segoe UI", 11, "bold"), text_color=COLOR_TEXT,
                     justify="left", anchor="w", wraplength=750
                     ).pack(fill="x", padx=10, pady=8)
        abox = ctk.CTkFrame(card, fg_color="#1f2e1f", corner_radius=8)
        abox.pack(fill="x", padx=12, pady=4)
        ctk.CTkLabel(abox, text="✅  " + s["answer"],
                     font=("Segoe UI", 11), text_color=COLOR_TEXT,
                     justify="left", anchor="w", wraplength=750
                     ).pack(fill="x", padx=10, pady=8)
        opt_row = ctk.CTkFrame(card, fg_color="transparent")
        opt_row.pack(fill="x", padx=12, pady=(6, 4))
        ctk.CTkLabel(opt_row, text="Категория:",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 4))
        cat_var = ctk.CTkComboBox(opt_row, values=sorted(kb.categories) or ["общие"],
                                  font=("Segoe UI", 10), height=30, width=140,
                                  fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                  button_color=COLOR_ACCENT_DARK,
                                  button_hover_color=COLOR_ACCENT,
                                  text_color=COLOR_TEXT,
                                  dropdown_fg_color=COLOR_PANEL_LIGHT,
                                  dropdown_text_color=COLOR_TEXT,
                                  dropdown_hover_color=COLOR_CARD_HOVER,
                                  corner_radius=8)
        cat_var.set("общие")
        cat_var.pack(side="left", padx=(0, 12))
        ctk.CTkLabel(opt_row, text="Сложность:",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 4))
        diff_var = ctk.CTkOptionMenu(opt_row, values=["easy", "medium", "hard"],
                                     font=("Segoe UI", 10), height=30, width=100,
                                     fg_color=COLOR_PANEL_LIGHT,
                                     button_color=COLOR_ACCENT_DARK,
                                     button_hover_color=COLOR_ACCENT,
                                     text_color=COLOR_TEXT,
                                     dropdown_fg_color=COLOR_PANEL_LIGHT,
                                     dropdown_text_color=COLOR_TEXT,
                                     dropdown_hover_color=COLOR_CARD_HOVER,
                                     corner_radius=8)
        diff_var.set("easy")
        diff_var.pack(side="left")
        ctk.CTkLabel(opt_row, text="  Теги:",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_DIM).pack(side="left", padx=(8, 4))
        tags_entry = ctk.CTkEntry(opt_row, placeholder_text="тег1, тег2",
                                  placeholder_text_color=COLOR_TEXT_MUTED,
                                  font=("Segoe UI", 10), height=30, width=160,
                                  fg_color=COLOR_PANEL_LIGHT,
                                  border_color=COLOR_BORDER,
                                  text_color=COLOR_TEXT, corner_radius=8)
        tags_entry.pack(side="left")
        self._attach_clipboard_support(tags_entry)
        btn_row = ctk.CTkFrame(card, fg_color="transparent")
        btn_row.pack(fill="x", padx=12, pady=(6, 10))

        def approve():
            tags_raw = tags_entry.get().strip()
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()] if tags_raw else []
            suggestions_db.approve(s["id"], cat_var.get(), diff_var.get(), tags=tags)
            journal_db.log(self.current_user, self.current_role,
                           "Одобрил предложение", s["question"][:80])
            self.load_faq_questions()
            try:
                self.records_label.configure(text=f"{len(kb.chunks)}  записей")
            except Exception:
                pass
            self.refresh_admin_suggestions()
            if self.current_admin_section == "tags":
                self._refresh_tags_tab_content()

        def reject():
            if messagebox.askyesno("Отклонить", "Отклонить предложение?"):
                suggestions_db.reject(s["id"])
                journal_db.log(self.current_user, self.current_role,
                               "Отклонил предложение", s["question"][:80])
                self.refresh_admin_suggestions()

        def edit():
            self.open_edit_suggestion_dialog(s)

        def delete():
            if messagebox.askyesno("Удалить", "Удалить навсегда?"):
                suggestions_db.delete(s["id"])
                self.refresh_admin_suggestions()

        ctk.CTkButton(btn_row, text="✅  Одобрить",
                      font=("Segoe UI", 11, "bold"),
                      height=32, corner_radius=8,
                      fg_color=COLOR_SUCCESS, hover_color="#9be87a",
                      text_color="#1a0d05", command=approve
                      ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(btn_row, text="✎  Изменить",
                      font=("Segoe UI", 11, "bold"),
                      height=32, corner_radius=8,
                      fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                      text_color=COLOR_ON_ACCENT, command=edit
                      ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(btn_row, text="❌  Отклонить",
                      font=("Segoe UI", 11, "bold"),
                      height=32, corner_radius=8,
                      fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                      text_color=COLOR_TEXT, border_width=1, border_color=COLOR_BORDER,
                      command=reject).pack(side="left", padx=(0, 6))
        ctk.CTkButton(btn_row, text="🗑️  Удалить",
                      font=("Segoe UI", 11, "bold"),
                      height=32, corner_radius=8,
                      fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                      text_color="#fff", command=delete).pack(side="right")

    def open_edit_suggestion_dialog(self, s):
        win = ctk.CTkToplevel(self.app)
        win.title(f"✎  Редактирование предложения #{s['id']}")
        win.geometry("640x520")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app); win.grab_set()
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL, corner_radius=14,
                           border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        inner = ctk.CTkFrame(box, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(inner, text=f"✎  Предложение #{s['id']}",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(inner, text=f"От: {s['author']}",
                     font=("Segoe UI", 10, "italic"),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", pady=(0, 14))
        ctk.CTkLabel(inner, text="Вопрос",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        q_entry = ctk.CTkEntry(inner, font=("Segoe UI", 12), height=40,
                               fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=10)
        q_entry.pack(fill="x", pady=(4, 12))
        q_entry.insert(0, s["question"])
        ctk.CTkLabel(inner, text="Ответ",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        a_text = ctk.CTkTextbox(inner, font=("Segoe UI", 12), height=180,
                                fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                border_width=1, text_color=COLOR_TEXT,
                                corner_radius=10, wrap="word")
        a_text.pack(fill="both", expand=True, pady=(4, 16))
        a_text.insert("1.0", s["answer"])
        self._attach_clipboard_support(a_text)

        def save():
            nq = q_entry.get().strip()
            na = a_text.get("1.0", "end").strip()
            if not nq or not na:
                messagebox.showerror("Ошибка", "❌ Заполните вопрос и ответ!")
                return
            suggestions_db.update(s["id"], nq, na)
            journal_db.log(self.current_user, self.current_role,
                           f"Отредактировал предложение #{s['id']}", nq[:80])
            messagebox.showinfo("Готово", "✅ Предложение обновлено!")
            win.destroy()
            self.refresh_admin_suggestions()

        btn_row = ctk.CTkFrame(inner, fg_color="transparent")
        btn_row.pack(fill="x")
        self._accent_button(btn_row, "💾  Сохранить",
                            command=save, width=180, height=42).pack(side="left")
        self._ghost_button(btn_row, "Отмена",
                           command=win.destroy, width=120, height=42).pack(side="right")

    def build_add_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        ctk.CTkLabel(box, text="➕  Новый вопрос",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 12))
        q_entry = ctk.CTkEntry(box, placeholder_text="Вопрос...",
                               placeholder_text_color=COLOR_TEXT_MUTED,
                               font=("Segoe UI", 12), height=40,
                               fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=10)
        q_entry.pack(fill="x", pady=4)
        self._attach_clipboard_support(q_entry)
        ctk.CTkLabel(box, text="Ответ:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", pady=(6, 0))
        a_text = ctk.CTkTextbox(box, font=("Segoe UI", 12), height=120,
                                fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                border_width=1, text_color=COLOR_TEXT,
                                corner_radius=10, wrap="word")
        a_text.pack(fill="x", pady=4)
        self._attach_clipboard_support(a_text)
        row_meta = ctk.CTkFrame(box, fg_color="transparent")
        row_meta.pack(fill="x", pady=(6, 4))
        ctk.CTkLabel(row_meta, text="Категория:",
                     font=("Segoe UI", 11), text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 6))
        cat_menu = ctk.CTkComboBox(row_meta, values=sorted(kb.categories) or
                                   ["общие", "игры", "периферия", "софт", "админ", "сеть"],
                                   font=("Segoe UI", 12), height=34, width=180,
                                   fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                                   button_color=COLOR_ACCENT_DARK,
                                   button_hover_color=COLOR_ACCENT,
                                   text_color=COLOR_TEXT,
                                   dropdown_fg_color=COLOR_PANEL_LIGHT,
                                   dropdown_text_color=COLOR_TEXT,
                                   dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=10)
        cat_menu.pack(side="left", padx=(0, 20)); cat_menu.set("общие")
        ctk.CTkLabel(row_meta, text="Сложность:",
                     font=("Segoe UI", 11), text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 6))
        diff_menu = ctk.CTkOptionMenu(row_meta, values=["easy", "medium", "hard"],
                                      font=("Segoe UI", 12), height=34, width=140,
                                      fg_color=COLOR_PANEL_LIGHT,
                                      button_color=COLOR_ACCENT_DARK,
                                      button_hover_color=COLOR_ACCENT,
                                      text_color=COLOR_TEXT,
                                      dropdown_fg_color=COLOR_PANEL_LIGHT,
                                      dropdown_text_color=COLOR_TEXT,
                                      dropdown_hover_color=COLOR_CARD_HOVER,
                                      corner_radius=10)
        diff_menu.set("easy"); diff_menu.pack(side="left")
        ctk.CTkLabel(box, text="Теги (через запятую):",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", pady=(6, 0))
        tags_entry = ctk.CTkEntry(box, placeholder_text="мышка, USB, периферия",
                                  placeholder_text_color=COLOR_TEXT_MUTED,
                                  font=("Segoe UI", 12), height=36,
                                  fg_color=COLOR_PANEL_LIGHT,
                                  border_color=COLOR_BORDER,
                                  text_color=COLOR_TEXT, corner_radius=10)
        tags_entry.pack(fill="x", pady=4)
        self._attach_clipboard_support(tags_entry)

        add_attach = {"files": []}
        add_att_row = ctk.CTkFrame(box, fg_color="transparent")
        add_att_row.pack(fill="x", pady=(6, 0))
        add_att_label = ctk.CTkLabel(add_att_row, text="📎 Вложений: 0/3",
                                     font=("Segoe UI", 10),
                                     text_color=COLOR_TEXT_MUTED)
        add_att_label.pack(side="left", padx=(0, 8))

        def add_attach_func():
            files = self._attach_files_dialog("kb", add_attach)
            add_attach["files"] = files
            add_att_label.configure(text=f"📎 Вложений: {len(files)}/3")

        self._ghost_button(add_att_row, "📎  Прикрепить",
                           command=add_attach_func,
                           width=140, height=28).pack(side="left")

        if kb.all_tags:
            existing_row = ctk.CTkFrame(box, fg_color="transparent")
            existing_row.pack(fill="x", pady=(4, 0))
            ctk.CTkLabel(existing_row, text="Существующие:",
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_MUTED).pack(side="left", padx=(0, 6))
            for tag in sorted(kb.all_tags)[:12]:
                ctk.CTkButton(
                    existing_row, text=tag,
                    font=("Segoe UI", 10), height=24, width=0,
                    fg_color=COLOR_CARD, hover_color=COLOR_CARD_HOVER,
                    text_color=COLOR_TEXT,
                    border_width=1, border_color=COLOR_BORDER,
                    command=lambda t=tag: self._add_tag_to_entry(tags_entry, t)
                ).pack(side="left", padx=2)

        def add_question():
            q = q_entry.get().strip()
            a = a_text.get("1.0", "end").strip()
            cat = cat_menu.get().strip() or "общие"
            diff = diff_menu.get()
            tags_raw = tags_entry.get().strip()
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()] if tags_raw else []
            if not q or not a:
                messagebox.showerror("Ошибка", "❌ Заполните вопрос и ответ!")
                return
            if kb.question_exists(q):
                messagebox.showwarning("Дубликат", "⚠️ Вопрос уже есть!")
                return
            text = f"Вопрос: {q}\nОтвет: {a}"
            kb.add_text(text, category=cat, difficulty=diff, tags=tags,
                        attachments=add_attach["files"])
            journal_db.log(self.current_user, self.current_role,
                           "Добавил вопрос", q[:80])
            rebuild_all_questions()
            self.load_faq_questions()
            try:
                self.records_label.configure(text=f"{len(kb.chunks)}  записей")
            except Exception:
                pass
            messagebox.showinfo("Успех", "✅ Вопрос добавлен!")
            q_entry.delete(0, "end"); a_text.delete("1.0", "end")
            tags_entry.delete(0, "end")
            add_attach["files"] = []
            add_att_label.configure(text="📎 Вложений: 0/3")
            if self.current_admin_section == "tags":
                self._refresh_tags_tab_content()

        self._accent_button(box, "➕  Добавить вопрос",
                            command=add_question,
                            width=220, height=44).pack(pady=16, anchor="w")

    def _add_tag_to_entry(self, entry, tag):
        current = entry.get().strip()
        if current:
            parts = [p.strip() for p in current.split(",") if p.strip()]
            if tag.lower() not in [p.lower() for p in parts]:
                entry.delete(0, "end")
                entry.insert(0, current + ", " + tag)
        else:
            entry.insert(0, tag)

    def build_edit_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="✏️  Управление записями",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self.selected_count_label = ctk.CTkLabel(head, text="",
                                                 font=("Segoe UI", 11),
                                                 text_color=COLOR_TEXT_MUTED)
        self.selected_count_label.pack(side="right")
        filter_box = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT, corner_radius=10)
        filter_box.pack(fill="x", pady=6)
        ctk.CTkLabel(filter_box, text="🔍", font=("Segoe UI", 13),
                     text_color=COLOR_TEXT_MUTED).pack(side="left", padx=(12, 0))
        self.edit_filter = ctk.CTkEntry(filter_box,
                                        placeholder_text="Фильтр записей...",
                                        placeholder_text_color=COLOR_TEXT_MUTED,
                                        font=("Segoe UI", 12), height=36,
                                        fg_color="transparent", border_width=0,
                                        text_color=COLOR_TEXT)
        self.edit_filter.pack(side="left", fill="x", expand=True,
                              padx=(6, 12), pady=4)
        self.edit_filter.bind("<KeyRelease>", lambda e: self.refresh_delete_list())
        self._attach_clipboard_support(self.edit_filter)
        self.delete_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.delete_list.pack(fill="both", expand=True, pady=6)
        btns = ctk.CTkFrame(box, fg_color="transparent")
        btns.pack(fill="x", pady=8)
        self._ghost_button(btns, "🗑️  Удалить выбранные",
                           command=self.delete_selected,
                           width=200, height=38).pack(side="left", padx=(0, 8))
        ctk.CTkButton(btns, text="🗑️  Очистить базу",
                      font=("Segoe UI", 11, "bold"),
                      height=38, width=170, corner_radius=10,
                      fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                      text_color="#fff", command=self.admin_clear
                      ).pack(side="right")
        self.selected_indices = set()
        self.refresh_delete_list()

    def refresh_delete_list(self):
        if not hasattr(self, "delete_list") or not self.delete_list.winfo_exists():
            return
        for w in self.delete_list.winfo_children():
            w.destroy()
        filt = ""
        if hasattr(self, "edit_filter"):
            filt = self.edit_filter.get().lower().strip()
        if not hasattr(self, "selected_indices"):
            self.selected_indices = set()
        if len(kb.chunks) == 0:
            ctk.CTkLabel(self.delete_list, text="📭  База знаний пуста",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=30)
            return
        shown = 0
        for i in range(len(kb.chunks)):
            text = kb.chunks[i]
            m = kb.metadata[i] if i < len(kb.metadata) else {}
            if filt and filt not in text.lower():
                continue
            shown += 1
            row = ctk.CTkFrame(self.delete_list, fg_color=COLOR_CARD,
                               corner_radius=10, border_width=1,
                               border_color=COLOR_BORDER)
            row.pack(fill="x", pady=3, padx=4)
            var = tk.BooleanVar(value=(i in self.selected_indices))

            def toggle(idx=i, v=var):
                if v.get():
                    self.selected_indices.add(idx)
                else:
                    self.selected_indices.discard(idx)
                self.selected_count_label.configure(
                    text=f"Выбрано: {len(self.selected_indices)}"
                    if self.selected_indices else "")
            ctk.CTkCheckBox(row, text="", width=24,
                            checkbox_width=20, checkbox_height=20,
                            fg_color=COLOR_ACCENT,
                            hover_color=COLOR_ACCENT_HOVER,
                            border_color=COLOR_BORDER,
                            variable=var, command=toggle
                            ).pack(side="left", padx=(10, 6), pady=8)
            if "Вопрос:" in text:
                parts = text.split("Ответ:")
                q_part = parts[0].replace("Вопрос:", "").strip()
                disp = q_part[:60] + "..." if len(q_part) > 60 else q_part
            else:
                disp = text[:60] + "..." if len(text) > 60 else text
            source = m.get("source", "base")
            src_badge = "📚" if source == "langame" else ""
            tags = m.get("tags", [])
            tag_str = " 🏷️ " + ",".join(tags[:3]) if tags else ""
            atts = m.get("attachments", [])
            att_str = f" 📎{len(atts)}" if atts else ""
            views = m.get("views", 0)
            emoji = "🟢" if (i < len(kb.difficulty) and kb.difficulty[i] == "easy") else \
                    "🟡" if (i < len(kb.difficulty) and kb.difficulty[i] == "medium") else "🔴"
            ctk.CTkLabel(row,
                         text=f"{emoji} {src_badge} [{i}]  {disp}{tag_str}{att_str}  👁️{views}",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT, anchor="w"
                         ).pack(side="left", padx=4, pady=8, fill="x", expand=True)
            ctk.CTkButton(row, text="✎", font=("Segoe UI", 12, "bold"),
                          width=32, height=32, corner_radius=8,
                          fg_color=COLOR_PANEL_LIGHT,
                          hover_color=COLOR_ACCENT,
                          text_color=COLOR_ACCENT,
                          command=lambda idx=i: self.edit_question(idx)
                          ).pack(side="right", padx=4, pady=5)
            ctk.CTkButton(row, text="✖", font=("Segoe UI", 12, "bold"),
                          width=32, height=32, corner_radius=8,
                          fg_color=COLOR_DANGER,
                          hover_color=COLOR_DANGER_HOVER,
                          text_color="#fff",
                          command=lambda idx=i: self.confirm_delete(idx)
                          ).pack(side="right", padx=4, pady=5)
        if shown == 0 and filt:
            ctk.CTkLabel(self.delete_list, text="🔍  Ничего не найдено",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=30)

    def edit_question(self, index):
        if not (0 <= index < len(kb.chunks)):
            messagebox.showerror("Ошибка", "Запись не найдена.")
            return
        win = ctk.CTkToplevel(self.app)
        win.title("Редактирование")
        win.geometry("700x760")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app); win.grab_set()
        outer = ctk.CTkScrollableFrame(win, fg_color=COLOR_BG, corner_radius=0)
        outer.pack(fill="both", expand=True)
        box = ctk.CTkFrame(outer, fg_color=COLOR_PANEL,
                           corner_radius=14, border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        inner = ctk.CTkFrame(box, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(inner, text=f"✏️  Запись [{index}]",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 10))
        text = kb.chunks[index]
        q_old, a_old = chunk_to_qa(text)
        m = kb.metadata[index] if index < len(kb.metadata) else {}
        ctk.CTkLabel(inner, text="Вопрос:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        q_entry = ctk.CTkEntry(inner, font=("Segoe UI", 12), height=40,
                               fg_color=COLOR_PANEL_LIGHT, border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=10)
        q_entry.pack(fill="x", pady=(4, 10)); q_entry.insert(0, q_old)
        self._attach_clipboard_support(q_entry)
        ctk.CTkLabel(inner, text="Ответ:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        a_text = ctk.CTkTextbox(inner, font=("Segoe UI", 12), height=140,
                                fg_color=COLOR_PANEL_LIGHT,
                                border_color=COLOR_BORDER, border_width=1,
                                text_color=COLOR_TEXT, corner_radius=10, wrap="word")
        a_text.pack(fill="x", pady=(4, 10))
        a_text.insert("1.0", a_old)
        self._attach_clipboard_support(a_text)
        ctk.CTkLabel(inner, text="Категория:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        cat_menu = ctk.CTkComboBox(inner, values=sorted(kb.categories) or ["общие"],
                                   font=("Segoe UI", 12), height=36,
                                   fg_color=COLOR_PANEL_LIGHT,
                                   border_color=COLOR_BORDER,
                                   button_color=COLOR_ACCENT_DARK,
                                   button_hover_color=COLOR_ACCENT,
                                   text_color=COLOR_TEXT,
                                   dropdown_fg_color=COLOR_PANEL_LIGHT,
                                   dropdown_text_color=COLOR_TEXT,
                                   dropdown_hover_color=COLOR_CARD_HOVER,
                                   corner_radius=10)
        cat_menu.pack(fill="x", pady=(4, 10))
        cat_menu.set(m.get("category", "общие"))
        ctk.CTkLabel(inner, text="Сложность:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        diff_menu = ctk.CTkOptionMenu(inner, values=["easy", "medium", "hard"],
                                      font=("Segoe UI", 12), height=36, width=180,
                                      fg_color=COLOR_PANEL_LIGHT,
                                      button_color=COLOR_ACCENT_DARK,
                                      button_hover_color=COLOR_ACCENT,
                                      text_color=COLOR_TEXT,
                                      dropdown_fg_color=COLOR_PANEL_LIGHT,
                                      dropdown_text_color=COLOR_TEXT,
                                      dropdown_hover_color=COLOR_CARD_HOVER,
                                      corner_radius=10)
        diff_menu.set(kb.difficulty[index] if index < len(kb.difficulty) else "easy")
        diff_menu.pack(anchor="w", pady=(4, 10))
        ctk.CTkLabel(inner, text="Теги:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        tags_input_row = ctk.CTkFrame(inner, fg_color="transparent")
        tags_input_row.pack(fill="x", pady=(4, 4))
        tags_entry = ctk.CTkEntry(tags_input_row, placeholder_text="тег1, тег2",
                                  placeholder_text_color=COLOR_TEXT_MUTED,
                                  font=("Segoe UI", 12), height=36,
                                  fg_color=COLOR_PANEL_LIGHT,
                                  border_color=COLOR_BORDER,
                                  text_color=COLOR_TEXT, corner_radius=10)
        tags_entry.pack(side="left", fill="x", expand=True)
        self._attach_clipboard_support(tags_entry)
        tags_entry.insert(0, ", ".join(m.get("tags", [])))

        # Вложения в редактировании
        edit_atts = {"files": list(m.get("attachments", []))}
        edit_att_row = ctk.CTkFrame(inner, fg_color="transparent")
        edit_att_row.pack(fill="x", pady=(6, 4))
        edit_att_label = ctk.CTkLabel(edit_att_row,
                                      text=f"📎 Вложений: {len(edit_atts['files'])}/3",
                                      font=("Segoe UI", 10),
                                      text_color=COLOR_TEXT_MUTED)
        edit_att_label.pack(side="left", padx=(0, 8))

        def edit_attach():
            files = self._attach_files_dialog("kb", edit_atts)
            edit_atts["files"] = files
            edit_att_label.configure(text=f"📎 Вложений: {len(files)}/3")

        self._ghost_button(edit_att_row, "📎  Прикрепить",
                           command=edit_attach,
                           width=140, height=28).pack(side="left")

        ctk.CTkLabel(inner, text="📌 Существующие теги (отметь — добавится):",
                     font=("Segoe UI", 10),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", pady=(6, 2))
        tag_checks = {}
        if kb.all_tags:
            tags_cloud = ctk.CTkFrame(inner, fg_color=COLOR_PANEL_LIGHT,
                                      corner_radius=10, border_width=1,
                                      border_color=COLOR_BORDER)
            tags_cloud.pack(fill="x", pady=(2, 10))
            tc_inner = ctk.CTkFrame(tags_cloud, fg_color="transparent")
            tc_inner.pack(fill="x", padx=10, pady=8)
            current_tags = set(t.lower().strip() for t in m.get("tags", []))
            row_f = ctk.CTkFrame(tc_inner, fg_color="transparent")
            row_f.pack(fill="x")
            col = 0
            for tag in sorted(kb.all_tags):
                var = tk.BooleanVar(value=(tag in current_tags))
                tag_checks[tag] = var
                ctk.CTkCheckBox(
                    row_f, text=tag,
                    font=("Segoe UI", 11),
                    checkbox_width=18, checkbox_height=18,
                    fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                    text_color=COLOR_TEXT,
                    border_color=COLOR_BORDER,
                    variable=var
                ).pack(side="left", padx=(0, 12), pady=3)
                col += 1
                if col % 4 == 0:
                    row_f = ctk.CTkFrame(tc_inner, fg_color="transparent")
                    row_f.pack(fill="x", pady=0)

        def save():
            new_q = q_entry.get().strip()
            new_a = a_text.get("1.0", "end").strip()
            tags_from_field = [t.strip() for t in tags_entry.get().split(",") if t.strip()]
            tags_from_checks = [t for t, v in tag_checks.items() if v.get()]
            all_tags = list(dict.fromkeys([t for t in (tags_from_checks + tags_from_field) if t]))
            if not new_q or not new_a:
                messagebox.showerror("Ошибка", "❌ Заполните вопрос и ответ!")
                return
            new_text = f"Вопрос: {new_q}\nОтвет: {new_a}"
            kb.update_text(index, new_text, cat_menu.get(), diff_menu.get(),
                           new_tags=all_tags)
            # обновляем вложения в metadata
            kb.metadata[index]["attachments"] = list(edit_atts["files"])
            kb.save()
            rebuild_all_questions()
            journal_db.log(self.current_user, self.current_role,
                           "Изменил запись", new_q[:80])
            self.load_faq_questions()
            self.refresh_delete_list()
            if self.current_admin_section == "tags":
                self._refresh_tags_tab_content()
            messagebox.showinfo("Готово", "✅ Запись обновлена!")
            win.destroy()

        btn_row = ctk.CTkFrame(inner, fg_color="transparent")
        btn_row.pack(fill="x", pady=(6, 0))
        self._accent_button(btn_row, "💾  Сохранить",
                            command=save, width=180, height=42).pack(side="left")
        self._ghost_button(btn_row, "Отмена",
                           command=win.destroy, width=120, height=42).pack(side="right")

    def delete_selected(self):
        if not self.selected_indices:
            messagebox.showinfo("Выбор", "Ничего не выбрано."); return
        if not messagebox.askyesno("Подтверждение",
                                   f"Удалить {len(self.selected_indices)} записей?"):
            return
        for idx in sorted(self.selected_indices, reverse=True):
            if 0 <= idx < len(kb.chunks):
                kb.delete_by_index(idx)
        journal_db.log(self.current_user, self.current_role,
                       f"Удалил записей: {len(self.selected_indices)}", "")
        self.selected_indices.clear()
        self.selected_count_label.configure(text="")
        rebuild_all_questions()
        self.load_faq_questions()
        self.refresh_delete_list()
        try:
            self.records_label.configure(text=f"{len(kb.chunks)}  записей")
        except Exception:
            pass
        if self.current_admin_section == "tags":
            self._refresh_tags_tab_content()

    def confirm_delete(self, index):
        text = kb.chunks[index]
        if "Вопрос:" in text:
            parts = text.split("Ответ:")
            q_part = parts[0].replace("Вопрос:", "").strip()
            disp = q_part[:50] + "..." if len(q_part) > 50 else q_part
        else:
            disp = text[:50] + "..." if len(text) > 50 else text
        if messagebox.askyesno("Подтверждение", f"Удалить:\n\n{disp}"):
            if kb.delete_by_index(index):
                journal_db.log(self.current_user, self.current_role,
                               "Удалил запись", disp)
                rebuild_all_questions()
                self.load_faq_questions()
                self.refresh_delete_list()
                try:
                    self.records_label.configure(text=f"{len(kb.chunks)}  записей")
                except Exception:
                    pass
                if self.current_admin_section == "tags":
                    self._refresh_tags_tab_content()

    def admin_clear(self):
        if not messagebox.askyesno("Подтверждение",
                                   "Создать бэкап и очистить ОБЫЧНУЮ базу?\n"
                                   "LANGame-записи останутся."):
            return
        try:
            backup_path = kb.backup()
            messagebox.showinfo("Бэкап", f"Сохранён бэкап:\n{backup_path}")
        except Exception as e:
            log_error(e, "admin_clear backup")
            messagebox.showwarning("Бэкап", f"Не удалось: {e}")
        kb.clear(keep_langame=True)
        for q in BASE_QUESTIONS:
            text = f"Вопрос: {q['question']}\nОтвет: {q['answer']}"
            kb.add_text(text, category=q['category'], difficulty=q['difficulty'],
                        tags=q.get("tags", []), source="base")
        journal_db.log(self.current_user, self.current_role,
                       "Очистил базу знаний", "")
        rebuild_all_questions()
        self.load_faq_questions()
        self.refresh_delete_list()
        try:
            self.records_label.configure(text=f"{len(kb.chunks)}  записей")
        except Exception:
            pass
        if self.current_admin_section == "tags":
            self._refresh_tags_tab_content()

    def build_stats_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="📊  Аналитика",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self._ghost_button(head, "📥  Отчёт (txt)",
                           command=self.export_stats,
                           width=140, height=32).pack(side="right", padx=(0, 6))
        self._ghost_button(head, "📊  Отчёт (CSV)",
                           command=self.export_stats_csv,
                           width=140, height=32).pack(side="right")
        scrollable = ctk.CTkScrollableFrame(box, fg_color="transparent")
        scrollable.pack(fill="both", expand=True)

        ctk.CTkLabel(scrollable, text="📈  Активность (тикеты за 14 дней)",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(6, 4))
        self.chart_frame = ctk.CTkFrame(scrollable, fg_color=COLOR_BG,
                                        corner_radius=12, border_width=1,
                                        border_color=COLOR_BORDER, height=140)
        self.chart_frame.pack(fill="x", pady=4)
        self.chart_frame.pack_propagate(False)

        ctk.CTkLabel(scrollable, text="🏆  Топ-5 техников (закрыто тикетов)",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(10, 4))
        self.tech_top_frame = ctk.CTkFrame(scrollable, fg_color=COLOR_BG,
                                           corner_radius=12, border_width=1,
                                           border_color=COLOR_BORDER)
        self.tech_top_frame.pack(fill="x", pady=4)

        self.avg_time_label = ctk.CTkLabel(scrollable, text="",
                                           font=("Segoe UI", 11),
                                           text_color=COLOR_TEXT_DIM)
        self.avg_time_label.pack(anchor="w", pady=(6, 4))

        ctk.CTkLabel(scrollable, text="🔧  Топ-5 проблемных ПК",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(10, 4))
        self.pcs_top_frame = ctk.CTkFrame(scrollable, fg_color=COLOR_BG,
                                          corner_radius=12, border_width=1,
                                          border_color=COLOR_BORDER)
        self.pcs_top_frame.pack(fill="x", pady=4)

        ctk.CTkLabel(scrollable, text="🔥  Топ-10 запросов",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(10, 4))
        self.top_list = ctk.CTkScrollableFrame(
            scrollable, fg_color=COLOR_BG, corner_radius=12, height=140,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.top_list.pack(fill="x", pady=4)

        ctk.CTkLabel(scrollable, text="👁️  Топ-10 просматриваемых ответов",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(10, 4))
        self.viewed_list = ctk.CTkScrollableFrame(
            scrollable, fg_color=COLOR_BG, corner_radius=12, height=140,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.viewed_list.pack(fill="x", pady=4)

        ctk.CTkLabel(scrollable, text="❌  Запросы без ответа",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(10, 4))
        self.failed_list = ctk.CTkScrollableFrame(
            scrollable, fg_color=COLOR_BG, corner_radius=12, height=200,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.failed_list.pack(fill="x", pady=4)
        self.refresh_history()

    def _draw_activity_chart(self):
        if not hasattr(self, "chart_frame") or not self.chart_frame.winfo_exists():
            return
        for w in self.chart_frame.winfo_children():
            w.destroy()
        daily = tickets_db.get_daily_stats(days=14)
        if not daily:
            ctk.CTkLabel(self.chart_frame, text="Нет данных").pack(pady=40)
            return
        max_count = max(c for _, c in daily) or 1
        chart_area = ctk.CTkFrame(self.chart_frame, fg_color="transparent")
        chart_area.pack(fill="both", expand=True, padx=14, pady=10)
        axis = ctk.CTkFrame(chart_area, fg_color="transparent", width=30)
        axis.pack(side="left", fill="y")
        ctk.CTkLabel(axis, text=str(max_count),
                     font=("Segoe UI", 9),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="n")
        bars_container = ctk.CTkFrame(chart_area, fg_color="transparent")
        bars_container.pack(side="left", fill="both", expand=True)
        for d, cnt in daily:
            col = ctk.CTkFrame(bars_container, fg_color="transparent")
            col.pack(side="left", fill="both", expand=True, padx=1)
            height_pct = cnt / max_count if max_count > 0 else 0
            bar_h = max(2, int(height_pct * 80))
            spacer = ctk.CTkFrame(col, fg_color="transparent", height=80 - bar_h)
            spacer.pack(side="top")
            bar = ctk.CTkFrame(col, fg_color=COLOR_ACCENT,
                               corner_radius=3, width=20, height=bar_h)
            bar.pack(side="top")
            try:
                day_num = d[-2:]
            except Exception:
                day_num = "?"
            ctk.CTkLabel(col, text=day_num,
                         font=("Consolas", 8),
                         text_color=COLOR_TEXT_MUTED).pack(side="bottom")
            if cnt > 0:
                ctk.CTkLabel(col, text=str(cnt),
                             font=("Segoe UI", 8, "bold"),
                             text_color=COLOR_ACCENT).pack(side="bottom")

    def _draw_technician_stats(self):
        if not hasattr(self, "tech_top_frame") or not self.tech_top_frame.winfo_exists():
            return
        for w in self.tech_top_frame.winfo_children():
            w.destroy()
        stats = tickets_db.get_technician_stats(limit=5)
        if not stats:
            ctk.CTkLabel(self.tech_top_frame,
                         text="📭  Пока нет закрытых тикетов",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=14)
            return
        inner = ctk.CTkFrame(self.tech_top_frame, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=10)
        max_c = stats[0][1] if stats else 1
        for i, (name, cnt) in enumerate(stats, 1):
            row = ctk.CTkFrame(inner, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=f"{i}.",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT, width=22).pack(side="left")
            ctk.CTkLabel(row, text=name,
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT, anchor="w",
                         width=120).pack(side="left", padx=(4, 10))
            bar_w = int((cnt / max_c) * 200)
            bar_bg = ctk.CTkFrame(row, height=8, corner_radius=4,
                                  fg_color=COLOR_PANEL_LIGHT,
                                  width=200)
            bar_bg.pack(side="left")
            bar_bg.pack_propagate(False)
            ctk.CTkFrame(bar_bg, height=8, corner_radius=4,
                         fg_color=COLOR_ACCENT, width=max(4, bar_w)
                         ).pack(side="left")
            ctk.CTkLabel(row, text=f"{cnt}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left", padx=(8, 0))

    def _draw_problem_pcs(self):
        if not hasattr(self, "pcs_top_frame") or not self.pcs_top_frame.winfo_exists():
            return
        for w in self.pcs_top_frame.winfo_children():
            w.destroy()
        stats = tickets_db.get_problem_pcs(limit=5)
        if not stats:
            ctk.CTkLabel(self.pcs_top_frame,
                         text="📭  Пока нет данных",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=14)
            return
        inner = ctk.CTkFrame(self.pcs_top_frame, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=10)
        max_c = stats[0][1] if stats else 1
        for i, (pc, cnt) in enumerate(stats, 1):
            row = ctk.CTkFrame(inner, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=f"{i}.",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT, width=22).pack(side="left")
            ctk.CTkLabel(row, text=f"ПК {pc}",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT, anchor="w",
                         width=120).pack(side="left", padx=(4, 10))
            bar_w = int((cnt / max_c) * 200)
            bar_bg = ctk.CTkFrame(row, height=8, corner_radius=4,
                                  fg_color=COLOR_PANEL_LIGHT,
                                  width=200)
            bar_bg.pack(side="left")
            bar_bg.pack_propagate(False)
            ctk.CTkFrame(bar_bg, height=8, corner_radius=4,
                         fg_color=COLOR_ERROR, width=max(4, bar_w)
                         ).pack(side="left")
            ctk.CTkLabel(row, text=f"{cnt}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ERROR).pack(side="left", padx=(8, 0))

    def refresh_history(self):
        self._draw_activity_chart()
        self._draw_technician_stats()
        avg = tickets_db.get_avg_resolution_time()
        if avg > 0:
            try:
                self.avg_time_label.configure(
                    text=f"⏱️  Среднее время решения: {format_duration(avg)}")
            except Exception:
                pass
        else:
            try:
                self.avg_time_label.configure(text="⏱️  Среднее время решения: —")
            except Exception:
                pass
        self._draw_problem_pcs()

        if not hasattr(self, "top_list") or not self.top_list.winfo_exists():
            return
        for w in self.top_list.winfo_children():
            w.destroy()
        top = kb.get_top_queries(limit=10)
        if not top:
            ctk.CTkLabel(self.top_list, text="📭  История пуста",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=20)
        else:
            max_cnt = max(c for _, c, _ in top)
            for i, (q, cnt, fnd) in enumerate(top, 1):
                row = ctk.CTkFrame(self.top_list, fg_color=COLOR_CARD,
                                   corner_radius=9, border_width=1,
                                   border_color=COLOR_BORDER)
                row.pack(fill="x", pady=2, padx=4)
                inner_row = ctk.CTkFrame(row, fg_color="transparent")
                inner_row.pack(fill="x", padx=10, pady=(6, 2))
                ctk.CTkLabel(inner_row, text=f"{i}",
                             font=("Segoe UI", 11, "bold"),
                             text_color=COLOR_ACCENT if i <= 3 else COLOR_TEXT_MUTED,
                             width=22).pack(side="left", padx=(0, 6))
                ctk.CTkLabel(inner_row, text=q[:50],
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT, anchor="w"
                             ).pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(inner_row, text=f"{cnt}×  ✅ {fnd}",
                             font=("Segoe UI", 10, "bold"),
                             text_color=COLOR_ACCENT).pack(side="right")
                bar_w = int((cnt / max_cnt) * 200)
                bar_bg = ctk.CTkFrame(row, height=4, corner_radius=2,
                                      fg_color=COLOR_PANEL_LIGHT)
                bar_bg.pack(fill="x", padx=10, pady=(0, 6))
                ctk.CTkFrame(bar_bg, height=4, corner_radius=2,
                             fg_color=COLOR_ACCENT, width=bar_w).pack(side="left")

        if hasattr(self, "viewed_list") and self.viewed_list.winfo_exists():
            for w in self.viewed_list.winfo_children():
                w.destroy()
            viewed = kb.get_top_viewed(limit=10)
            if not viewed:
                ctk.CTkLabel(self.viewed_list,
                             text="📭  Пока никто не открывал ответы",
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT_MUTED).pack(pady=20)
            else:
                max_v = viewed[0][1] if viewed else 1
                for i, (idx, cnt) in enumerate(viewed, 1):
                    if idx >= len(kb.chunks):
                        continue
                    q_txt, _ = chunk_to_qa(kb.chunks[idx])
                    m = kb.metadata[idx] if idx < len(kb.metadata) else {}
                    is_langame = m.get("source") == "langame"
                    badge = "📚 " if is_langame else ""
                    row = ctk.CTkFrame(self.viewed_list, fg_color=COLOR_CARD,
                                       corner_radius=9, border_width=1,
                                       border_color=COLOR_BORDER)
                    row.pack(fill="x", pady=2, padx=4)
                    inner_row = ctk.CTkFrame(row, fg_color="transparent")
                    inner_row.pack(fill="x", padx=10, pady=(6, 2))
                    ctk.CTkLabel(inner_row, text=f"{i}",
                                 font=("Segoe UI", 11, "bold"),
                                 text_color=COLOR_ACCENT if i <= 3 else COLOR_TEXT_MUTED,
                                 width=22).pack(side="left", padx=(0, 6))
                    ctk.CTkLabel(inner_row, text=f"{badge}{q_txt[:55]}",
                                 font=("Segoe UI", 11),
                                 text_color=COLOR_TEXT, anchor="w"
                                 ).pack(side="left", fill="x", expand=True)
                    ctk.CTkLabel(inner_row, text=f"👁️ {cnt}",
                                 font=("Segoe UI", 10, "bold"),
                                 text_color=COLOR_ACCENT).pack(side="right")
                    bar_w = max(2, int((cnt / max(1, max_v)) * 200))
                    bar_bg = ctk.CTkFrame(row, height=4, corner_radius=2,
                                          fg_color=COLOR_PANEL_LIGHT)
                    bar_bg.pack(fill="x", padx=10, pady=(0, 6))
                    ctk.CTkFrame(bar_bg, height=4, corner_radius=2,
                                 fg_color="#a78bfa" if is_langame else COLOR_ACCENT,
                                 width=bar_w).pack(side="left")

        for w in self.failed_list.winfo_children():
            w.destroy()
        failed = kb.get_failed_queries(limit=30)
        if not failed:
            ctk.CTkLabel(self.failed_list,
                         text="🎉  Все запросы находят ответ!",
                         font=("Segoe UI", 11),
                         text_color=COLOR_SUCCESS).pack(pady=20)
        else:
            for q, cnt in failed:
                row = ctk.CTkFrame(self.failed_list, fg_color=COLOR_CARD,
                                   corner_radius=9, border_width=1,
                                   border_color=COLOR_BORDER)
                row.pack(fill="x", pady=2, padx=4)
                ctk.CTkLabel(row, text="❌",
                             font=("Segoe UI", 12, "bold"),
                             text_color=COLOR_ERROR, width=24
                             ).pack(side="left", padx=(10, 6), pady=6)
                ctk.CTkLabel(row, text=q[:55],
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT, anchor="w"
                             ).pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(row, text=f"{cnt}×",
                             font=("Segoe UI", 11, "bold"),
                             text_color=COLOR_ERROR).pack(side="right", padx=10)
                ctk.CTkButton(row, text="➕", font=("Segoe UI", 12, "bold"),
                              width=28, height=28, corner_radius=7,
                              fg_color=COLOR_ACCENT_DARK,
                              hover_color=COLOR_ACCENT,
                              text_color=COLOR_ON_ACCENT,
                              command=lambda query=q: self.prefill_new_question(query)
                              ).pack(side="right", padx=(0, 6))

    def prefill_new_question(self, query):
        try:
            self.app.clipboard_clear()
            self.app.clipboard_append(query)
            messagebox.showinfo("Готово",
                                "✅ Скопировано.\nОткрой «➕ Добавить», вставь Ctrl+V.")
        except Exception:
            pass

    def export_stats(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Text files", "*.txt")],
            initialfile=f"stats_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
        if not path:
            return
        total = len(kb.search_history)
        found = sum(1 for e in kb.search_history if e["found"])
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(f"Dopamine — Отчёт\n{datetime.now().strftime('%d.%m.%Y %H:%M')}\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"Всего записей: {len(kb.chunks)}\n")
                f.write(f"Поисков: {total} (✅ {found} / ❌ {total - found})\n\n")
                f.write("Топ запросов:\n")
                for i, (q, c, fnd) in enumerate(kb.get_top_queries(20), 1):
                    f.write(f"  {i}. {q} — {c}× (✅ {fnd})\n")
                f.write("\nТоп просмотров:\n")
                for idx, v in kb.get_top_viewed(20):
                    if idx >= len(kb.chunks):
                        continue
                    q, _ = chunk_to_qa(kb.chunks[idx])
                    f.write(f"  {q[:60]} — 👁️ {v}\n")
                f.write("\nТоп техников:\n")
                for name, cnt in tickets_db.get_technician_stats(10):
                    f.write(f"  {name} — {cnt}\n")
                f.write(f"\nСреднее время решения: {format_duration(tickets_db.get_avg_resolution_time())}\n")
                f.write("\nТоп проблемных ПК:\n")
                for pc, cnt in tickets_db.get_problem_pcs(10):
                    f.write(f"  ПК {pc} — {cnt}\n")
            messagebox.showinfo("Готово", f"✅ Отчёт сохранён:\n{path}")
        except Exception as e:
            log_error(e, "export_stats")
            messagebox.showerror("Ошибка", f"{e}")

    def export_stats_csv(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV", "*.csv")],
            initialfile=f"stats_{datetime.now().strftime('%Y%m%d_%H%M')}.csv")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";")
                w.writerow(["Отчёт Dopamine"])
                w.writerow([f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M')}"])
                w.writerow([])
                w.writerow(["=== БАЗА ЗНАНИЙ ==="])
                w.writerow(["Всего записей", len(kb.chunks)])
                w.writerow(["Категорий", len(kb.categories)])
                w.writerow(["Уникальных тегов", len(kb.all_tags)])
                w.writerow(["LANGame-записей",
                            sum(1 for m in kb.metadata if m.get("source") == "langame")])
                w.writerow([])
                w.writerow(["=== ПОИСК ==="])
                total = len(kb.search_history)
                found = sum(1 for e in kb.search_history if e["found"])
                w.writerow(["Всего поисков", total])
                w.writerow(["Найдено", found])
                w.writerow(["Не найдено", total - found])
                w.writerow([])
                w.writerow(["=== ТОП-20 ЗАПРОСОВ ==="])
                w.writerow(["Запрос", "Количество", "Найдено"])
                for q, c, fnd in kb.get_top_queries(20):
                    w.writerow([q, c, fnd])
                w.writerow([])
                w.writerow(["=== ТОП-20 ПРОСМОТРОВ ==="])
                w.writerow(["Вопрос", "Просмотры"])
                for idx, v in kb.get_top_viewed(20):
                    if idx >= len(kb.chunks):
                        continue
                    q, _ = chunk_to_qa(kb.chunks[idx])
                    w.writerow([q[:100], v])
                w.writerow([])
                w.writerow(["=== ТОП ТЕХНИКОВ ==="])
                w.writerow(["Имя", "Закрыто тикетов"])
                for name, cnt in tickets_db.get_technician_stats(20):
                    w.writerow([name, cnt])
                w.writerow([])
                w.writerow(["=== ТОП ПРОБЛЕМНЫХ ПК ==="])
                w.writerow(["ПК", "Количество тикетов"])
                for pc, cnt in tickets_db.get_problem_pcs(20):
                    w.writerow([pc, cnt])
                w.writerow([])
                w.writerow(["=== ТИКЕТЫ ==="])
                w.writerow(["ID", "ПК", "Зона", "Приоритет", "Статус", "Автор",
                            "Исполнитель", "Создан", "Решил", "Проблема"])
                for t in tickets_db.get_all():
                    w.writerow([t.get("id"), t.get("pc"), t.get("zone", ""),
                                t.get("priority", ""), t.get("status", ""),
                                t.get("author", ""), t.get("assignee", ""),
                                t.get("created", "")[:16],
                                t.get("resolved_by", ""), t.get("problem", "")])
            messagebox.showinfo("Готово", f"✅ CSV сохранён:\n{path}")
            if messagebox.askyesno("Открыть", "Открыть файл сейчас?"):
                open_file_in_default_app(path)
        except Exception as e:
            log_error(e, "export_stats_csv")
            messagebox.showerror("Ошибка", f"{e}")

    def export_json(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=[("JSON", "*.json")],
            initialfile=f"knowledge_{datetime.now().strftime('%Y%m%d')}.json")
        if not path:
            return
        try:
            kb.export_json(path)
            messagebox.showinfo("Готово", f"✅ Экспортировано:\n{path}")
        except Exception as e:
            log_error(e, "export_json")
            messagebox.showerror("Ошибка", f"{e}")

    def export_pdf(self):
        if not HAS_REPORTLAB:
            messagebox.showerror("PDF недоступен",
                                 "Для экспорта в PDF установите:\n\n"
                                 "pip install reportlab")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
            initialfile=f"knowledge_{datetime.now().strftime('%Y%m%d')}.pdf")
        if not path:
            return
        try:
            export_knowledge_to_pdf(path)
            messagebox.showinfo("Готово", f"✅ PDF сохранён:\n{path}")
            if messagebox.askyesno("Открыть", "Открыть файл сейчас?"):
                open_file_in_default_app(path)
        except Exception as e:
            log_error(e, "export_pdf")
            messagebox.showerror("Ошибка", f"{e}")

    def import_json(self):
        if not messagebox.askyesno("Внимание",
                                   "Импорт заменит ВСЮ текущую базу!\n\nПродолжить?"):
            return
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            kb.import_json(path)
            rebuild_all_questions()
            self.load_faq_questions()
            try:
                self.records_label.configure(text=f"{len(kb.chunks)}  записей")
            except Exception:
                pass
            if self.current_admin_section == "edit":
                self.refresh_delete_list()
            messagebox.showinfo("Готово", "✅ База импортирована!")
        except Exception as e:
            log_error(e, "import_json")
            messagebox.showerror("Ошибка", f"{e}")

    def make_backup(self):
        try:
            path = kb.backup()
            messagebox.showinfo("Готово", f"✅ Бэкап создан:\n{path}")
        except Exception as e:
            log_error(e, "make_backup")
            messagebox.showerror("Ошибка", f"{e}")

    def build_journal_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="📝  Журнал действий",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        self._ghost_button(head, "🔄  Обновить",
                           command=self.refresh_journal,
                           width=140, height=32).pack(side="right", padx=(0, 6))
        self._ghost_button(head, "📄  Логи ошибок",
                           command=self.open_error_log,
                           width=140, height=32).pack(side="right", padx=(0, 6))
        ctk.CTkButton(head, text="🗑️  Очистить",
                      font=("Segoe UI", 11, "bold"),
                      height=32, width=140, corner_radius=10,
                      fg_color=COLOR_DANGER, hover_color=COLOR_DANGER_HOVER,
                      text_color="#fff",
                      command=self.clear_journal).pack(side="right")
        self.journal_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.journal_list.pack(fill="both", expand=True, pady=4)
        self.refresh_journal()

    def open_error_log(self):
        win = ctk.CTkToplevel(self.app)
        win.title("📄  Логи ошибок")
        win.geometry("900x600")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app)
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL,
                           corner_radius=14, border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(box, text="📄  Последние ошибки",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", padx=16, pady=(14, 6))
        ctk.CTkLabel(box, text=f"Файл: {LOG_FILE}",
                     font=("Consolas", 10),
                     text_color=COLOR_TEXT_MUTED).pack(anchor="w", padx=16, pady=(0, 8))
        txt = ctk.CTkTextbox(box, font=("Consolas", 10),
                             fg_color=COLOR_BG, text_color=COLOR_TEXT,
                             corner_radius=10)
        txt.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        try:
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
                tail = lines[-200:] if len(lines) > 200 else lines
                txt.insert("1.0", "".join(tail) if tail else "(файл пуст)")
            else:
                txt.insert("1.0", "(логов пока нет)")
        except Exception as e:
            txt.insert("1.0", f"Ошибка чтения: {e}")
        txt.configure(state="disabled")

        def clear_logs():
            if not messagebox.askyesno("Очистить", "Удалить все логи?"):
                return
            try:
                for fname in ["error.log", "error.1.log", "error.2.log", "error.3.log"]:
                    p = os.path.join(LOG_DIR, fname)
                    if os.path.exists(p):
                        os.remove(p)
                txt.configure(state="normal")
                txt.delete("1.0", "end")
                txt.insert("1.0", "(логи очищены)")
                txt.configure(state="disabled")
            except Exception as e:
                messagebox.showerror("Ошибка", str(e))

        btn_row = ctk.CTkFrame(box, fg_color="transparent")
        btn_row.pack(fill="x", padx=16, pady=(0, 14))
        self._ghost_button(btn_row, "🗑️  Очистить логи",
                           command=clear_logs,
                           width=180, height=38).pack(side="left")
        self._ghost_button(btn_row, "Закрыть",
                           command=win.destroy,
                           width=120, height=38).pack(side="right")

    def refresh_journal(self):
        if not hasattr(self, "journal_list") or not self.journal_list.winfo_exists():
            return
        for w in self.journal_list.winfo_children():
            w.destroy()
        entries = journal_db.get_all()[:200]
        if not entries:
            ctk.CTkLabel(self.journal_list,
                         text="📭  Журнал пуст",
                         font=("Segoe UI", 12),
                         text_color=COLOR_TEXT_MUTED).pack(pady=40)
            return
        for e in entries:
            row = ctk.CTkFrame(self.journal_list, fg_color=COLOR_CARD,
                               corner_radius=9, border_width=1,
                               border_color=COLOR_BORDER)
            row.pack(fill="x", pady=2, padx=4)
            top = ctk.CTkFrame(row, fg_color="transparent")
            top.pack(fill="x", padx=10, pady=(6, 2))
            try:
                t = datetime.fromisoformat(e["time"]).strftime("%d.%m %H:%M:%S")
            except Exception:
                t = "?"
            ctk.CTkLabel(top, text=t,
                         font=("Consolas", 10),
                         text_color=COLOR_TEXT_MUTED).pack(side="left", padx=(0, 10))
            role_icon = UsersDB.ROLES.get(e["role"], {}).get("icon", "👤")
            ctk.CTkLabel(top, text=f"{role_icon}  {e['user']}",
                         font=("Segoe UI", 11, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left", padx=(0, 10))
            ctk.CTkLabel(top, text=e["action"],
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT).pack(side="left")
            if e.get("details"):
                ctk.CTkLabel(row, text=e["details"],
                             font=("Segoe UI", 10),
                             text_color=COLOR_TEXT_DIM,
                             anchor="w", justify="left", wraplength=1000
                             ).pack(anchor="w", padx=14, pady=(0, 6))

    def clear_journal(self):
        if messagebox.askyesno("Очистить", "Удалить всю историю журнала?"):
            journal_db.clear()
            journal_db.log(self.current_user, self.current_role,
                           "Очистил журнал", "")
            self.refresh_journal()

    def build_users_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        head = ctk.CTkFrame(box, fg_color="transparent")
        head.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(head, text="👥  Пользователи",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")
        ctk.CTkLabel(head, text="Только тех-админ",
                     font=("Segoe UI", 10, "italic"),
                     text_color=COLOR_TEXT_MUTED).pack(side="right")
        add_frame = ctk.CTkFrame(box, fg_color=COLOR_PANEL_LIGHT,
                                 corner_radius=12, border_width=1,
                                 border_color=COLOR_BORDER)
        add_frame.pack(fill="x", pady=(0, 12))
        inner = ctk.CTkFrame(add_frame, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=14)
        ctk.CTkLabel(inner, text="➕  Добавить пользователя",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 8))
        row1 = ctk.CTkFrame(inner, fg_color="transparent")
        row1.pack(fill="x", pady=3)
        ctk.CTkLabel(row1, text="Логин:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM, width=90).pack(side="left")
        login_e = ctk.CTkEntry(row1, placeholder_text=f"{MIN_LOGIN_LENGTH}-{MAX_LOGIN_LENGTH} симв.",
                               placeholder_text_color=COLOR_TEXT_MUTED,
                               font=("Segoe UI", 11), height=34,
                               fg_color=COLOR_PANEL, border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=8)
        login_e.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self._attach_clipboard_support(login_e)
        ctk.CTkLabel(row1, text="Пароль:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM, width=90).pack(side="left")
        pass_e = ctk.CTkEntry(row1, placeholder_text=f"{MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} симв.",
                              placeholder_text_color=COLOR_TEXT_MUTED,
                              show="*", font=("Segoe UI", 11), height=34,
                              fg_color=COLOR_PANEL, border_color=COLOR_BORDER,
                              text_color=COLOR_TEXT, corner_radius=8)
        pass_e.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self._attach_clipboard_support(pass_e)
        ctk.CTkLabel(row1, text="Роль:", font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM, width=50).pack(side="left")
        role_menu = ctk.CTkOptionMenu(
            row1, values=["admin", "tech"],
            font=("Segoe UI", 11), height=34, width=130,
            fg_color=COLOR_PANEL, button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT, text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=8)
        role_menu.set("admin")
        role_menu.pack(side="left")
        ctk.CTkLabel(inner, text="Права доступа:",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w", pady=(10, 4))
        perms_frame = ctk.CTkFrame(inner, fg_color="transparent")
        perms_frame.pack(fill="x", pady=2)
        perm_vars = {}
        for idx, (perm_id, info) in enumerate(PERMISSIONS.items()):
            var = tk.BooleanVar(value=True)
            perm_vars[perm_id] = var
            ctk.CTkCheckBox(
                perms_frame, text=info["name"],
                font=("Segoe UI", 11),
                checkbox_width=20, checkbox_height=20,
                fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                text_color=COLOR_TEXT,
                border_color=COLOR_BORDER,
                variable=var).grid(row=idx // 4, column=idx % 4, sticky="w",
                                   padx=(0, 16), pady=3)
        quick_row = ctk.CTkFrame(inner, fg_color="transparent")
        quick_row.pack(fill="x", pady=(6, 0))

        def select_all():
            for v in perm_vars.values():
                v.set(True)

        def deselect_all():
            for v in perm_vars.values():
                v.set(False)

        ctk.CTkButton(quick_row, text="Выбрать всё",
                      font=("Segoe UI", 10),
                      height=28, width=130, corner_radius=8,
                      fg_color=COLOR_PANEL, hover_color=COLOR_CARD_HOVER,
                      text_color=COLOR_TEXT,
                      border_width=1, border_color=COLOR_BORDER,
                      command=select_all).pack(side="left", padx=(0, 6))
        ctk.CTkButton(quick_row, text="Снять всё",
                      font=("Segoe UI", 10),
                      height=28, width=130, corner_radius=8,
                      fg_color=COLOR_PANEL, hover_color=COLOR_CARD_HOVER,
                      text_color=COLOR_TEXT,
                      border_width=1, border_color=COLOR_BORDER,
                      command=deselect_all).pack(side="left")

        def on_role_change(choice):
            if choice == "tech":
                for v in perm_vars.values():
                    v.set(True)

        role_menu.configure(command=on_role_change)

        def add_user():
            role = role_menu.get()
            perms = [pid for pid, v in perm_vars.items() if v.get()]
            ok, msg = users_db.add_user(login_e.get(), pass_e.get(), role, perms)
            if ok:
                journal_db.log(self.current_user, self.current_role,
                               "Создал пользователя",
                               f"{login_e.get()} ({role}) — прав: {len(perms)}")
                messagebox.showinfo("Готово", f"✅ {msg}")
                login_e.delete(0, "end"); pass_e.delete(0, "end")
                self.refresh_users_list()
            else:
                messagebox.showerror("Ошибка", f"❌ {msg}")

        self._accent_button(inner, "➕  Добавить",
                            command=add_user,
                            width=180, height=38).pack(anchor="w", pady=(10, 0))
        ctk.CTkLabel(box, text="📋  Существующие пользователи",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLOR_TEXT).pack(anchor="w", pady=(8, 4))
        self.users_list = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        self.users_list.pack(fill="both", expand=True, pady=4)
        self.refresh_users_list()

    def refresh_users_list(self):
        if not hasattr(self, "users_list") or not self.users_list.winfo_exists():
            return
        for w in self.users_list.winfo_children():
            w.destroy()
        users = users_db.list_users()
        for login, role, permissions, created in users:
            row = ctk.CTkFrame(self.users_list, fg_color=COLOR_CARD,
                               corner_radius=9, border_width=1,
                               border_color=COLOR_BORDER)
            row.pack(fill="x", pady=3, padx=4)
            inner = ctk.CTkFrame(row, fg_color="transparent")
            inner.pack(fill="x", padx=12, pady=8)
            rdata = UsersDB.ROLES.get(role, {"icon": "👤", "name": role})
            ctk.CTkLabel(inner, text=f"{rdata['icon']}  {login}",
                         font=("Segoe UI", 12, "bold"),
                         text_color=COLOR_ACCENT).pack(side="left", padx=(0, 14))
            ctk.CTkLabel(inner, text=rdata["name"],
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT).pack(side="left", padx=(0, 14))
            if role == "tech":
                perms_text = "🔓 все права"
            else:
                perms_text = f"🔓 {len(permissions)} прав" if permissions else "🔒 нет прав"
            ctk.CTkLabel(inner, text=perms_text,
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_DIM).pack(side="left", padx=(0, 14))
            auto_t = "🌗 авто" if users_db.get_auto_theme(login) else ""
            if auto_t:
                ctk.CTkLabel(inner, text=auto_t,
                             font=("Segoe UI", 10),
                             text_color=COLOR_ACCENT).pack(side="left", padx=(0, 14))
            try:
                dt = datetime.fromisoformat(created).strftime("%d.%m.%Y")
            except Exception:
                dt = "?"
            ctk.CTkLabel(inner, text=f"создан {dt}",
                         font=("Segoe UI", 10),
                         text_color=COLOR_TEXT_MUTED).pack(side="left")

            def open_edit(l=login, r=role, p=list(permissions)):
                self.open_user_edit_dialog(l, r, p)

            if login != "tech":
                ctk.CTkButton(inner, text="✎  Изменить",
                              font=("Segoe UI", 10, "bold"),
                              width=110, height=30, corner_radius=8,
                              fg_color=COLOR_PANEL_LIGHT,
                              hover_color=COLOR_CARD_HOVER,
                              text_color=COLOR_TEXT,
                              border_width=1, border_color=COLOR_BORDER,
                              command=open_edit).pack(side="right", padx=(4, 0))

                def del_user(l=login):
                    if messagebox.askyesno("Удалить", f"Удалить {l}?"):
                        users_db.delete_user(l)
                        journal_db.log(self.current_user, self.current_role,
                                       f"Удалил пользователя {l}", "")
                        self.refresh_users_list()
                ctk.CTkButton(inner, text="🗑️",
                              font=("Segoe UI", 11, "bold"),
                              width=40, height=30, corner_radius=8,
                              fg_color=COLOR_DANGER,
                              hover_color=COLOR_DANGER_HOVER,
                              text_color="#fff",
                              command=del_user).pack(side="right", padx=(4, 0))
            else:
                ctk.CTkLabel(inner, text="(главный)",
                             font=("Segoe UI", 10, "italic"),
                             text_color=COLOR_TEXT_MUTED).pack(side="right")

    def open_user_edit_dialog(self, login, current_role, current_perms):
        win = ctk.CTkToplevel(self.app)
        win.title(f"✎  Редактирование: {login}")
        win.geometry("640x720")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app); win.grab_set()
        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL, corner_radius=14,
                           border_width=1, border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        inner = ctk.CTkFrame(box, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(inner, text=f"✎  {login}",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 16))
        ctk.CTkLabel(inner, text="Логин",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        login_e = ctk.CTkEntry(inner, font=("Segoe UI", 12), height=38,
                               fg_color=COLOR_PANEL_LIGHT,
                               border_color=COLOR_BORDER,
                               text_color=COLOR_TEXT, corner_radius=10)
        login_e.pack(fill="x", pady=(4, 12))
        login_e.insert(0, login)
        self._attach_clipboard_support(login_e)
        ctk.CTkLabel(inner, text=f"Новый пароль ({MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} симв., пусто = не менять)",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        pass_e = ctk.CTkEntry(inner, placeholder_text="••••••",
                              placeholder_text_color=COLOR_TEXT_MUTED,
                              show="*", font=("Segoe UI", 12), height=38,
                              fg_color=COLOR_PANEL_LIGHT,
                              border_color=COLOR_BORDER,
                              text_color=COLOR_TEXT, corner_radius=10)
        pass_e.pack(fill="x", pady=(4, 12))
        self._attach_clipboard_support(pass_e)
        ctk.CTkLabel(inner, text="Роль",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        role_menu = ctk.CTkOptionMenu(
            inner, values=["admin", "tech"],
            font=("Segoe UI", 12), height=38, width=200,
            fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER, corner_radius=10)
        role_menu.set(current_role)
        role_menu.pack(anchor="w", pady=(4, 12))
        auto_var = tk.BooleanVar(value=users_db.get_auto_theme(login))
        ctk.CTkCheckBox(
            inner, text="🌗  Авто-тема (день — светлая, вечер — тёмная)",
            font=("Segoe UI", 11),
            checkbox_width=20, checkbox_height=20,
            fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
            text_color=COLOR_TEXT,
            border_color=COLOR_BORDER,
            variable=auto_var
        ).pack(anchor="w", pady=(4, 12))
        ctk.CTkLabel(inner, text="Права доступа",
                     font=("Segoe UI", 11, "bold"),
                     text_color=COLOR_TEXT_DIM).pack(anchor="w")
        perms_frame = ctk.CTkFrame(inner, fg_color=COLOR_PANEL_LIGHT,
                                   corner_radius=10, border_width=1,
                                   border_color=COLOR_BORDER)
        perms_frame.pack(fill="x", pady=(4, 12))
        p_inner = ctk.CTkFrame(perms_frame, fg_color="transparent")
        p_inner.pack(fill="x", padx=14, pady=12)
        perm_vars = {}
        for idx, (perm_id, info) in enumerate(PERMISSIONS.items()):
            var = tk.BooleanVar(value=(perm_id in current_perms))
            perm_vars[perm_id] = var
            ctk.CTkCheckBox(
                p_inner, text=info["name"],
                font=("Segoe UI", 11),
                checkbox_width=20, checkbox_height=20,
                fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
                text_color=COLOR_TEXT,
                border_color=COLOR_BORDER,
                variable=var).grid(row=idx // 2, column=idx % 2, sticky="w",
                                   padx=(0, 20), pady=3)

        def select_all():
            for v in perm_vars.values():
                v.set(True)

        def deselect_all():
            for v in perm_vars.values():
                v.set(False)

        quick_row = ctk.CTkFrame(inner, fg_color="transparent")
        quick_row.pack(fill="x", pady=(0, 8))
        ctk.CTkButton(quick_row, text="Выбрать всё",
                      font=("Segoe UI", 10), height=28, width=130,
                      corner_radius=8,
                      fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                      text_color=COLOR_TEXT,
                      border_width=1, border_color=COLOR_BORDER,
                      command=select_all).pack(side="left", padx=(0, 6))
        ctk.CTkButton(quick_row, text="Снять всё",
                      font=("Segoe UI", 10), height=28, width=130,
                      corner_radius=8,
                      fg_color=COLOR_PANEL_LIGHT, hover_color=COLOR_CARD_HOVER,
                      text_color=COLOR_TEXT,
                      border_width=1, border_color=COLOR_BORDER,
                      command=deselect_all).pack(side="left")

        def save():
            new_login = login_e.get().strip().lower()
            new_pass = pass_e.get()
            new_role = role_menu.get()
            new_perms = [pid for pid, v in perm_vars.items() if v.get()]
            changes = []
            if new_login and new_login != login:
                ok, msg = users_db.change_login(login, new_login)
                if not ok:
                    messagebox.showerror("Ошибка логина", f"❌ {msg}")
                    return
                changes.append(f"логин → {new_login}")
            target_login = new_login or login
            if new_pass:
                ok, msg = users_db.change_password(target_login, new_pass)
                if not ok:
                    messagebox.showerror("Ошибка пароля", f"❌ {msg}")
                    return
                changes.append("пароль изменён")
            if new_role != current_role:
                ok, msg = users_db.change_role(target_login, new_role)
                if not ok:
                    messagebox.showerror("Ошибка роли", f"❌ {msg}")
                    return
                changes.append(f"роль → {new_role}")
            if new_role == "admin":
                ok, msg = users_db.change_permissions(target_login, new_perms)
                if not ok:
                    messagebox.showerror("Ошибка прав", f"❌ {msg}")
                    return
                changes.append(f"прав: {len(new_perms)}")
            users_db.set_auto_theme(target_login, auto_var.get())
            if auto_var.get():
                changes.append("авто-тема включена")
            if changes:
                journal_db.log(self.current_user, self.current_role,
                               f"Изменил пользователя {login}",
                               ", ".join(changes))
                messagebox.showinfo("Готово", "✅ Изменения сохранены")
            win.destroy()
            self.refresh_users_list()

        btn_row = ctk.CTkFrame(inner, fg_color="transparent")
        btn_row.pack(fill="x", pady=(8, 0))
        self._accent_button(btn_row, "💾  Сохранить",
                            command=save, width=180, height=42).pack(side="left")
        self._ghost_button(btn_row, "Отмена",
                           command=win.destroy, width=120, height=42).pack(side="right")
    def build_update_tab(self, parent):
        """Раздел «Обновление». Вся логика — в update_ui.py,
        чтобы app.py не распухал."""
        if not HAS_UPDATER:
            ctk.CTkLabel(parent, text="⚠️  Модуль обновления не загружен",
                         font=("Segoe UI", 14),
                         text_color=COLOR_TEXT_MUTED).pack(expand=True)
            return
        update_ui.build_update_tab(self, parent)
    def build_io_tab(self, parent):
        box = ctk.CTkFrame(parent, fg_color="transparent")
        box.pack(fill="both", expand=True, padx=18, pady=16)
        ctk.CTkLabel(box, text="💾  Экспорт / Бэкап",
                     font=("Segoe UI", 16, "bold"),
                     text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 12))
        ctk.CTkLabel(box,
                     text="Автобэкап запускается при каждом старте приложения.\n"
                          f"Хранится последние {MAX_BACKUPS} копий в data/backups/.\n\n"
                          "Экспорт доступен только в форматах: JSON и PDF.",
                     font=("Segoe UI", 11),
                     text_color=COLOR_TEXT_DIM,
                     justify="left").pack(anchor="w", pady=(0, 16))
        self._accent_button(box, "📤  Экспорт в JSON",
                            command=self.export_json,
                            width=240, height=44).pack(anchor="w", pady=6)
        self._accent_button(box, "📄  Экспорт в PDF",
                            command=self.export_pdf,
                            width=240, height=44).pack(anchor="w", pady=6)
        self._ghost_button(box, "📥  Импорт из JSON (полная замена)",
                           command=self.import_json,
                           width=240, height=44).pack(anchor="w", pady=6)
        self._ghost_button(box, "💾  Создать бэкап базы (сейчас)",
                           command=self.make_backup,
                           width=240, height=44).pack(anchor="w", pady=6)

        def open_backup_folder():
            try:
                if sys.platform == "win32":
                    os.startfile(BACKUP_DIR)
                elif sys.platform == "darwin":
                    os.system(f'open "{BACKUP_DIR}"')
                else:
                    os.system(f'xdg-open "{BACKUP_DIR}"')
            except Exception as e:
                messagebox.showerror("Ошибка", str(e))

        self._ghost_button(box, "📂  Открыть папку бэкапов",
                           command=open_backup_folder,
                           width=240, height=44).pack(anchor="w", pady=6)

    def export_dialog(self):
        if not self.history:
            messagebox.showinfo("Экспорт", "Диалог пуст."); return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Text files", "*.txt")],
            initialfile=f"dialog_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(f"Dopamine Assistant — диалог от {datetime.now().strftime('%d.%m.%Y %H:%M')}\n")
                f.write("=" * 60 + "\n\n")
                for m in self.history:
                    role = "🤖 Ассистент" if m["role"] == "assistant" else "👤 Пользователь"
                    clean = strip_md_links(m["text"])
                    f.write(f"{role}:\n{clean}\n\n{'─' * 60}\n\n")
            messagebox.showinfo("Экспорт", f"✅ Диалог сохранён:\n{path}")
        except Exception as e:
            log_error(e, "export_dialog")
            messagebox.showerror("Ошибка", f"{e}")

    def clear_chat(self):
        if not messagebox.askyesno("Очистка", "Очистить весь диалог?"):
            return
        self._cancel_typing(add_separator=False)
        self.chat_text.configure(state="normal")
        self.chat_text.delete("1.0", "end")
        self.chat_text.configure(state="disabled")
        self.history = []
        self.msg_count.configure(text="Сообщений: 0")
        self.add_bot_message("🧹  Диалог очищен. Чем ещё помочь?", animate=True,
                             show_actions=False)

    def show_stats(self):
        total = len(kb.search_history)
        found = sum(1 for e in kb.search_history if e["found"])
        not_found = total - found
        top = kb.get_top_queries(limit=5)
        tstats = tickets_db.stats()
        sug = suggestions_db.count_pending()
        langame_cnt = sum(1 for m in kb.metadata if m.get("source") == "langame")
        avg = tickets_db.get_avg_resolution_time()
        avg_str = format_duration(avg) if avg > 0 else "—"
        resp = (f"📊  Статистика\n{'─' * 35}\n\n"
                f"📚  Записей: {len(kb.chunks)}\n"
                f"📖  из них LANGame: {langame_cnt}\n"
                f"🏷️  Уникальных тегов: {len(kb.all_tags)}\n"
                f"📂  Категорий: {len(kb.categories)}\n\n"
                f"🚨  Тикеты: {tstats['total']}\n"
                f"    🆕 {tstats['new']}  ⚙️ {tstats['in_progress']}  ⏳ {tstats['waiting']}\n"
                f"    📦 В архиве: {tstats['archive']}\n"
                f"    🔴 Критичных: {tstats['critical']}\n"
                f"    ⏱️ Среднее решение: {avg_str}\n\n"
                f"✍️  Предложений: {sug}\n\n"
                f"🔍  Поиск: {total}  (✅ {found} / ❌ {not_found})\n\n")
        if top:
            resp += "🔥  Топ-5:\n"
            for i, (q, cnt, _) in enumerate(top, 1):
                resp += f"     {i}. {q}  —  {cnt}×\n"
        self.add_bot_message(resp, animate=True, show_actions=False)

    def on_input_key(self, event):
        if event.keysym in ("Return", "Up", "Down", "Escape"):
            return
        self.save_draft()

    def on_up_arrow(self, event):
        if self.input_entry.get().strip() == "" and self.last_query:
            self.input_entry.insert(0, self.last_query)

    def save_draft(self):
        try:
            with open(os.path.join(APP_PATH, DRAFT_FILE), "w", encoding="utf-8") as f:
                f.write(self.input_entry.get())
        except Exception:
            pass

    def restore_draft(self):
        try:
            path = os.path.join(APP_PATH, DRAFT_FILE)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    text = f.read().strip()
                if text:
                    self.input_entry.insert(0, text)
        except Exception:
            pass

    # ===== AI-ОКНО =====
    def open_ai_window(self, prefill=None):
        win = ctk.CTkToplevel(self.app)
        win.title("🤖  AI-помощник")
        win.geometry("900x700")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app)

        def on_ai_window_close():
            # Если окно закрыли посреди записи голоса — не оставляем
            # висящий открытый поток с микрофона.
            if HAS_VOICE and voice_client and voice_client.is_recording():
                voice_client.cancel_recording()
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", on_ai_window_close)

        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL,
                           corner_radius=16, border_width=1,
                           border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=16, pady=16)

        head = ctk.CTkFrame(box, fg_color="transparent", height=52)
        head.pack(fill="x", padx=16, pady=(14, 0)); head.pack_propagate(False)
        ctk.CTkLabel(head, text="🤖  AI-помощник (Cloudflare)",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_AI if 'COLOR_AI' in globals() else COLOR_ACCENT
                     ).pack(side="left")
        status = "● онлайн" if (HAS_AI and ai_client and ai_client.available) \
                 else "● не подключён"
        ctk.CTkLabel(head, text=status, font=("Segoe UI", 10),
                     text_color=COLOR_SUCCESS if HAS_AI and ai_client and ai_client.available
                     else COLOR_TEXT_MUTED).pack(side="left", padx=(10, 0))

        chat_frame = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        chat_frame.pack(fill="both", expand=True, padx=16, pady=(10, 0))

        if not (ai_client and ai_client.history):
            ctk.CTkLabel(chat_frame, text="🤖", font=("Segoe UI", 44)
                         ).pack(pady=(30, 10))
            ctk.CTkLabel(chat_frame,
                         text="AI-помощник Cloudflare",
                         font=("Segoe UI", 16, "bold"),
                         text_color=COLOR_ACCENT).pack()
            ctk.CTkLabel(chat_frame,
                         text="Спроси что угодно про клуб, игры, "
                              "периферию.\nCtrl+Enter — отправить.",
                         font=("Segoe UI", 11),
                         text_color=COLOR_TEXT_MUTED).pack(pady=(6, 20))

        # Показать историю
        if ai_client:
            for msg in ai_client.history[-20:]:
                self._ai_bubble(chat_frame, msg["role"], msg["content"])

        # Очистить
        def clear_ai():
            if ai_client: ai_client.clear()
            for w in chat_frame.winfo_children(): w.destroy()
            ctk.CTkLabel(chat_frame, text="🧹 История очищена",
                         font=("Segoe UI", 11, "italic"),
                         text_color=COLOR_TEXT_MUTED).pack(pady=20)
        self._ghost_button(head, "🧹 Очистить", command=clear_ai,
                           width=110, height=32).pack(side="right")

        # Озвучка ответов (офлайн, работает без интернета)
        if not hasattr(self, "_ai_voice_reply"):
            self._ai_voice_reply = False

        voice_btn = self._ghost_button(
            head, "🔊 Озвучка" if self._ai_voice_reply else "🔇 Озвучка",
            command=lambda: None, width=120, height=32)
        voice_btn.pack(side="right", padx=(0, 6))

        def toggle_voice_reply():
            if HAS_VOICE and voice_client and voice_client.tts_available:
                self._ai_voice_reply = not self._ai_voice_reply
                voice_btn.configure(
                    text="🔊 Озвучка" if self._ai_voice_reply else "🔇 Озвучка")
            else:
                reason = (voice_client.tts_unavailable_reason()
                          if HAS_VOICE and voice_client
                          else "Модуль voice_client не подключён.")
                messagebox.showinfo("Озвучка недоступна", reason)
        voice_btn.configure(command=toggle_voice_reply)

        # Ввод
        input_row = ctk.CTkFrame(box, fg_color=COLOR_CARD,
                                 corner_radius=12, height=80,
                                 border_width=1, border_color=COLOR_BORDER)
        input_row.pack(fill="x", padx=16, pady=14)
        input_row.pack_propagate(False)

        ai_input = ctk.CTkTextbox(input_row, font=("Segoe UI", 12),
                                   height=56, fg_color=COLOR_PANEL_LIGHT,
                                   border_width=0, text_color=COLOR_TEXT,
                                   corner_radius=10, wrap="word")
        ai_input.pack(side="left", fill="both", expand=True,
                      padx=(10, 8), pady=12)

        mic_btn = self._ghost_button(input_row, "🎤", command=lambda: None,
                                      width=56, height=56, font_size=16)
        mic_btn.pack(side="left", padx=(0, 8), pady=12)
        mic_btn.configure(command=lambda: self._ai_toggle_mic(mic_btn, ai_input))

        send_btn = ctk.CTkButton(
            input_row, text="➤ Отправить",
            font=("Segoe UI", 12, "bold"),
            height=56, width=140, corner_radius=10,
            fg_color=COLOR_ACCENT, hover_color=COLOR_ACCENT_HOVER,
            text_color=COLOR_ON_ACCENT,
            command=lambda: self._ai_send(ai_input, chat_frame, send_btn))
        send_btn.pack(side="right", padx=(0, 10), pady=12)

        ai_input.bind("<Control-Return>",
                      lambda e: self._ai_send(ai_input, chat_frame, send_btn))

        if prefill:
            ai_input.insert("1.0", prefill)
            ai_input.focus()

    def _ai_bubble(self, parent, role, text):
        is_user = role == "user"
        bubble = ctk.CTkFrame(
            parent,
            fg_color=COLOR_ACCENT if is_user else COLOR_CARD,
            corner_radius=12)
        bubble.pack(anchor="e" if is_user else "w", padx=10, pady=6,
                     fill="x" if not is_user else None)
        ctk.CTkLabel(bubble, text=text,
                     font=("Segoe UI", 12),
                     text_color=COLOR_ON_ACCENT if is_user else COLOR_TEXT,
                     wraplength=620, justify="left",
                     anchor="w").pack(padx=14, pady=10,
                                       fill="x" if not is_user else None)

    def _ai_send(self, input_widget, chat_frame, send_btn):
        text = input_widget.get("1.0", "end").strip()
        if not text: return
        if not (ai_client and ai_client.available):
            messagebox.showerror("AI недоступен",
                                 "Проверь .env и CLOUDFLARE_API_KEY.")
            return

        input_widget.delete("1.0", "end")
        send_btn.configure(state="disabled")

        # Убираем приветствие
        for w in list(chat_frame.winfo_children()):
            w.destroy()
        # История
        for msg in ai_client.history[-20:]:
            self._ai_bubble(chat_frame, msg["role"], msg["content"])
        # Сообщение пользователя
        self._ai_bubble(chat_frame, "user", text)

        loading = ctk.CTkLabel(chat_frame, text="⏳ AI думает...",
                                font=("Segoe UI", 11, "italic"),
                                text_color=COLOR_TEXT_MUTED)
        loading.pack(anchor="w", padx=10, pady=8)

        def worker():
            try:
                # Поиск по ключевым словам в базе знаний клуба (RAG):
                # находим до 3 релевантных материалов и передаём их AI,
                # чтобы ответ опирался на специфику именно этого клуба,
                # а не только на общие знания модели.
                try:
                    matches = kb.search(text, top_k=3, source="base")
                    kb_context = [m["text"] for m in matches]
                except Exception as ex:
                    log_error(ex, "kb.search для AI-контекста")
                    kb_context = None
                answer = ai_client.chat(text, kb_context=kb_context)
            except Exception as ex:
                answer = f"❌ Ошибка: {ex}"
            self.app.after(0, lambda: self._ai_done(
                chat_frame, loading, answer, send_btn))

        threading.Thread(target=worker, daemon=True).start()

    def _ai_done(self, chat_frame, loading, answer, send_btn):
        try: loading.destroy()
        except Exception: pass
        self._ai_bubble(chat_frame, "assistant", answer)
        send_btn.configure(state="normal")
        if getattr(self, "_ai_voice_reply", False) and HAS_VOICE and voice_client \
                and voice_client.tts_available:
            voice_client.speak(answer)

    def _ai_toggle_mic(self, mic_btn, ai_input):
        """Кнопка 🎤: первый клик — начать запись, второй — остановить,
        распознать через Cloudflare Whisper и вставить текст в поле ввода."""
        if not (HAS_VOICE and voice_client):
            messagebox.showinfo("Голосовой ввод недоступен",
                                 "Модуль voice_client не подключён.")
            return

        if not voice_client.is_recording():
            if not voice_client.mic_available:
                messagebox.showinfo("Голосовой ввод недоступен",
                                     voice_client.mic_unavailable_reason())
                return
            if voice_client.start_recording():
                mic_btn.configure(text="⏺", fg_color=COLOR_DANGER,
                                  hover_color=COLOR_DANGER_HOVER)
            else:
                messagebox.showerror("Ошибка",
                                     "Не удалось начать запись с микрофона.")
            return

        # Уже пишем — останавливаем и распознаём
        mic_btn.configure(text="⏳", state="disabled")

        def worker():
            ok, result = voice_client.stop_recording_and_transcribe()

            def done():
                mic_btn.configure(text="🎤", state="normal",
                                  fg_color=COLOR_PANEL_LIGHT,
                                  hover_color=COLOR_CARD_HOVER)
                if ok:
                    ai_input.insert("end", (" " if ai_input.get("1.0", "end").strip()
                                             else "") + result)
                    ai_input.focus()
                else:
                    messagebox.showerror("Распознавание не удалось", result)
            self.app.after(0, done)

        threading.Thread(target=worker, daemon=True).start()

    # ===== LANGAME-ОКНО =====
    def open_langame_window(self):
        win = ctk.CTkToplevel(self.app)
        win.title("🎓  LAnGame")
        win.geometry("1100x750")
        win.configure(fg_color=COLOR_BG)
        win.transient(self.app)

        box = ctk.CTkFrame(win, fg_color=COLOR_PANEL,
                           corner_radius=16, border_width=1,
                           border_color=COLOR_BORDER)
        box.pack(fill="both", expand=True, padx=16, pady=16)

        head = ctk.CTkFrame(box, fg_color="transparent", height=52)
        head.pack(fill="x", padx=16, pady=(14, 0)); head.pack_propagate(False)
        ctk.CTkLabel(head, text="🎓  LAnGame — нюансы и опыт",
                     font=("Segoe UI", 15, "bold"),
                     text_color=COLOR_ACCENT).pack(side="left")

        # Фильтр по категории
        cats = ["Все"] + LANGAME_CATEGORIES
        filter_m = ctk.CTkOptionMenu(
            head, values=cats, font=("Segoe UI", 11),
            height=34, width=180, fg_color=COLOR_PANEL_LIGHT,
            button_color=COLOR_ACCENT_DARK,
            button_hover_color=COLOR_ACCENT,
            text_color=COLOR_TEXT,
            dropdown_fg_color=COLOR_PANEL_LIGHT,
            dropdown_text_color=COLOR_TEXT,
            dropdown_hover_color=COLOR_CARD_HOVER,
            corner_radius=10)
        filter_m.set("Все")
        filter_m.pack(side="left", padx=(16, 0))

        scroll = ctk.CTkScrollableFrame(
            box, fg_color=COLOR_BG, corner_radius=12,
            scrollbar_button_color=COLOR_ACCENT_DARK,
            scrollbar_button_hover_color=COLOR_ACCENT,
            border_width=1, border_color=COLOR_BORDER)
        scroll.pack(fill="both", expand=True, padx=16, pady=14)

        def render_cards(cat_filter="Все"):
            for w in scroll.winfo_children(): w.destroy()
            items = kb.get_by_source("langame")
            filtered = [(i, ch, m) for i, ch, m in items
                        if cat_filter == "Все"
                        or m.get("category") == cat_filter]
            if not filtered:
                ctk.CTkLabel(scroll, text="📭  Материалов пока нет",
                             font=("Segoe UI", 12),
                             text_color=COLOR_TEXT_MUTED).pack(pady=40)
                return
            for idx, chunk, meta in filtered:
                q, a = chunk_to_qa(chunk)
                cat = meta.get("category", "LAnGame")
                tags = meta.get("tags", [])
                related = self._find_related_tickets(q, a)

                card = ctk.CTkFrame(scroll, fg_color=COLOR_CARD,
                                    corner_radius=12, border_width=2,
                                    border_color=COLOR_ACCENT)
                card.pack(fill="x", pady=6, padx=4)

                ctk.CTkLabel(card, text=f"🎓  {q}",
                             font=("Segoe UI", 13, "bold"),
                             text_color=COLOR_ACCENT,
                             anchor="w", justify="left", wraplength=900
                             ).pack(fill="x", padx=14, pady=(12, 4))

                meta_line = f"📂 {cat}"
                if tags: meta_line += f"  •  🏷️ {', '.join(tags)}"
                ctk.CTkLabel(card, text=meta_line,
                             font=("Segoe UI", 10, "italic"),
                             text_color=COLOR_TEXT_MUTED,
                             anchor="w").pack(fill="x", padx=14, pady=(0, 6))

                ctk.CTkLabel(card, text=a[:400] + ("..." if len(a) > 400 else ""),
                             font=("Segoe UI", 11),
                             text_color=COLOR_TEXT,
                             anchor="w", justify="left", wraplength=900
                             ).pack(fill="x", padx=14, pady=(0, 8))

                if related:
                    ctk.CTkLabel(card,
                                 text="🎫 Связанные тикеты: " +
                                      ", ".join(f"#{tid}" for tid in related[:3]),
                                 font=("Segoe UI", 10, "italic"),
                                 text_color=COLOR_TEXT_DIM,
                                 anchor="w").pack(fill="x", padx=14, pady=(0, 6))

                btn_row = ctk.CTkFrame(card, fg_color="transparent")
                btn_row.pack(fill="x", padx=14, pady=(0, 12))

                ctk.CTkButton(btn_row, text="📥 В базу знаний",
                              font=("Segoe UI", 10, "bold"),
                              height=30, corner_radius=8,
                              fg_color=COLOR_ACCENT,
                              hover_color=COLOR_ACCENT_HOVER,
                              text_color=COLOR_ON_ACCENT,
                              command=lambda qq=q, aa=a, cc=cat, tt=list(tags):
                                  self._langame_to_base(qq, aa, cc, tt)
                              ).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_row, text="🗑 Удалить",
                              font=("Segoe UI", 10, "bold"),
                              height=30, corner_radius=8,
                              fg_color=COLOR_DANGER,
                              hover_color=COLOR_DANGER_HOVER,
                              text_color="#fff",
                              command=lambda i=idx, qq=q:
                                  (kb.delete_by_index(i),
                                   journal_db.log(self.current_user, self.current_role,
                                                   f"Удалил LAnGame: {qq[:50]}"),
                                   render_cards(filter_m.get()))
                              ).pack(side="right")

        filter_m.configure(command=lambda v: render_cards(v))
        render_cards("Все")

        def add_langame():
            dlg = ctk.CTkToplevel(win)
            dlg.title("Новый материал LAnGame")
            dlg.geometry("600x600")
            dlg.configure(fg_color=COLOR_BG)
            dlg.transient(win); dlg.grab_set()

            dbox = ctk.CTkFrame(dlg, fg_color=COLOR_PANEL,
                                corner_radius=14, border_width=1,
                                border_color=COLOR_BORDER)
            dbox.pack(fill="both", expand=True, padx=16, pady=16)
            inner = ctk.CTkFrame(dbox, fg_color="transparent")
            inner.pack(fill="both", expand=True, padx=20, pady=20)

            ctk.CTkLabel(inner, text="🎓 Новый материал LAnGame",
                         font=("Segoe UI", 15, "bold"),
                         text_color=COLOR_ACCENT).pack(anchor="w", pady=(0, 12))

            name_e = ctk.CTkEntry(inner, placeholder_text="Название",
                                   placeholder_text_color=COLOR_TEXT_MUTED,
                                   font=("Segoe UI", 12), height=40,
                                   fg_color=COLOR_PANEL_LIGHT,
                                   border_color=COLOR_BORDER,
                                   text_color=COLOR_TEXT, corner_radius=10)
            name_e.pack(fill="x", pady=4)

            cat_m = ctk.CTkOptionMenu(
                inner, values=LANGAME_CATEGORIES,
                font=("Segoe UI", 11), height=36, width=200,
                fg_color=COLOR_PANEL_LIGHT,
                button_color=COLOR_ACCENT_DARK,
                button_hover_color=COLOR_ACCENT,
                text_color=COLOR_TEXT,
                dropdown_fg_color=COLOR_PANEL_LIGHT,
                dropdown_text_color=COLOR_TEXT,
                dropdown_hover_color=COLOR_CARD_HOVER,
                corner_radius=10)
            cat_m.set(LANGAME_CATEGORIES[0])
            cat_m.pack(anchor="w", pady=4)

            tags_e = ctk.CTkEntry(inner, placeholder_text="Теги через запятую",
                                   placeholder_text_color=COLOR_TEXT_MUTED,
                                   font=("Segoe UI", 11), height=36,
                                   fg_color=COLOR_PANEL_LIGHT,
                                   border_color=COLOR_BORDER,
                                   text_color=COLOR_TEXT, corner_radius=10)
            tags_e.pack(fill="x", pady=4)

            desc = ctk.CTkTextbox(inner, font=("Segoe UI", 12), height=140,
                                   fg_color=COLOR_PANEL_LIGHT,
                                   border_color=COLOR_BORDER, border_width=1,
                                   text_color=COLOR_TEXT, corner_radius=10,
                                   wrap="word")
            desc.pack(fill="x", pady=4)

            def save():
                    q = name_e.get().strip()
                    a = desc.get("1.0", "end").strip()
                    if not q or not a:
                        messagebox.showerror("Ошибка",
                                             "Название и описание обязательны")
                        return
                    tags = [x.strip() for x in tags_e.get().split(",") if x.strip()]
                    kb.add_text(f"Вопрос: {q}\nОтвет: {a}",
                                category=cat_m.get(), difficulty="medium",
                                tags=tags, source="langame")
                    journal_db.log(self.current_user, self.current_role,
                                   f"Добавил LAnGame: {q[:50]}")
                    dlg.destroy()
                    render_cards(filter_m.get())

            btn_row = ctk.CTkFrame(inner, fg_color="transparent")
            btn_row.pack(fill="x", pady=(10, 0))
            self._accent_button(btn_row, "💾 Сохранить", command=save,
                                    width=180, height=42).pack(side="left")
            self._ghost_button(btn_row, "Отмена", command=dlg.destroy,
                                   width=120, height=42).pack(side="right")

        self._accent_button(head, "➕ Добавить материал",
                            command=add_langame,
                            width=200, height=34).pack(side="right")

    def _langame_to_base(self, q, a, cat, tags):
        base_cat = cat if cat in ["общие", "игры", "периферия",
                                   "софт", "админ", "сеть"] else "общие"
        kb.add_text(f"Вопрос: {q}\nОтвет: {a}", category=base_cat,
                    difficulty="medium", tags=list(tags), source="base")
        journal_db.log(self.current_user, self.current_role,
                       f"Скопировал LAnGame в базу: {q[:50]}")
        messagebox.showinfo("Готово", "✅ Скопировано в базу знаний")


    def on_close(self):
        self._notify_stop = True
        self._cancel_typing(add_separator=False)
        self.save_draft()
        try:
            self.app.destroy()
        except Exception:
            pass

    def run(self):
        self.app.mainloop()


# ===== ЗАПУСК =====
if __name__ == "__main__":
    app = ModernSupportApp()
    app.run()
