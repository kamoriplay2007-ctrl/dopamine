"""Готовит файлы релиза: zip-ассеты + SHA256SUMS.txt.

Запускать НА МАШИНЕ, ГДЕ СОБРАН EXE, из папки проекта:

    # обновление приложения (папка сборки PyInstaller onedir)
    python make_release.py app dist/DopamineAssistant

    # обновление только базы знаний / справочников
    python make_release.py data

    # оба сразу
    python make_release.py app dist/DopamineAssistant data

Результат кладётся в release/ — эти файлы и надо загрузить в GitHub
Release. Версия берётся из version.py, руками ничего вписывать не надо.
"""

import hashlib
import os
import shutil
import sys
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(ROOT, "release")

# Что кладём в архив обновления данных (пути относительно папки проекта)
DATA_FILES = [
    "base_questions.json",
    "data/synonyms.csv",
    "data/stop_words.csv",
]

# Что НИКОГДА не попадает в архив приложения
EXCLUDE_DIRS = {"data", "__pycache__", ".git", ".github", "release", "build"}
EXCLUDE_FILES = {".env", "update_token", "VERSION.tmp"}


def get_version() -> str:
    sys.path.insert(0, ROOT)
    import version
    return version.__version__


def sha256_of(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build_app_zip(src_dir: str, version: str) -> str:
    """Архивирует папку сборки. data/ и .env внутрь не попадают."""
    if not os.path.isdir(src_dir):
        raise SystemExit(f"Папка сборки не найдена: {src_dir}")

    # Кладём VERSION рядом с exe — чтобы версию было видно без запуска
    with open(os.path.join(src_dir, "VERSION"), "w", encoding="utf-8") as f:
        f.write(version)

    name = f"dopamine-app-v{version}-win64.zip"
    out = os.path.join(OUT_DIR, name)
    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirs, files in os.walk(src_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for fn in files:
                if fn in EXCLUDE_FILES:
                    continue
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, src_dir)
                z.write(full, rel)
                count += 1
    print(f"  {name}: {count} файлов, {os.path.getsize(out) / 1e6:.1f} МБ")
    return out


def build_data_zip(version: str) -> str:
    name = f"dopamine-data-v{version}.zip"
    out = os.path.join(OUT_DIR, name)
    found = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in DATA_FILES:
            full = os.path.join(ROOT, *rel.split("/"))
            if os.path.exists(full):
                z.write(full, rel)
                found += 1
            else:
                print(f"  ! пропущен (нет файла): {rel}")
    if not found:
        os.remove(out)
        raise SystemExit("Нечего класть в архив данных")
    print(f"  {name}: {found} файлов")
    return out


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)

    version = get_version()
    print(f"Версия из version.py: {version}  (тег релиза: v{version})")

    if os.path.isdir(OUT_DIR):
        shutil.rmtree(OUT_DIR)
    os.makedirs(OUT_DIR, exist_ok=True)

    built = []
    i = 0
    while i < len(args):
        if args[i] == "app":
            if i + 1 >= len(args):
                raise SystemExit("После 'app' укажите папку сборки")
            built.append(build_app_zip(args[i + 1], version))
            i += 2
        elif args[i] == "data":
            built.append(build_data_zip(version))
            i += 1
        else:
            raise SystemExit(f"Непонятный аргумент: {args[i]}")

    sums_path = os.path.join(OUT_DIR, "SHA256SUMS.txt")
    with open(sums_path, "w", encoding="utf-8") as f:
        for p in built:
            f.write(f"{sha256_of(p)} *{os.path.basename(p)}\n")

    print("\nГотово. Загрузите в GitHub Release эти файлы:")
    for p in built + [sums_path]:
        print("   ", os.path.basename(p))
    print(f"\nТег релиза: v{version}")


if __name__ == "__main__":
    main()
