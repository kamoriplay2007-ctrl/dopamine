"""Самообновление Dopamine Assistant через GitHub Releases.

Принципы:
  * Только stdlib (urllib, json, zipfile, hashlib, subprocess) — ни одной
    новой зависимости, апдейтер не может сломать сборку.
  * Репозиторий публичный: ни токена, ни авторизации не требуется —
    на клубных ПК не хранится никаких секретов.
  * Ни одна функция НЕ бросает исключений наружу. Любая ошибка =
    запись в лог + None/False. Если GitHub недоступен — приложение
    просто работает на старой версии.
  * Папку data/ апдейтер не трогает НИКОГДА (кроме своих подпапок
    data/updates и data/backups).
  * Ленивая инициализация: импорт модуля ничего не делает — ни сети,
    ни файлов (в отличие от ai_client/voice_client).

Соглашение об именах ассетов в релизе:
    dopamine-app-v1.3.0-win64.zip   — полная папка приложения (onedir)
    dopamine-data-v1.3.0.zip        — только база знаний / справочники
    SHA256SUMS.txt                  — контрольные суммы всех ассетов

В одном релизе может быть и то, и другое, и только одно из двух.
"""

import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile

logger = logging.getLogger("updater")

# ======================================================================
# КОНФИГУРАЦИЯ
# ======================================================================

# Базовый адрес API. Подменяется на http://127.0.0.1:8765 при локальном
# тестировании (см. fake_github.py) — код при этом не меняется.
API_BASE = os.environ.get("DOPAMINE_UPDATE_API_BASE",
                          "https://github.com/kamoriplay2007-ctrl/dopamine").rstrip("/")

# Полностью выключить апдейтер (например, на машине разработчика)
UPDATE_DISABLED = os.environ.get("DOPAMINE_UPDATE_DISABLED", "") == "1"

HTTP_TIMEOUT = 15          # секунд на запрос к API
DOWNLOAD_CHUNK = 256 * 1024
MAX_ASSET_MB = 500         # защита от скачивания чего-то безумного

ASSET_APP_PREFIX = "dopamine-app-"
ASSET_DATA_PREFIX = "dopamine-data-"
SUMS_ASSET_NAME = "SHA256SUMS.txt"

# Что архиву с данными разрешено перезаписывать. Всё остальное
# игнорируется — чтобы "обновление базы" не смогло подменить exe.
DATA_UPDATE_WHITELIST = (
    "base_questions.json",
    "data/synonyms.csv",
    "data/stop_words.csv",
    "data/knowledge.pkl",
)

# ======================================================================
# ПУТИ (дублируем логику app.py, чтобы не импортировать монолит)
# ======================================================================

if getattr(sys, "frozen", False):
    APP_PATH = os.path.dirname(sys.executable)
    EXE_PATH = sys.executable
else:
    APP_PATH = os.path.dirname(os.path.abspath(__file__))
    EXE_PATH = ""

DATA_DIR = os.path.join(APP_PATH, "data")
UPDATE_DIR = os.path.join(DATA_DIR, "updates")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
IS_FROZEN = bool(getattr(sys, "frozen", False))


def _ensure_dirs():
    for d in (UPDATE_DIR, BACKUP_DIR, os.path.join(DATA_DIR, "logs")):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError as e:
            logger.error("Не удалось создать %s: %s", d, e)


# ======================================================================
# ВЕРСИЯ И ТОКЕН
# ======================================================================

def get_current_version() -> str:
    """Версия из version.py, запасной вариант — файл VERSION рядом с exe."""
    try:
        import version as _v
        v = str(getattr(_v, "__version__", "")).strip()
        if v:
            return v
    except Exception as e:
        logger.warning("version.py недоступен: %s", e)
    try:
        with open(os.path.join(APP_PATH, "VERSION"), encoding="utf-8") as f:
            return f.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def get_repo() -> str:
    """owner/repo из переменной окружения или из version.py."""
    env = os.environ.get("DOPAMINE_REPO", "").strip()
    if env:
        return env
    try:
        import version as _v
        return str(getattr(_v, "GITHUB_REPO", "")).strip()
    except Exception:
        return ""


def get_token() -> str:
    """Токен НЕ нужен: репозиторий публичный, релизы качаются анонимно.

    Переменную DOPAMINE_GH_TOKEN можно задать только в одном случае —
    если с одного внешнего IP (весь клуб за одним NAT) упёрлись в лимит
    анонимных запросов GitHub API (60 в час). Тогда лимит поднимается
    до 5000. В коде и в репозитории токена нет и быть не должно.
    """
    return os.environ.get("DOPAMINE_GH_TOKEN", "").strip()


def parse_version(s: str) -> tuple:
    """'v1.3.0-beta2' -> (1, 3, 0, 0, 'beta2'). Пре-релиз < релиза."""
    s = (s or "").strip().lstrip("vV").split("+")[0]
    core, _, pre = s.partition("-")
    nums = []
    for part in core.split(".")[:3]:
        digits = "".join(ch for ch in part if ch.isdigit())
        nums.append(int(digits) if digits else 0)
    while len(nums) < 3:
        nums.append(0)
    return (nums[0], nums[1], nums[2], 0 if pre else 1, pre)


def is_newer(remote: str, local: str) -> bool:
    try:
        return parse_version(remote) > parse_version(local)
    except Exception as e:
        logger.error("Сравнение версий %r/%r: %s", remote, local, e)
        return False


# ======================================================================
# СЕТЬ
# ======================================================================

def _request(url: str, accept: str, timeout: int = HTTP_TIMEOUT):
    req = urllib.request.Request(url, headers={
        "Accept": accept,
        "User-Agent": "DopamineAssistant-Updater",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    tok = get_token()
    if tok:
        req.add_header("Authorization", "Bearer " + tok)
    return urllib.request.urlopen(req, timeout=timeout)


class UpdateItem:
    """Один ассет релиза, который нужно применить."""

    def __init__(self, kind, name, url, size, sha256):
        self.kind = kind          # "app" | "data"
        self.name = name
        self.url = url
        self.size = int(size or 0)
        self.sha256 = (sha256 or "").lower()

    def __repr__(self):
        return f"<UpdateItem {self.kind} {self.name} {self.size}B>"


class UpdateInfo:
    """Результат проверки: что за версия и какие файлы к ней приложены."""

    def __init__(self, version, tag, notes, items, published_at=""):
        self.version = version
        self.tag = tag
        self.notes = notes or ""
        self.items = items        # список UpdateItem
        self.published_at = published_at

    @property
    def has_app(self):
        return any(i.kind == "app" for i in self.items)

    @property
    def total_size(self):
        return sum(i.size for i in self.items)


def _parse_sums(text: str) -> dict:
    """Разбирает SHA256SUMS.txt формата `<hash> *<имя файла>`."""
    out = {}
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        h, name = parts[0].strip(), parts[1].strip().lstrip("*")
        if len(h) == 64:
            out[name] = h.lower()
    return out


def _download_sums(assets) -> dict:
    for a in assets:
        if a.get("name") == SUMS_ASSET_NAME:
            try:
                # Публичный репозиторий: качаем по прямой ссылке,
                # без API и без авторизации.
                with _request(a.get("browser_download_url"),
                              "application/octet-stream") as r:
                    return _parse_sums(r.read(64 * 1024).decode("utf-8", "ignore"))
            except Exception as e:
                logger.warning("SHA256SUMS.txt не скачался: %s", e)
    return {}


def check_for_update(include_prerelease: bool = False):
    """Возвращает UpdateInfo или None. Никогда не бросает исключений.

    Блокирующая (сетевая) функция — вызывать из фонового потока.
    """
    if UPDATE_DISABLED:
        logger.info("Апдейтер выключен через DOPAMINE_UPDATE_DISABLED=1")
        return None

    repo = get_repo()
    if not repo or repo == "OWNER/REPO":
        logger.warning("Репозиторий не настроен (version.GITHUB_REPO)")
        return None

    url = f"{API_BASE}/repos/{repo}/releases/latest"
    try:
        with _request(url, "application/vnd.github+json") as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            logger.error("Проверка обновлений: репозиторий %s не найден, "
                         "опубликованных релизов нет, или репозиторий "
                         "приватный (404)", repo)
        elif e.code == 403:
            logger.error("Проверка обновлений: превышен лимит анонимных "
                         "запросов GitHub, 60 в час на IP (403). Пройдёт "
                         "само в течение часа.")
        else:
            logger.error("Проверка обновлений: HTTP %s", e.code)
        return None
    except Exception as e:
        logger.warning("Проверка обновлений недоступна (сеть): %s", e)
        return None

    try:
        if data.get("draft"):
            return None
        if data.get("prerelease") and not include_prerelease:
            return None

        tag = str(data.get("tag_name") or "")
        remote = tag.lstrip("vV")
        current = get_current_version()
        if not is_newer(remote, current):
            logger.info("Обновлений нет: установлена %s, в релизе %s",
                        current, remote or "?")
            return None

        assets = data.get("assets") or []
        sums = _download_sums(assets)

        items = []
        for a in assets:
            name = str(a.get("name") or "")
            if name == SUMS_ASSET_NAME or not name.lower().endswith(".zip"):
                continue
            if name.startswith(ASSET_APP_PREFIX):
                kind = "app"
            elif name.startswith(ASSET_DATA_PREFIX):
                kind = "data"
            else:
                logger.info("Ассет %s пропущен (не подходит под соглашение "
                            "об именах)", name)
                continue
            size = int(a.get("size") or 0)
            if size > MAX_ASSET_MB * 1024 * 1024:
                logger.error("Ассет %s слишком большой (%d байт)", name, size)
                continue
            items.append(UpdateItem(kind, name,
                                    a.get("browser_download_url"), size,
                                    sums.get(name, "")))

        if not items:
            logger.error("В релизе %s нет подходящих ассетов", tag)
            return None

        # Сначала данные, приложение — последним (оно перезапускает программу)
        items.sort(key=lambda i: 0 if i.kind == "data" else 1)

        info = UpdateInfo(remote, tag, data.get("body"), items,
                          str(data.get("published_at") or ""))
        logger.info("Найдено обновление %s (ассетов: %d)", remote, len(items))
        return info
    except Exception as e:
        logger.error("Разбор ответа GitHub: %s", e, exc_info=True)
        return None


# ======================================================================
# СКАЧИВАНИЕ
# ======================================================================

def _rm(path):
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def download_item(item: UpdateItem, progress_cb=None):
    """Скачивает ассет в data/updates/. Возвращает путь к файлу или None.

    progress_cb(скачано_байт, всего_байт) — для прогресс-бара в GUI.
    Пишет во временный .part и переименовывает только после успешной
    проверки размера, SHA256 и целостности zip.
    """
    _ensure_dirs()
    dst = os.path.join(UPDATE_DIR, os.path.basename(item.name))
    tmp = dst + ".part"
    _rm(tmp)

    h = hashlib.sha256()
    got = 0
    try:
        with _request(item.url, "application/octet-stream") as r, \
                open(tmp, "wb") as f:
            while True:
                chunk = r.read(DOWNLOAD_CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                h.update(chunk)
                got += len(chunk)
                if got > MAX_ASSET_MB * 1024 * 1024:
                    raise RuntimeError("превышен лимит размера файла")
                if progress_cb:
                    try:
                        progress_cb(got, item.size)
                    except Exception:
                        pass  # прогресс-бар не должен ронять скачивание
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        logger.error("Скачивание %s не удалось: %s", item.name, e)
        _rm(tmp)
        return None

    if item.size and got != item.size:
        logger.error("Размер %s не совпал: ожидали %d, получили %d",
                     item.name, item.size, got)
        _rm(tmp)
        return None

    digest = h.hexdigest()
    if item.sha256:
        if digest != item.sha256:
            logger.error("SHA256 %s не совпал: ожидали %s, получили %s",
                         item.name, item.sha256, digest)
            _rm(tmp)
            return None
    else:
        logger.warning("Для %s нет контрольной суммы в SHA256SUMS.txt "
                       "(проверка пропущена), sha256=%s", item.name, digest)

    if not zipfile.is_zipfile(tmp):
        logger.error("%s — битый архив", item.name)
        _rm(tmp)
        return None

    try:
        os.replace(tmp, dst)
    except OSError as e:
        logger.error("Не удалось переименовать %s: %s", tmp, e)
        _rm(tmp)
        return None

    logger.info("Скачано: %s (%d байт, sha256 %s…)", dst, got, digest[:12])
    return dst


# ======================================================================
# РАСПАКОВКА
# ======================================================================

def _safe_extract(zip_path: str, dest: str):
    """Распаковка с защитой от path traversal (zip slip)."""
    root = os.path.abspath(dest)
    os.makedirs(root, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        broken = z.testzip()
        if broken:
            raise RuntimeError(f"повреждён файл в архиве: {broken}")
        for m in z.infolist():
            name = m.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/"):
                raise RuntimeError(f"подозрительный путь в архиве: {name}")
            target = os.path.abspath(os.path.join(root, *name.split("/")))
            if target != root and not target.startswith(root + os.sep):
                raise RuntimeError(f"выход за пределы папки: {name}")
        z.extractall(root)


def _single_root(path: str) -> str:
    """Если в архиве одна верхняя папка — возвращает её, иначе сам path."""
    try:
        entries = os.listdir(path)
    except OSError:
        return path
    if len(entries) == 1 and os.path.isdir(os.path.join(path, entries[0])):
        return os.path.join(path, entries[0])
    return path


# ======================================================================
# УСТАНОВКА: ОБНОВЛЕНИЕ ДАННЫХ (без перезапуска)
# ======================================================================

def apply_data_update(zip_path: str) -> bool:
    """Обновляет справочники/базу знаний. Возвращает True при успехе.

    Перед заменой делает бэкап каждого затрагиваемого файла в
    data/backups/pre_update_<время>/ и при любой ошибке откатывается.
    Разрешено переписывать только пути из DATA_UPDATE_WHITELIST.
    """
    _ensure_dirs()
    staged = tempfile.mkdtemp(prefix="data_", dir=UPDATE_DIR)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup = os.path.join(BACKUP_DIR, f"pre_update_{stamp}")
    done = []  # (целевой путь, путь бэкапа или None если файла не было)
    try:
        _safe_extract(zip_path, staged)
        src_root = _single_root(staged)

        planned = []
        for dirpath, _dirs, files in os.walk(src_root):
            for fn in files:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, src_root).replace("\\", "/")
                if rel not in DATA_UPDATE_WHITELIST:
                    logger.warning("Файл %s не в белом списке — пропущен", rel)
                    continue
                planned.append((full, os.path.join(APP_PATH, *rel.split("/"))))

        if not planned:
            logger.error("В архиве данных нет разрешённых файлов")
            return False

        os.makedirs(backup, exist_ok=True)
        for src, dst in planned:
            bak = None
            if os.path.exists(dst):
                bak = os.path.join(backup, os.path.basename(dst))
                shutil.copy2(dst, bak)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            done.append((dst, bak))
            logger.info("Обновлён файл данных: %s", dst)
        return True
    except Exception as e:
        logger.error("Обновление данных не удалось, откатываюсь: %s",
                     e, exc_info=True)
        for dst, bak in done:
            try:
                if bak:
                    shutil.copy2(bak, dst)
                else:
                    os.remove(dst)
            except OSError as e2:
                logger.error("Откат %s не удался: %s", dst, e2)
        return False
    finally:
        _rm(staged)


# ======================================================================
# УСТАНОВКА: ОБНОВЛЕНИЕ ПРИЛОЖЕНИЯ (через helper + перезапуск)
# ======================================================================

_HELPER_BAT = r"""@echo off
chcp 65001 >nul
setlocal enableextensions
set "PID={pid}"
set "APPDIR={appdir}"
set "STAGED={staged}"
set "BACKUP={backup}"
set "LOG={log}"

echo. >> "%LOG%"
echo ===== %date% %time% helper start (pid %PID%) >> "%LOG%"

rem --- 1. Ждём, пока приложение закроется (максимум ~60 секунд) ---
set /a TRIES=0
:waitloop
tasklist /FI "PID eq %PID%" 2>nul | find "%PID%" >nul
if errorlevel 1 goto closed
set /a TRIES+=1
if %TRIES% GEQ 60 (
    echo ERROR: приложение не закрылось за 60 сек, обновление отменено >> "%LOG%"
    goto restart_only
)
ping -n 2 127.0.0.1 >nul
goto waitloop

:closed
echo Приложение закрыто, делаю бэкап >> "%LOG%"

rem --- 2. Бэкап текущей версии (без data\ — там пользовательская база) ---
robocopy "%APPDIR%" "%BACKUP%" /E /XD "%APPDIR%\data" /R:1 /W:1 /NFL /NDL /NP >> "%LOG%"
if errorlevel 8 (
    echo ERROR: бэкап не удался, обновление отменено >> "%LOG%"
    goto restart_only
)

rem --- 3. Подмена файлов приложения ---
echo Копирую новую версию >> "%LOG%"
robocopy "%STAGED%" "%APPDIR%" /E /XD data /R:2 /W:2 /NFL /NDL /NP >> "%LOG%"
if errorlevel 8 goto rollback
if not exist "%APPDIR%\{checkfile}" goto rollback

echo Обновление применено успешно >> "%LOG%"
rmdir /S /Q "%STAGED%" 2>nul
goto restart_only

:rollback
echo ROLLBACK: возвращаю предыдущую версию >> "%LOG%"
robocopy "%BACKUP%" "%APPDIR%" /E /R:2 /W:2 /NFL /NDL /NP >> "%LOG%"

:restart_only
echo Запускаю приложение >> "%LOG%"
cd /d "%APPDIR%"
start "" {restart}
echo ===== helper done >> "%LOG%"
exit /b 0
"""


def _restart_command() -> str:
    """Команда запуска приложения для bat-файла (в кавычках)."""
    if IS_FROZEN:
        return f'"{EXE_PATH}"'
    py = sys.executable
    pyw = os.path.join(os.path.dirname(py), "pythonw.exe")
    if os.path.exists(pyw):
        py = pyw
    return f'"{py}" "{os.path.join(APP_PATH, "app.py")}"'


def apply_app_update(zip_path: str) -> bool:
    """Готовит подмену файлов приложения и запускает helper-процесс.

    Возвращает True, если helper успешно стартовал — после этого
    вызывающий код ОБЯЗАН закрыть приложение (иначе helper будет ждать
    и через 60 секунд откатится к простому перезапуску).
    """
    if sys.platform != "win32":
        logger.error("Установка обновления реализована только для Windows")
        return False

    _ensure_dirs()
    staged = os.path.join(UPDATE_DIR, "staged")
    _rm(staged)
    try:
        _safe_extract(zip_path, staged)
        src_root = _single_root(staged)

        # Проверяем, что в архиве действительно приложение
        checkfile = os.path.basename(EXE_PATH) if IS_FROZEN else "app.py"
        if not os.path.exists(os.path.join(src_root, checkfile)):
            logger.error("В архиве нет %s — это не похоже на сборку "
                         "приложения, обновление отменено", checkfile)
            _rm(staged)
            return False

        stamp = time.strftime("%Y%m%d_%H%M%S")
        backup = os.path.join(BACKUP_DIR, f"app_{stamp}")
        log = os.path.join(DATA_DIR, "logs", "update_helper.log")

        bat_path = os.path.join(UPDATE_DIR, "apply_update.bat")
        bat = _HELPER_BAT.format(
            pid=os.getpid(),
            appdir=APP_PATH.rstrip("\\"),
            staged=src_root.rstrip("\\"),
            backup=backup,
            log=log,
            restart=_restart_command(),
            checkfile=checkfile,
        )
        with open(bat_path, "w", encoding="utf-8") as f:
            f.write(bat)

        flags = 0
        if hasattr(subprocess, "DETACHED_PROCESS"):
            flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        subprocess.Popen(["cmd.exe", "/c", bat_path],
                         cwd=UPDATE_DIR, close_fds=True,
                         creationflags=flags)
        logger.info("Helper обновления запущен: %s", bat_path)
        return True
    except Exception as e:
        logger.error("Подготовка обновления не удалась: %s", e, exc_info=True)
        _rm(staged)
        return False


def restart_app() -> bool:
    """Перезапуск без обновления. cwd=APP_PATH — иначе не найдётся data/."""
    try:
        if IS_FROZEN:
            cmd = [EXE_PATH]
        else:
            cmd = [sys.executable, os.path.join(APP_PATH, "app.py")]
        subprocess.Popen(cmd, cwd=APP_PATH, close_fds=True)
        return True
    except Exception as e:
        logger.error("Перезапуск не удался: %s", e)
        return False


def cleanup_downloads(keep_hours: int = 24) -> int:
    """Убирает старые скачанные архивы из data/updates/."""
    removed = 0
    try:
        now = time.time()
        for fn in os.listdir(UPDATE_DIR):
            p = os.path.join(UPDATE_DIR, fn)
            if os.path.isfile(p) and now - os.path.getmtime(p) > keep_hours * 3600:
                _rm(p)
                removed += 1
    except OSError:
        pass
    return removed
